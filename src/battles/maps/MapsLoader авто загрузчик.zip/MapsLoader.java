//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package battles.maps;

import battles.maps.loaders.MapL;
import battles.maps.parser.Parser;
import battles.maps.parser.map.bonus.BonusRegion;
import battles.maps.parser.map.bonus.BonusType;
import battles.maps.parser.map.spawn.SpawnPosition;
import battles.maps.parser.map.spawn.SpawnPositionType;
import battles.maps.themes.MapThemeFactory;
import battles.tanks.math.Vector3;
import logger.Logger;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
//import javax.xml.bind.JAXBException;
import logger.remote.RemoteDatabaseLogger;
import main.Main;
import org.apache.commons.codec.digest.DigestUtils;
import org.hibernate.Session;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import services.hibernate.HibernateService;

public class MapsLoader {
   public static HashMap<String, Map> maps = new HashMap();
   private static ArrayList<IMapConfigItem> configItems = new ArrayList();
   private static Parser parser;

   public MapsLoader() {
   }

   public static void initFactoryMaps() {
      Logger.log("Maps Loader Factory inited. Loading maps...");

      try {
         parser = new Parser();
      } catch (Exception var1) {
         var1.printStackTrace();
      }

      loadConfig();
   }

   private static void loadConfig() {
      try {
         JSONParser mapsParser = new JSONParser();
         Object items = mapsParser.parse(new FileReader(new File(Main.pat + "maps/config.json")));
         JSONObject obj = (JSONObject)items;
         JSONArray jarray = (JSONArray)obj.get("maps");

         IMapConfigItem __item;
         for (Iterator var5 = jarray.iterator(); var5.hasNext(); configItems.add(__item)) {
            Object objItem = var5.next();
            JSONObject item = (JSONObject)objItem;
            String id = (String)item.get("id");
            String name = (String)item.get("name");
            String skyboxId = (String)item.get("skybox_id");
            Object ambientSoundId = item.get("ambient_sound_id");
            Object gameModeId = item.get("gamemode_id");
            int minRank = Integer.parseInt((String)item.get("min_rank"));
            int maxRank = Integer.parseInt((String)item.get("max_rank"));
            int maxPlayers = Integer.parseInt((String)item.get("max_players"));
            boolean tdm = (Boolean)item.get("tdm");
            boolean ctf = (Boolean)item.get("ctf");
            Object themeId = item.get("theme_id");
            __item = ambientSoundId != null && gameModeId != null ? new IMapConfigItem(id, name, skyboxId, minRank, maxRank, maxPlayers, tdm, ctf, (String)ambientSoundId, (String)gameModeId) : new IMapConfigItem(id, name, skyboxId, minRank, maxRank, maxPlayers, tdm, ctf);
            if (themeId != null) {
               __item.themeName = (String)themeId;
            }
         }
      } catch (Exception var7) {
         var7.printStackTrace();
         RemoteDatabaseLogger.error(var7);
      }
      parseMaps();
   }

   private static void parseMaps() {
      File[] maps = (new File(Main.pat + "maps")).listFiles();
      File[] var4 = maps;
      int var3 = maps.length;

      for(int var2 = 0; var2 < var3; ++var2) {
         File file = var4[var2];
         if (!file.isDirectory() && file.getName().endsWith(".xml")) {
            parse(file);
         }
      }

      Logger.log("Loaded all maps!\n");
   }

   private static void parse(File file) {
      //Logger.log("Loading " + file.getName() + "...");
      IMapConfigItem temp = getMapItem(file.getName().substring(0, file.getName().length() - 4));
      if (temp != null) {
         Map map = null;

         try {
            map = new Map() {
               {
                  this.name = temp.name;
                  this.id = temp.id;
                  this.skyboxId = temp.skyboxId;
                  this.minRank = temp.minRank;
                  this.maxRank = temp.maxRank;
                  this.maxPlayers = temp.maxPlayers;
                  this.tdm = temp.tdm;
                  this.ctf = temp.ctf;
                  this.md5Hash = DigestUtils.md5Hex(new FileInputStream(file));
                  this.mapTheme = temp.ambientSoundId != null && temp.gameMode != null ? MapThemeFactory.getMapTheme(temp.ambientSoundId, temp.gameMode) : MapThemeFactory.getDefaultMapTheme();
                  this.themeId = temp.themeName;
               }
            };
         } catch (IOException var9) {
            var9.printStackTrace();
         }

         battles.maps.parser.map.Map parsedMap = null;

         try {
            parsedMap = parser.parseMap(file);
         } catch (Exception var8) {
            var8.printStackTrace();
         }

         JSONObject jobj = new JSONObject();
         JSONArray jar = new JSONArray();
         JSONArray jar1 = new JSONArray();
         JSONArray jar2 = new JSONArray();
         Iterator var5 = parsedMap.getSpawnPositions().iterator();

         while(var5.hasNext()) {
            SpawnPosition sp = (SpawnPosition)(var5.next());
            if (sp.getSpawnPositionType() == SpawnPositionType.NONE) {
               Vector3 v = sp.getVector3();
               JSONObject jobj1 = new JSONObject();
               map.spawnPositonsDM.add(v);
               jobj1.put("x",v.x);
               jobj1.put("y",v.y);
               jobj1.put("z",v.z);
               jar.add(jobj1);
            }

            if (sp.getSpawnPositionType() == SpawnPositionType.RED) {
               Vector3 v = sp.getVector3();
               JSONObject jobj1 = new JSONObject();
               map.spawnPositonsRed.add(v);
               jobj1.put("x",v.x);
               jobj1.put("y",v.y);
               jobj1.put("z",v.z);
               jar1.add(jobj1);
            }

            if (sp.getSpawnPositionType() == SpawnPositionType.BLUE) {
               Vector3 v = sp.getVector3();
               JSONObject jobj1 = new JSONObject();
               map.spawnPositonsBlue.add(v);
               jobj1.put("x",v.x);
               jobj1.put("y",v.y);
               jobj1.put("z",v.z);
               jar2.add(jobj1);
            }
         }

         jobj.put("dm",jar);
         jobj.put("blue",jar2);
         jobj.put("red",jar1);

         try(FileWriter writer = new FileWriter("maps/spawn.json", false))
         {
            writer.write(jobj.toJSONString());
            writer.flush();
         }
         catch(IOException ex){
            System.out.println(ex.getMessage());
         }
         JSONObject jobj1 = new JSONObject();
         JSONArray jar3 = new JSONArray();
         JSONArray jar4 = new JSONArray();
         JSONArray jar5 = new JSONArray();
         JSONArray jar6 = new JSONArray();
         JSONArray jar7 = new JSONArray();
         JSONArray jar8 = new JSONArray();

         if (parsedMap.getBonusesRegion() != null) {
            var5 = parsedMap.getBonusesRegion().iterator();

            while(var5.hasNext()) {
               BonusRegion br = (BonusRegion)var5.next();
               Iterator var7 = br.getType().iterator();
               while(var7.hasNext()) {
                  BonusType type = (BonusType)var7.next();
                  if (type == BonusType.CRYSTALL) {
                     JSONObject jobj2 = new JSONObject();
                     JSONObject jobj3 = new JSONObject();
                     JSONObject jobj4 = new JSONObject();
                     JSONObject jobj5 = new JSONObject();
                     Vector3 v = br.toVector3(br.getMin());
                     Vector3 v1 = br.toVector3(br.getMax());
                     Vector3 v2 = new Vector3(0,0,0);
                     jobj3.put("x",v.x);
                     jobj3.put("y",v.y);
                     jobj3.put("z",v.z);
                     jobj4.put("x",v1.x);
                     jobj4.put("y",v1.y);
                     jobj4.put("z",v1.z);
                     jobj5.put("x",v2.x);
                     jobj5.put("y",v2.y);
                     jobj5.put("z",v2.z);
                     jobj2.put("min",jobj3);
                     jobj2.put("max",jobj4);
                     jobj2.put("pos",jobj5);
                     jar3.add(jobj2);
                     map.crystallsRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.CRYSTALL_100) {
                     JSONObject jobj2 = new JSONObject();
                     JSONObject jobj3 = new JSONObject();
                     JSONObject jobj4 = new JSONObject();
                     JSONObject jobj5 = new JSONObject();
                     Vector3 v = br.toVector3(br.getMin());
                     Vector3 v1 = br.toVector3(br.getMax());
                     Vector3 v2 = new Vector3(0,0,0);
                     jobj3.put("x",v.x);
                     jobj3.put("y",v.y);
                     jobj3.put("z",v.z);
                     jobj4.put("x",v1.x);
                     jobj4.put("y",v1.y);
                     jobj4.put("z",v1.z);
                     jobj5.put("x",v2.x);
                     jobj5.put("y",v2.y);
                     jobj5.put("z",v2.z);
                     jobj2.put("min",jobj3);
                     jobj2.put("max",jobj4);
                     jobj2.put("pos",jobj5);
                     jar4.add(jobj2);
                     map.goldsRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.ARMOR) {
                     JSONObject jobj2 = new JSONObject();
                     JSONObject jobj3 = new JSONObject();
                     JSONObject jobj4 = new JSONObject();
                     JSONObject jobj5 = new JSONObject();
                     Vector3 v = br.toVector3(br.getMin());
                     Vector3 v1 = br.toVector3(br.getMax());
                     Vector3 v2 = new Vector3(0,0,0);
                     jobj3.put("x",v.x);
                     jobj3.put("y",v.y);
                     jobj3.put("z",v.z);
                     jobj4.put("x",v1.x);
                     jobj4.put("y",v1.y);
                     jobj4.put("z",v1.z);
                     jobj5.put("x",v2.x);
                     jobj5.put("y",v2.y);
                     jobj5.put("z",v2.z);
                     jobj2.put("min",jobj3);
                     jobj2.put("max",jobj4);
                     jobj2.put("pos",jobj5);
                     jar5.add(jobj2);
                     map.armorsRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.DAMAGE) {
                     JSONObject jobj2 = new JSONObject();
                     JSONObject jobj3 = new JSONObject();
                     JSONObject jobj4 = new JSONObject();
                     JSONObject jobj5 = new JSONObject();
                     Vector3 v = br.toVector3(br.getMin());
                     Vector3 v1 = br.toVector3(br.getMax());
                     Vector3 v2 = new Vector3(0,0,0);
                     jobj3.put("x",v.x);
                     jobj3.put("y",v.y);
                     jobj3.put("z",v.z);
                     jobj4.put("x",v1.x);
                     jobj4.put("y",v1.y);
                     jobj4.put("z",v1.z);
                     jobj5.put("x",v2.x);
                     jobj5.put("y",v2.y);
                     jobj5.put("z",v2.z);
                     jobj2.put("min",jobj3);
                     jobj2.put("max",jobj4);
                     jobj2.put("pos",jobj5);
                     jar6.add(jobj2);
                     map.damagesRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.HEAL) {
                     JSONObject jobj2 = new JSONObject();
                     JSONObject jobj3 = new JSONObject();
                     JSONObject jobj4 = new JSONObject();
                     JSONObject jobj5 = new JSONObject();
                     Vector3 v = br.toVector3(br.getMin());
                     Vector3 v1 = br.toVector3(br.getMax());
                     Vector3 v2 = new Vector3(0,0,0);
                     jobj3.put("x",v.x);
                     jobj3.put("y",v.y);
                     jobj3.put("z",v.z);
                     jobj4.put("x",v1.x);
                     jobj4.put("y",v1.y);
                     jobj4.put("z",v1.z);
                     jobj5.put("x",v2.x);
                     jobj5.put("y",v2.y);
                     jobj5.put("z",v2.z);
                     jobj2.put("min",jobj3);
                     jobj2.put("max",jobj4);
                     jobj2.put("pos",jobj5);
                     jar7.add(jobj2);
                     map.healthsRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.NITRO) {
                     JSONObject jobj2 = new JSONObject();
                     JSONObject jobj3 = new JSONObject();
                     JSONObject jobj4 = new JSONObject();
                     JSONObject jobj5 = new JSONObject();
                     Vector3 v = br.toVector3(br.getMin());
                     Vector3 v1 = br.toVector3(br.getMax());
                     Vector3 v2 = new Vector3(0,0,0);
                     jobj3.put("x",v.x);
                     jobj3.put("y",v.y);
                     jobj3.put("z",v.z);
                     jobj4.put("x",v1.x);
                     jobj4.put("y",v1.y);
                     jobj4.put("z",v1.z);
                     jobj5.put("x",v2.x);
                     jobj5.put("y",v2.y);
                     jobj5.put("z",v2.z);
                     jobj2.put("min",jobj3);
                     jobj2.put("max",jobj4);
                     jobj2.put("pos",jobj5);
                     jar8.add(jobj2);
                     map.nitrosRegions.add(br.toServerBonusRegion());
                  }
               }
            }
         }

         jobj1.put("gold",jar4);
         jobj1.put("crystal",jar3);
         jobj1.put("medkit",jar7);
         jobj1.put("armorup",jar5);
         jobj1.put("damageup",jar6);
         jobj1.put("nitro",jar8);

         //System.out.println("json bonus: " + jobj1.toJSONString());

         try(FileWriter writer = new FileWriter("maps/bonus.json", false))
         {
            writer.write(jobj1.toJSONString());
            writer.flush();
         }
         catch(IOException ex){
            System.out.println(ex.getMessage());
         }

         JSONObject jobj2 = new JSONObject();
         JSONObject jobj3 = new JSONObject();
         JSONObject jobj4 = new JSONObject();
         Vector3 v = parsedMap.getPositionBlueFlag().toVector3();
         Vector3 v1 = parsedMap.getPositionRedFlag().toVector3();
         jobj3.put("x",v.x);
         jobj3.put("y",v.y);
         jobj3.put("z",v.z);
         jobj4.put("x",v1.x);
         jobj4.put("y",v1.y);
         jobj4.put("z",v1.z);
         jobj2.put("blue",jobj3);
         jobj2.put("red",jobj4);
         //System.out.println("json flags: " + jobj2.toJSONString());
         try(FileWriter writer = new FileWriter("maps/flag.json", false))
         {
            writer.write(jobj2.toJSONString());
            writer.flush();
         }
         catch(IOException ex){
            System.out.println(ex.getMessage());
         }
         map.flagBluePosition = parsedMap.getPositionBlueFlag() != null ? parsedMap.getPositionBlueFlag().toVector3() : null;
         map.flagRedPosition = parsedMap.getPositionRedFlag() != null ? parsedMap.getPositionRedFlag().toVector3() : null;
         if (map.flagBluePosition != null) {
            map.flagBluePosition.z += 50.0F;
            map.flagRedPosition.z += 50.0F;
         }

         maps.put(map.id, map);
      }
   }

   private static IMapConfigItem getMapItem(String id) {
      Iterator var2 = configItems.iterator();

      while(var2.hasNext()) {
         IMapConfigItem item = (IMapConfigItem)var2.next();
         if (item.id.equals(id)) {
            return item;
         }
      }

      return null;
   }
}
