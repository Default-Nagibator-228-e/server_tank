package gtanks.lobby;

import gtanks.main.Main;
import gtanks.rmi.payments.mapping.Payment;
import gtanks.system.localization.Localization;
import gtanks.users.friends.Friends;
import gtanks.users.garage.Garage;
import gtanks.users.garage.GarageItemsLoader;
import gtanks.users.garage.items.Item;
import gtanks.network.listeners.IDisconnectListener;
import gtanks.users.anticheat.AntiCheatData;
import gtanks.battles.maps.MapsLoader;
import gtanks.battles.maps.Map;
import gtanks.users.garage.items.modification.Mod;
import gtanks.users.garage.items.modification.Modif;
import org.hibernate.cfg.annotations.Nullability;
import org.json.simple.parser.ParseException;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONObject;
import gtanks.lobby.battles.BattleInfo;
import gtanks.logger.Logger;
import gtanks.lobby.battles.BattlesList;
import gtanks.users.TypeUser;
import gtanks.json.JSONUtils;
import gtanks.StringUtils;
import gtanks.lobby.chat.ChatMessage;
import gtanks.commands.Command;
import java.io.IOException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Objects;
import java.util.Vector;

import gtanks.commands.Type;
import gtanks.main.params.OnlineStats;
import gtanks.users.locations.UserLocation;
import gtanks.lobby.chat.flood.LobbyFloodController;
import gtanks.network.listeners.DisconnectListener;
import gtanks.lobby.chat.flood.FloodController;
import gtanks.services.AutoEntryServices;
import gtanks.system.dailybonus.DailyBonusService;
import gtanks.lobby.chat.ChatLobby;
import gtanks.services.LobbysServices;
import gtanks.lobby.top.HallOfFame;
import gtanks.main.database.impl.DatabaseManagerImpl;
import gtanks.services.annotations.ServicesInject;
import gtanks.main.database.DatabaseManager;
import gtanks.battles.spectator.SpectatorController;
import gtanks.battles.BattlefieldPlayerController;
import gtanks.main.netty.ProtocolTransfer;
import gtanks.users.User;

public class LobbyManager extends LobbyComandsConst
{
   private User localUser;
   public ProtocolTransfer networker;
   public BattlefieldPlayerController battle;
   public SpectatorController spectatorController;
   @ServicesInject(target = DatabaseManagerImpl.class)
   private static DatabaseManager database;
   @ServicesInject(target = HallOfFame.class)
   private static HallOfFame top;
   @ServicesInject(target = LobbysServices.class)
   private static LobbysServices lobbysServices;
   @ServicesInject(target = ChatLobby.class)
   private static ChatLobby chatLobby;
   @ServicesInject(target = DailyBonusService.class)
   private static DailyBonusService dailyBonusService;
   @ServicesInject(target = AutoEntryServices.class)
   private AutoEntryServices autoEntryServices;
   private FloodController chatFloodController;
   public DisconnectListener disconnectListener;
   public long timer;
   private int mof = 0;

   static {
      LobbyManager.database = DatabaseManagerImpl.instance();
      LobbyManager.top = HallOfFame.getInstance();
      LobbyManager.lobbysServices = LobbysServices.getInstance();
      LobbyManager.chatLobby = ChatLobby.getInstance();
      LobbyManager.dailyBonusService = DailyBonusService.instance();
   }

   public LobbyManager(final ProtocolTransfer networker, final User localUser) {
      this.autoEntryServices = AutoEntryServices.instance();
      this.networker = networker;
      this.localUser = localUser;
      this.disconnectListener = new DisconnectListener();
      this.setChatFloodController(new LobbyFloodController());
      this.timer = System.currentTimeMillis();
      this.localUser.setUserLocation(UserLocation.GARAGE);
      LobbyManager.lobbysServices.addLobby(this);
      OnlineStats.addOnline();
      LobbyManager.dailyBonusService.userInited(this);
   }

   public void send(final Type type, final String... args) {
      try {
         this.networker.send(type, args);
      }
      catch (IOException ex) {}
   }

   public void executeCommand(final Command cmd) {
      try {
         switch (cmd.type) {
            case LOBBY_CHAT: {
               LobbyManager.chatLobby.addMessage(new ChatMessage(this.localUser, cmd.args[0], this.stringToBoolean(cmd.args[1]), cmd.args[2].equals("NULL") ? null : LobbyManager.database.getUserById(cmd.args[2]), this));
               break;
            }
            case GARAGE: {
               if (cmd.args[0].equals("try_mount_item")) {
                  if (this.localUser.getGarage().mountItem(cmd.args[1])) {
                     this.send(Type.GARAGE, "mount_item", cmd.args[1]);
                     this.localUser.getGarage().parseJSONData();
                     LobbyManager.database.update(this.localUser.getGarage());
                  }
                  else {
                     this.send(Type.GARAGE, "try_mount_item_NO");
                  }
               }
               if (cmd.args[0].equals("try_update_item")) {
                  this.onTryUpdateItem(cmd.args[1]);
               }
               if (cmd.args[0].equals("mod")) {
                  this.mod(cmd.args[1],cmd.args[2]);
               }
               if (cmd.args[0].equals("bymod")) {
                  this.bpt1(cmd.args[1],cmd.args[2]);
               }
               if (cmd.args[0].equals("get_garage_data") && this.localUser.getGarage().mountHull != null && this.localUser.getGarage().mountTurret != null && this.localUser.getGarage().mountColormap != null) {
                  this.send(Type.GARAGE, "init_mounted_item", StringUtils.concatStrings(new String[] { this.localUser.getGarage().mountHull.id, "_m", String.valueOf(this.localUser.getGarage().mountHull.modificationIndex) }));
                  this.send(Type.GARAGE, "init_mounted_item", StringUtils.concatStrings(new String[] { this.localUser.getGarage().mountTurret.id, "_m", String.valueOf(this.localUser.getGarage().mountTurret.modificationIndex) }));
                  this.send(Type.GARAGE, "init_mounted_item", StringUtils.concatStrings(new String[] { this.localUser.getGarage().mountColormap.id, "_m", String.valueOf(this.localUser.getGarage().mountColormap.modificationIndex) }));
               }
               if (cmd.args[0].equals("try_buy_item")) {
                  this.onTryBuyItem(cmd.args[1], Integer.parseInt(cmd.args[2]));
                  break;
               }
               break;
            }
            case LOBBY: {
               if (cmd.args[0].equals("get_hall_of_fame_data")) {
                  this.localUser.setUserLocation(UserLocation.HALL_OF_FAME);
                  this.send(Type.LOBBY, "init_hall_of_fame", JSONUtils.parseHallOfFame(LobbyManager.top));
               }
               if (cmd.args[0].equals("pum")) {
                  System.out.println(this.localUser.getNickname());
                  if(cmd.args[1].equals(this.localUser.getNickname()))
                  {
                     System.out.println(4);
                     this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(this.localUser.getFriend()));
                  }
               }
               if (cmd.args[0].equals("get_garage_data")) {
                  this.sendGarage();
               }
               if (cmd.args[0].equals("get_friend")) {
                  this.sendFriend();
               }
               if (cmd.args[0].equals("make_friend")) {
                  makeFriend(cmd.args[1]);
               }
               if (cmd.args[0].equals("got_friend")) {
                  gotFriend(cmd.args[1]);
               }
               if (cmd.args[0].equals("del_friend")) {
                  delFriend(cmd.args[1]);
               }
               if (cmd.args[0].equals("del_infriend")) {
                  delnFriend(cmd.args[1]);
               }
               if (cmd.args[0].equals("get_rank")) {
                  this.sendRang(cmd.args[1],cmd.args[2],cmd.args[3]);
               }
               if (cmd.args[0].equals("get_data_init_battle_select")) {
                  this.sendMapsInit();
               }
               if (cmd.args[0].equals("check_user")) {
                  try {
                     database.getUserById(cmd.args[1]).getNickname();
                     this.send(Type.LOBBY, "val", JSONUtils.parseV(0));
                  }catch (NullPointerException f){
                     this.send(Type.LOBBY, "val", JSONUtils.parseV(1));
                  }
               }
               if (cmd.args[0].equals("check_battleName_for_forbidden_words")) {
                  final String _name = (cmd.args.length > 0) ? cmd.args[1] : "";
                  this.checkBattleName(_name);
               }
               if (cmd.args[0].equals("try_create_battle_dm")) {
                  this.tryCreateBattleDM(cmd.args[1], cmd.args[2], Integer.parseInt(cmd.args[3]), Integer.parseInt(cmd.args[4]), Integer.parseInt(cmd.args[5]), Integer.parseInt(cmd.args[6]), Integer.parseInt(cmd.args[7]), this.stringToBoolean(cmd.args[8]), this.stringToBoolean(cmd.args[9]), this.stringToBoolean(cmd.args[10]));
               }
               if (cmd.args[0].equals("try_create_battle_tdm")) {
                  this.tryCreateTDMBattle(cmd.args[1]);
               }
               if (cmd.args[0].equals("zacet")) {
                  this.zacet(cmd.args[1]);
               }
               if (cmd.args[0].equals("try_create_battle_ctf")) {
                  this.tryCreateCTFBattle(cmd.args[1]);
               }
               if (cmd.args[0].equals("get_show_battle_info")) {
                  this.sendBattleInfo(cmd.args[1]);
               }
               if (cmd.args[0].equals("enter_battle")) {
                  this.onEnterInBattle(cmd.args[1]);
               }
               cmd.args[0].equals("bug_report");
               cmd.args[0].equals("screenshot");
               if (cmd.args[0].equals("enter_battle_team")) {
                  this.onEnterInTeamBattle(cmd.args[1], Boolean.parseBoolean(cmd.args[2]));
               }
               if (cmd.args[0].equals("enter_battle_spectator")) {
                  if (this.getLocalUser().getType() == TypeUser.DEFAULT) {
                     return;
                  }
                  this.enterInBattleBySpectator(cmd.args[1]);
               }
               if (cmd.args[0].equals("user_inited")) {
                  LobbyManager.dailyBonusService.userLoaded(this);
                  break;
               }
               break;
            }
            case BATTLE: {
               if (this.battle != null) {
                  this.battle.executeCommand(cmd);
               }
               if (this.spectatorController != null) {
                  this.spectatorController.executeCommand(cmd);
                  break;
               }
               break;
            }
            case SYSTEM: {
               final String data = cmd.args[0];
               if (data.equals("c01")) {
                  this.kick();
                  break;
               }
               break;
            }
         }
      }
      catch (Exception ex) {
         ex.printStackTrace();
      }
   }

   private void enterInBattleBySpectator(final String battleId) {
      final BattleInfo battle = BattlesList.getBattleInfoById(battleId);
      if (battle == null) {
         return;
      }
      battle.model.spectatorModel.addSpectator(this.spectatorController = new SpectatorController(this, battle.model, battle.model.spectatorModel));
      this.localUser.setUserLocation(UserLocation.BATTLE);
      this.send(Type.BATTLE, "init_battle_model", JSONUtils.parseBattleModelInfo(battle, true));
      Logger.log("User " + this.localUser.getNickname() + " enter in battle by spectator.");
   }

   private void sendTableMessage(final String msg) {
      this.send(Type.LOBBY, "server_message", msg);
   }

   private void tryCreateCTFBattle(final String json) {
      if (System.currentTimeMillis() - this.localUser.getAntiCheatData().lastTimeCreationBattle <= 300000L) {
         if (this.localUser.getAntiCheatData().countCreatedBattles >= 3) {
            if (this.localUser.getAntiCheatData().countWarningForFludCreateBattle >= 5) {
               this.kick();
            }
            this.sendTableMessage("\u0412\u044b \u043c\u043e\u0436\u0435\u0442\u0435 \u0441\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u043d\u0435 \u0431\u043e\u043b\u0435\u0435 \u0442\u0440\u0435\u0445 \u0431\u0438\u0442\u0432 \u0432 \u0442\u0435\u0447\u0435\u043d\u0438\u0438 5 \u043c\u0438\u043d\u0443\u0442.");
            final AntiCheatData antiCheatData = this.localUser.getAntiCheatData();
            ++antiCheatData.countWarningForFludCreateBattle;
            return;
         }
      }
      else {
         this.localUser.getAntiCheatData().countCreatedBattles = 0;
         this.localUser.getAntiCheatData().countWarningForFludCreateBattle = 0;
      }
      JSONObject parser = null;
      try {
         parser = (JSONObject)new JSONParser().parse(json);
      }
      catch (ParseException e) {
         e.printStackTrace();
      }
      final BattleInfo battle = new BattleInfo();
      battle.battleType = "CTF";
      battle.isPaid = (boolean)parser.get((Object)"pay");
      battle.isPrivate = (boolean)parser.get((Object)"privateBattle");
      battle.friendlyFire = (boolean)parser.get((Object)"frielndyFire");
      battle.name = (String)parser.get((Object)"gameName");
      battle.map = MapsLoader.maps.get(parser.get((Object)"mapId"));
      battle.maxPeople = (int)(long)parser.get((Object)"numPlayers");
      battle.numFlags = (int)(long)parser.get((Object)"numFlags");
      battle.minRank = (int)(long)parser.get((Object)"minRang");
      battle.maxRank = (int)(long)parser.get((Object)"maxRang");
      battle.team = true;
      battle.time = (int)(long)parser.get((Object)"time");
      battle.autobalance = (boolean)parser.get((Object)"autoBalance");
      final Map map = battle.map;
      if (battle.maxRank < battle.minRank) {
         battle.maxRank = battle.minRank;
      }
      if (battle.maxPeople < 2) {
         battle.maxPeople = 2;
      }
      if (battle.time <= 0 && battle.numFlags <= 0) {
         battle.time = 15;
         battle.numFlags = 0;
      }
      if (battle.maxPeople > map.maxPlayers) {
         battle.maxPeople = map.maxPlayers;
      }
      if (battle.numKills > 999) {
         battle.numKills = 999;
      }
      BattlesList.tryCreateBatle(battle);
      this.localUser.getAntiCheatData().lastTimeCreationBattle = System.currentTimeMillis();
      final AntiCheatData antiCheatData2 = this.localUser.getAntiCheatData();
      ++antiCheatData2.countCreatedBattles;
   }

   private void tryCreateTDMBattle(final String json) {
      if (System.currentTimeMillis() - this.localUser.getAntiCheatData().lastTimeCreationBattle <= 300000L) {
         if (this.localUser.getAntiCheatData().countCreatedBattles >= 3) {
            if (this.localUser.getAntiCheatData().countWarningForFludCreateBattle >= 5) {
               this.kick();
            }
            this.sendTableMessage("\u0412\u044b \u043c\u043e\u0436\u0435\u0442\u0435 \u0441\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u043d\u0435 \u0431\u043e\u043b\u0435\u0435 \u0442\u0440\u0435\u0445 \u0431\u0438\u0442\u0432 \u0432 \u0442\u0435\u0447\u0435\u043d\u0438\u0438 5 \u043c\u0438\u043d\u0443\u0442.");
            final AntiCheatData antiCheatData = this.localUser.getAntiCheatData();
            ++antiCheatData.countWarningForFludCreateBattle;
            return;
         }
      }
      else {
         this.localUser.getAntiCheatData().countCreatedBattles = 0;
         this.localUser.getAntiCheatData().countWarningForFludCreateBattle = 0;
      }
      JSONObject parser = null;
      try {
         parser = (JSONObject)new JSONParser().parse(json);
      }
      catch (ParseException e) {
         e.printStackTrace();
      }
      final BattleInfo battle = new BattleInfo();
      battle.battleType = "TDM";
      battle.isPaid = (boolean)parser.get((Object)"pay");
      battle.isPrivate = (boolean)parser.get((Object)"privateBattle");
      battle.friendlyFire = (boolean)parser.get((Object)"frielndyFire");
      battle.name = (String)parser.get((Object)"gameName");
      battle.map = MapsLoader.maps.get(parser.get((Object)"mapId"));
      battle.maxPeople = (int)(long)parser.get((Object)"numPlayers");
      battle.numKills = (int)(long)parser.get((Object)"numKills");
      battle.minRank = (int)(long)parser.get((Object)"minRang");
      battle.maxRank = (int)(long)parser.get((Object)"maxRang");
      battle.team = true;
      battle.time = (int)(long)parser.get((Object)"time");
      battle.autobalance = (boolean)parser.get((Object)"autoBalance");
      final Map map = battle.map;
      if (battle.maxRank < battle.minRank) {
         battle.maxRank = battle.minRank;
      }
      if (battle.maxPeople < 2) {
         battle.maxPeople = 2;
      }
      if (battle.time <= 0 && battle.numKills <= 0) {
         battle.time = 900;
         battle.numKills = 0;
      }
      if (battle.maxPeople > map.maxPlayers) {
         battle.maxPeople = map.maxPlayers;
      }
      if (battle.numKills > 999) {
         battle.numKills = 999;
      }
      BattlesList.tryCreateBatle(battle);
      this.localUser.getAntiCheatData().lastTimeCreationBattle = System.currentTimeMillis();
      final AntiCheatData antiCheatData2 = this.localUser.getAntiCheatData();
      ++antiCheatData2.countCreatedBattles;
   }

   public void onExitFromBattle() {
      if (this.battle != null) {
         if (this.autoEntryServices.removePlayer(this.battle.battle, this.getLocalUser().getNickname(), this.battle.playerTeamType, this.battle.battle.battleInfo.team)) {
            this.battle.destroy(true);
         }
         else {
            this.battle.destroy(false);
         }
         this.battle = null;
         this.disconnectListener.removeListener(this.battle);
      }
      if (this.spectatorController != null) {
         this.spectatorController.onDisconnect();
         this.spectatorController = null;
      }
      this.send(Type.LOBBY_CHAT, "init_messages", JSONUtils.parseChatLobbyMessages(LobbyManager.chatLobby.getMessages()));
   }

   public void onExitFromStatistic() {
      this.onExitFromBattle();
      this.sendMapsInit();
   }

   public void zacet(String cod) {
      Payment pay = database.getPayByCod(cod);
      try {
         this.addCrystall(pay.getSum());
         this.send(Type.LOBBY, "pa", JSONUtils.parsePa(pay.getSum()));
         pay.setNickname("1111111111111111345");
         pay.setSum(0);
         database.update(pay);
      }catch (NullPointerException kk){

      }
   }

   public void bpt1(String name, String mod) {
      Garage ve = this.localUser.getGarage();
      Iterator var3 = ve.items.iterator();

      while(var3.hasNext()) {
         Item hhy = (Item)var3.next();
         if(hhy.name.localizatedString(Localization.RU).equals(name) && hhy.modificationIndex == Integer.parseInt(mod))
         {
            if(hhy.mod + 1 != 11) {
               for (int tth = 0; tth < GarageItemsLoader.f.size(); tth++) {
                  if (GarageItemsLoader.f.get(tth).name.equals(name)) {
                     Vector<Vector<Modif>> dda = GarageItemsLoader.f.get(tth).jobs();
                     Modif ffg = dda.get(Integer.parseInt(mod)).get(hhy.mod);
                     if(this.localUser.getCrystall() - ffg.price > 0) {
                        hhy.mod += 1;//Прогресс
                        this.addCrystall(-ffg.price);
                        this.localUser.getGarage().parseJSONData();
                        database.update(this.localUser.getGarage());
                     }
                  }
               }
            }
         }
      }
      this.mod(name,mod);
   }

   public void mod(String name, String mod) {
      Garage ve = this.localUser.getGarage();
      Iterator var30 = ve.items.iterator();

      while(var30.hasNext()) {
         Item item = (Item)var30.next();
         if(item.name.localizatedString(Localization.RU).equals(name) && item.modificationIndex == Integer.parseInt(mod))
         {
            mof = item.mod;//Прогресс
         }
      }
      int var1 = 0;//Стоимость
      String var2 = "";//f
      String var3 = "";//s
      String var4 = "";//t
      if(mof != 10) {
         for (int tth = 0; tth < GarageItemsLoader.f.size(); tth++) {
            if (GarageItemsLoader.f.get(tth).name.equals(name)) {
               //System.out.println("Имя: " + GarageItemsLoader.f.get(tth).name);
               Vector<Vector<Modif>> dda = GarageItemsLoader.f.get(tth).jobs();
               Modif ffg = dda.get(Integer.parseInt(mod)).get(mof);
               Modif ffg1 = dda.get(Integer.parseInt(mod)).get(mof + 1);
               //System.out.println("Модификация: " + Integer.parseInt(mod));
               var1 = ffg.price;
               //System.out.println("Цена: " + ffg.price);
               String[] ttu = new String[ffg.propertys.length];
               String[] ttu1 = new String[ffg.propertys.length];
               String[] ttu2 = new String[ffg1.propertys.length];
               for (int kkl = 0; kkl < ffg.propertys.length; kkl++) {
                  ttu[kkl] = ffg.propertys[kkl].value;
               }
               for (int kkl1 = 0; kkl1 < ffg1.propertys.length; kkl1++) {
                  ttu2[kkl1] = ffg1.propertys[kkl1].value;
               }
               for (int yyi = 0; yyi < ttu.length; yyi++) {
                  try {
                     try {
                        String[] h = ttu[yyi].split(" - ");
                        String[] h1 = ttu2[yyi].split(" - ");
                        if (h.length > 1) {
                           for (int var5 = 0; var5 < h.length; var5++) {
                              if (var5 > 0) {
                                 ttu1[yyi] += " - " + roundResult(Double.parseDouble(h1[var5]) - Double.parseDouble(h[var5]), 2);
                              } else {
                                 ttu1[yyi] = roundResult(Double.parseDouble(h1[var5]) - Double.parseDouble(h[var5]), 2) + "";
                              }
                           }
                        } else {
                           ttu1[yyi] = "" + roundResult(Double.parseDouble(h1[0]) - Double.parseDouble(h[0]), 2);
                        }
                     } catch (NullPointerException oop) {
                        ttu1[yyi] = "0";
                     }
                  } catch (NumberFormatException k) {
                     try {
                        String[] h = ttu[yyi].split("-");
                        String[] h1 = ttu2[yyi].split("-");
                        if (h.length > 1) {
                           for (int var5 = 0; var5 < h.length; var5++) {
                              if (var5 > 0) {
                                 ttu1[yyi] += " - " + roundResult(Double.parseDouble(h1[var5]) - Double.parseDouble(h[var5]), 2);
                              } else {
                                 ttu1[yyi] = roundResult(Double.parseDouble(h1[var5]) - Double.parseDouble(h[var5]), 2) + "";
                              }
                           }
                        } else {
                           ttu1[yyi] = "" + roundResult(Double.parseDouble(h1[0]) - Double.parseDouble(h[0]), 2);
                        }
                     } catch (NumberFormatException ggy) {
                        ttu1[yyi] = 0 + "";
                     }
                  }
               }
               var2 = jggd(ttu);
               var3 = jggd(ttu1);
               var4 = jggd(ttu2);
            }
         }
      }else{
         for (int tth = 0; tth < GarageItemsLoader.f.size(); tth++) {
            if (GarageItemsLoader.f.get(tth).name.equals(name)) {
               Vector<Vector<Modif>> dda = GarageItemsLoader.f.get(tth).jobs();
               Modif ffg = dda.get(Integer.parseInt(mod)).get(mof);
               String[] ttu = new String[ffg.propertys.length];
               for (int kkl = 0; kkl < ffg.propertys.length; kkl++) {
                  ttu[kkl] = ffg.propertys[kkl].value;
               }
               var2 = jggd(ttu);
            }
         }
      }
      //System.out.println(var + "    " + var1 + "   " + var2 + "   " + var3 + "   " + var4);
      this.send(Type.GARAGE, "lod", JSONUtils.parseMod(mof,var2,var3,var4,var1));
   }

   private double roundResult (double d1, int precise) {
      DecimalFormat df = new DecimalFormat("#.##");
      df.setRoundingMode(RoundingMode.CEILING);
      //Double d = new Double("1");
      for (Number n : Arrays.asList(d1)) {
         d1 = n.doubleValue();
      }
      return Double.parseDouble(df.format(d1).replace(",","."));
      //return d1;
   }

   private String jggd(String[] po)
   {
      String f = "";
      for(int ghk = 0;ghk<po.length;ghk++)
      {
         if(po[ghk] != null && po[ghk] != "" && ghk != 0) {
            f = String.join("э", f, po[ghk]);
         }
         if(po[ghk] != null && po[ghk] != "" && ghk == 0)
         {
            f = po[ghk];
         }
      }
      return f;
   }

   private void onEnterInTeamBattle(final String battleId, final boolean red) {
      this.localUser.setUserLocation(UserLocation.BATTLE);
      if (this.battle != null) {
         return;
      }
      final BattleInfo battleInfo = BattlesList.getBattleInfoById(battleId);
      if (battleInfo == null) {
         return;
      }
      if (battleInfo.model.players.size() >= battleInfo.maxPeople * 2) {
         return;
      }
      if (red) {
         final BattleInfo battleInfo2 = battleInfo;
         ++battleInfo2.redPeople;
      }
      else {
         final BattleInfo battleInfo3 = battleInfo;
         ++battleInfo3.bluePeople;
      }
      this.battle = new BattlefieldPlayerController(this, battleInfo.model, red ? "RED" : "BLUE");
      this.disconnectListener.addListener((IDisconnectListener)this.battle);
      LobbyManager.lobbysServices.sendCommandToAllUsers(Type.LOBBY, UserLocation.BATTLESELECT, new String[] { "update_count_users_in_team_battle", JSONUtils.parseUpdateCoundPeoplesCommand(battleInfo) });
      this.send(Type.BATTLE, "init_battle_model", JSONUtils.parseBattleModelInfo(battleInfo, false));
      LobbyManager.lobbysServices.sendCommandToAllUsers(Type.LOBBY, UserLocation.BATTLESELECT, new String[] { "add_player_to_battle", JSONUtils.parseAddPlayerComand(this.battle, battleInfo) });
   }

   private void onEnterInBattle(final String battleId) {
      this.localUser.setUserLocation(UserLocation.BATTLE);
      this.autoEntryServices.removePlayer(this.getLocalUser().getNickname());
      if (this.battle != null) {
         return;
      }
      final BattleInfo battleInfo = BattlesList.getBattleInfoById(battleId);
      if (battleInfo == null) {
         return;
      }
      if (battleInfo.model.players.size() >= battleInfo.maxPeople) {
         return;
      }
      this.battle = new BattlefieldPlayerController(this, battleInfo.model, "NONE");
      this.disconnectListener.addListener((IDisconnectListener)this.battle);
      final BattleInfo battleInfo2 = battleInfo;
      ++battleInfo2.countPeople;
      System.out.println("incration");
      if (!battleInfo.team) {
         LobbyManager.lobbysServices.sendCommandToAllUsers(Type.LOBBY, UserLocation.BATTLESELECT, new String[] { StringUtils.concatStrings(new String[] { "update_count_users_in_dm_battle", ";", battleId, ";", String.valueOf(this.battle.battle.battleInfo.countPeople) }) });
      }
      else {
         LobbyManager.lobbysServices.sendCommandToAllUsers(Type.LOBBY, UserLocation.BATTLESELECT, new String[] { "update_count_users_in_team_battle", JSONUtils.parseUpdateCoundPeoplesCommand(battleInfo) });
      }
      this.send(Type.BATTLE, "init_battle_model", JSONUtils.parseBattleModelInfo(battleInfo, false));
      LobbyManager.lobbysServices.sendCommandToAllUsers(Type.LOBBY, UserLocation.BATTLESELECT, new String[] { "add_player_to_battle", JSONUtils.parseAddPlayerComand(this.battle, battleInfo) });
   }

   private void sendBattleInfo(final String id) {
      this.send(Type.LOBBY, "show_battle_info", JSONUtils.parseBattleInfoShow(BattlesList.getBattleInfoById(id), this.getLocalUser().getType() != TypeUser.DEFAULT && this.getLocalUser().getType() != TypeUser.TESTER));
   }

   private void delnFriend(String uid1) {
      User jj = database.getUserById(uid1);
      jj.setFriend(database.getFriendByUser(jj));
      dedrj(this.localUser.getNickname(), jj.getFriend());
      dedrj(uid1, this.localUser.getFriend());
      database.update(this.localUser.getFriend());
      database.update(jj.getFriend());
      try
      {
         LobbyManager fdr = database.getUserById(uid1).getLobby();
         this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(localUser.getFriend()));
         for(int hm = 0; hm< Main.opdf.size();hm++)
         {
            if(Main.opdf.get(hm).localUser.getNickname().equals(uid1)) {
               Main.opdf.get(hm).send(Type.LOBBY, "init_f", JSONUtils.parseFriend(jj.getFriend()));
            }
         }
      }catch (NullPointerException g) {
         this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(localUser.getFriend()));
      }
   }

   private void delFriend(String uid1) {
      User jj = database.getUserById(uid1);
      jj.setFriend(database.getFriendByUser(jj));
      Vector<String> fgre = dedrj(uid1,this.localUser.getFriend()).get(2);
      fgre.addElement(uid1 + "э");
      this.localUser.getFriend().setOutt(fgre);
      database.update(this.localUser.getFriend());
      Vector<String> fgre1 = dedrj(this.localUser.getNickname(),jj.getFriend()).get(1);
      fgre1.addElement(this.localUser.getNickname() + "э");
      jj.getFriend().setInn(fgre1);
      database.update(jj.getFriend());
      try
      {
         LobbyManager fdr = database.getUserById(uid1).getLobby();
         this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(this.localUser.getFriend()));
         for(int hm = 0; hm< Main.opdf.size();hm++)
         {
            if(Main.opdf.get(hm).localUser.getNickname().equals(uid1)) {
               Main.opdf.get(hm).send(Type.LOBBY, "init_f", JSONUtils.parseFriend(jj.getFriend()));
            }
         }
      }catch (NullPointerException g) {
         this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(this.localUser.getFriend()));
      }
   }

   private void gotFriend(String uid1) {
      User jj = database.getUserById(uid1);
      jj.setFriend(database.getFriendByUser(jj));
      Vector<String> fgre = dedrj(uid1,this.localUser.getFriend()).get(1);
      fgre.addElement(uid1 + "э");
      this.localUser.getFriend().setInn(fgre);
      database.update(this.localUser.getFriend());
      Vector<String> fgre1 = dedrj(this.localUser.getNickname(),jj.getFriend()).get(2);
      fgre1.addElement(this.localUser.getNickname() + "э");
      jj.getFriend().setOutt(fgre1);
      database.update(jj.getFriend());
      try
      {
         LobbyManager fdr = database.getUserById(uid1).getLobby();
         this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(this.localUser.getFriend()));
         for(int hm = 0; hm< Main.opdf.size();hm++)
         {
            if(Main.opdf.get(hm).localUser.getNickname().equals(uid1)) {
               Main.opdf.get(hm).send(Type.LOBBY, "init_f", JSONUtils.parseFriend(jj.getFriend()));
            }
         }
      }catch (NullPointerException g) {
         this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(this.localUser.getFriend()));
      }
   }

   private void makeFriend(String uid1) {
      User jj = database.getUserById(uid1);
      jj.setFriend(database.getFriendByUser(jj));
      Vector<String> fgre = dedrj(uid1,this.localUser.getFriend()).get(0);
      fgre.addElement(uid1 + "э");
      this.localUser.getFriend().setDR(fgre);
      database.update(this.localUser.getFriend());
      Vector<String> fgre1 = dedrj(this.localUser.getNickname(),jj.getFriend()).get(0);
      fgre1.addElement(this.localUser.getNickname() + "э");
      jj.getFriend().setDR(fgre1);
      database.update(jj.getFriend());
      try
      {
         LobbyManager fdr = database.getUserById(uid1).getLobby();
         this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(this.localUser.getFriend()));
         for(int hm = 0; hm< Main.opdf.size();hm++)
         {
            if(Main.opdf.get(hm).localUser.getNickname().equals(uid1)) {
               Main.opdf.get(hm).send(Type.LOBBY, "init_f", JSONUtils.parseFriend(jj.getFriend()));
            }
         }
      }catch (NullPointerException g) {
         this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(this.localUser.getFriend()));
      }
   }

   private Vector<Vector<String>> dedrj(String uid1, Friends fg) {
      Vector<String> fd = fg.getDrV();
      Vector<String> fd1 = fg.getInnV();
      Vector<String> fd2 = fg.getOuttV();
      for(int f = 0; f < fd.size(); f++)
      {
         if(fd.get(f).equals(uid1) || fd.get(f).equals(uid1 + "э"))
         {
            fd.remove(f);
            //String f1 = fd.get(f);
            //f1 = null;
         }
      }
      for(int f1 = 0; f1 < fd1.size(); f1++)
      {
         if(fd1.get(f1).equals(uid1) || fd1.get(f1).equals(uid1 + "э"))
         {
            fd1.remove(f1);
            //String f1 = fd1.get(f);
            //f1 = null;
         }
      }
      for(int f2 = 0; f2 < fd2.size(); f2++)
      {
         if(fd2.get(f2).equals(uid1) || fd2.get(f2).equals(uid1 + "э"))
         {
            fd2.remove(f2);
            //String f1 = fd2.get(f);
            //f1 = null;
         }
      }
      fg.setDR(fd);
      fg.setInn(fd1);
      fg.setOutt(fd2);
      fd = fg.getDrV();
      fd1 = fg.getInnV();
      fd2 = fg.getOuttV();
      Vector<Vector<String>> gkl = new Vector<Vector<String>>();
      gkl.add(fd);
      gkl.add(fd1);
      gkl.add(fd2);
      return gkl;
   }

   private void sendRang(final String id, String uid, String type) {
      try {
         this.send(Type.LOBBY, "rang", JSONUtils.parseR(database.getUserById(uid).getRang(), id, type));
      }catch (NullPointerException upd){
      }
   }

   private void tryCreateBattleDM(final String gameName, final String mapId, int time, int kills, int maxPlayers, final int minRang, int maxRang, final boolean isPrivate, final boolean pay, final boolean mm) {
      if (System.currentTimeMillis() - this.localUser.getAntiCheatData().lastTimeCreationBattle <= 300000L) {
         if (this.localUser.getAntiCheatData().countCreatedBattles >= 3) {
            if (this.localUser.getAntiCheatData().countWarningForFludCreateBattle >= 5) {
               this.kick();
            }
            this.sendTableMessage("\u0412\u044b \u043c\u043e\u0436\u0435\u0442\u0435 \u0441\u043e\u0437\u0434\u0430\u0432\u0430\u0442\u044c \u043d\u0435 \u0431\u043e\u043b\u0435\u0435 \u0442\u0440\u0435\u0445 \u0431\u0438\u0442\u0432 \u0432 \u0442\u0435\u0447\u0435\u043d\u0438\u0438 5 \u043c\u0438\u043d\u0443\u0442.");
            final AntiCheatData antiCheatData = this.localUser.getAntiCheatData();
            ++antiCheatData.countWarningForFludCreateBattle;
            return;
         }
      }
      else {
         this.localUser.getAntiCheatData().countCreatedBattles = 0;
         this.localUser.getAntiCheatData().countWarningForFludCreateBattle = 0;
      }
      final BattleInfo battle = new BattleInfo();
      final Map map = MapsLoader.maps.get(mapId);
      if (maxRang < minRang) {
         maxRang = minRang;
      }
      if (maxPlayers < 2) {
         maxPlayers = 2;
      }
      if (time <= 0 && kills <= 0) {
         time = 900;
         kills = 0;
      }
      if (maxPlayers > map.maxPlayers) {
         maxPlayers = map.maxPlayers;
      }
      if (kills > 999) {
         kills = 999;
      }
      battle.name = gameName;
      battle.map = MapsLoader.maps.get(mapId);
      battle.time = time;
      battle.numKills = kills;
      battle.maxPeople = maxPlayers;
      battle.minRank = minRang;
      battle.countPeople = 0;
      battle.maxRank = maxRang;
      battle.team = false;
      battle.isPrivate = isPrivate;
      battle.isPaid = pay;
      BattlesList.tryCreateBatle(battle);
      this.localUser.getAntiCheatData().lastTimeCreationBattle = System.currentTimeMillis();
      final AntiCheatData antiCheatData2 = this.localUser.getAntiCheatData();
      ++antiCheatData2.countCreatedBattles;
   }

   private void checkBattleName(final String name) {
      this.send(Type.LOBBY, "check_battle_name", name);
   }

   private void sendMapsInit() {
      this.localUser.setUserLocation(UserLocation.BATTLESELECT);
      this.send(Type.LOBBY, "init_battle_select", JSONUtils.parseBattleMapList());
   }

   private void sendFriend() {
      this.localUser.setUserLocation(UserLocation.ALL);
      this.send(Type.LOBBY, "init_f", JSONUtils.parseFriend(localUser.getFriend()));
   }

   private void sendGarage() {
      this.localUser.setUserLocation(UserLocation.GARAGE);
      this.send(Type.GARAGE, "init_garage_items", JSONUtils.parseGarageUser(this.localUser).trim());
      this.send(Type.GARAGE, "init_market", JSONUtils.parseMarketItems(this.localUser));
   }

   public synchronized void onTryUpdateItem(final String id) {
      final Item item = this.localUser.getGarage().getItemById(id.substring(0, id.length() - 3));
      final int modificationID = Integer.parseInt(id.substring(id.length() - 1));
      if (this.checkMoney(item.modifications[modificationID + 1].price)) {
         if (this.getLocalUser().getRang() + 1 < item.modifications[modificationID + 1].rank) {
            return;
         }
         if (this.localUser.getGarage().updateItem(id)) {
            this.send(Type.GARAGE, "update_item", id);
            this.addCrystall(-item.modifications[modificationID + 1].price);
            this.localUser.getGarage().parseJSONData();
            LobbyManager.database.update(this.localUser.getGarage());
         }
      }
      else {
         this.send(Type.GARAGE, "try_update_NO");
      }
   }

   public synchronized void onTryBuyItem(final String itemId, final int count) {
      if (count <= 0 || count > 9999) {
         this.crystallToZero();
         return;
      }
      final Item item = (Item)GarageItemsLoader.items.get(itemId.substring(0, itemId.length() - 3));
      Item fromUser = null;
      final int price = item.price * count;
      final int itemRang = item.modifications[0].rank;
      if (this.checkMoney(price)) {
         if (this.getLocalUser().getRang() + 1 < itemRang) {
            return;
         }
         if ((fromUser = this.localUser.getGarage().buyItem(itemId, count, 0)) != null) {
            this.send(Type.GARAGE, "buy_item", StringUtils.concatStrings(new String[] { item.id, "_m", String.valueOf(item.modificationIndex) }), JSONUtils.parseItemInfo(fromUser));
            this.addCrystall(-price);
            this.localUser.getGarage().parseJSONData();
            LobbyManager.database.update(this.localUser.getGarage());
         }
         else {
            this.send(Type.GARAGE, "try_buy_item_NO");
         }
      }
   }

   private boolean checkMoney(final int buyValue) {
      return this.localUser.getCrystall() - buyValue >= 0;
   }

   public synchronized void addCrystall(final int value) {
      this.localUser.addCrystall(value);
      this.send(Type.LOBBY, "add_crystall", String.valueOf(this.localUser.getCrystall()));
      LobbyManager.database.update(this.localUser);
   }

   public void crystallToZero() {
      this.localUser.setCrystall(0);
      this.send(Type.LOBBY, "add_crystall", String.valueOf(this.localUser.getCrystall()));
      LobbyManager.database.update(this.localUser);
   }

   private boolean stringToBoolean(final String src) {
      return src.toLowerCase().equals("true");
   }

   public void onDisconnect() {
      LobbyManager.database.uncache(this.localUser.getNickname());
      LobbyManager.lobbysServices.removeLobby(this);
      OnlineStats.removeOnline();
      if (this.spectatorController != null) {
         this.spectatorController.onDisconnect();
         this.spectatorController = null;
      }
      if (this.battle != null) {
         this.battle.onDisconnect();
         this.battle = null;
      }
      this.localUser.session = null;
   }

   public void kick() {
      this.networker.closeConnection();
   }

   public User getLocalUser() {
      return this.localUser;
   }

   public void setLocalUser(final User localUser) {
      this.localUser = localUser;
   }

   public FloodController getChatFloodController() {
      return this.chatFloodController;
   }

   public void setChatFloodController(final FloodController chatFloodController) {
      this.chatFloodController = chatFloodController;
   }
}