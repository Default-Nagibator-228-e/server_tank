//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package battles.maps;

import battles.maps.loaders.MapL;
import battles.maps.parser.Parser;
import battles.maps.parser.map.bonus.BonusRegion;
import battles.maps.parser.map.bonus.BonusType;
import battles.maps.parser.map.spawn.SpawnPosition;
import battles.maps.parser.map.spawn.SpawnPositionType;
import battles.maps.themes.MapThemeFactory;
import logger.Logger;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
//import javax.xml.bind.JAXBException;
import logger.remote.RemoteDatabaseLogger;
import main.Main;
import org.apache.commons.codec.digest.DigestUtils;
import org.hibernate.Session;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import services.hibernate.HibernateService;

public class MapsLoader {
   public static HashMap<String, Map> maps = new HashMap();
   private static ArrayList<IMapConfigItem> configItems = new ArrayList();
   private static Parser parser;

   public MapsLoader() {
   }

   public static void initFactoryMaps() {
      Logger.log("Maps Loader Factory inited. Loading maps...");

      try {
         parser = new Parser();
      } catch (Exception var1) {
         var1.printStackTrace();
      }

      loadConfig();
   }

   private static void loadConfig() {
      Session session = null;
      try {
         session = HibernateService.getSessionFactory().getCurrentSession();
         if(!session.getTransaction().isActive() || session.getTransaction() == null)
         {
            session.beginTransaction();
         }
         List<MapL> listmap = session.createQuery("from MapL").list();
         JSONParser mapsParser = new JSONParser();
         Object items = mapsParser.parse(new FileReader(new File(Main.pat + "maps/config.json")));
         JSONObject obj = (JSONObject)items;
         JSONArray jarray = (JSONArray)obj.get("maps");

         IMapConfigItem __item;
         for each(Iterator var5 = jarray.iterator(); var5.hasNext(); configItems.add(__item)) {
            Object objItem = var5.next();
            JSONObject item = (JSONObject)objItem;
            String id = (String)item.get("id");
            String name = (String)item.get("name");
            String skyboxId = (String)item.get("skybox_id");
            Object ambientSoundId = item.get("ambient_sound_id");
            Object gameModeId = item.get("gamemode_id");
            int minRank = Integer.parseInt((String)item.get("min_rank"));
            int maxRank = Integer.parseInt((String)item.get("max_rank"));
            int maxPlayers = Integer.parseInt((String)item.get("max_players"));
            boolean tdm = (Boolean)item.get("tdm");
            boolean ctf = (Boolean)item.get("ctf");
            Object themeId = item.get("theme_id");
            __item = ambientSoundId != null && gameModeId != null ? new IMapConfigItem(id, name, skyboxId, minRank, maxRank, maxPlayers, tdm, ctf, (String)ambientSoundId, (String)gameModeId) : new IMapConfigItem(id, name, skyboxId, minRank, maxRank, maxPlayers, tdm, ctf);
            if (themeId != null) {
               __item.themeName = (String)themeId;
            }
         }
         session.getTransaction().commit();
      } catch (Exception var7) {
         if(session.getTransaction() != null) {
            session.getTransaction().rollback();
         }

         var7.printStackTrace();
         RemoteDatabaseLogger.error(var7);
      }
         parseMaps();
   }

   private static void parseMaps() {
      File[] maps = (new File(Main.pat + "maps")).listFiles();
      File[] var4 = maps;
      int var3 = maps.length;

      for(int var2 = 0; var2 < var3; ++var2) {
         File file = var4[var2];
         if (!file.isDirectory() && file.getName().endsWith(".xml")) {
            parse(file);
         }
      }

      Logger.log("Loaded all maps!\n");
   }

   private static void parse(File file) {
      //Logger.log("Loading " + file.getName() + "...");
      IMapConfigItem temp = getMapItem(file.getName().substring(0, file.getName().length() - 4));
      if (temp != null) {
         Map map = null;

         try {
            map = new Map() {
               {
                  this.name = temp.name;
                  this.id = temp.id;
                  this.skyboxId = temp.skyboxId;
                  this.minRank = temp.minRank;
                  this.maxRank = temp.maxRank;
                  this.maxPlayers = temp.maxPlayers;
                  this.tdm = temp.tdm;
                  this.ctf = temp.ctf;
                  this.md5Hash = DigestUtils.md5Hex(new FileInputStream(file));
                  this.mapTheme = temp.ambientSoundId != null && temp.gameMode != null ? MapThemeFactory.getMapTheme(temp.ambientSoundId, temp.gameMode) : MapThemeFactory.getDefaultMapTheme();
                  this.themeId = temp.themeName;
               }
            };
         } catch (IOException var9) {
            var9.printStackTrace();
         }

         battles.maps.parser.map.Map parsedMap = null;

         try {
            parsedMap = parser.parseMap(file);
         } catch (Exception var8) {
            var8.printStackTrace();
         }

         Iterator var5 = parsedMap.getSpawnPositions().iterator();

         while(var5.hasNext()) {
            SpawnPosition sp = (SpawnPosition)(var5.next());
            if (sp.getSpawnPositionType() == SpawnPositionType.NONE) {
               map.spawnPositonsDM.add(sp.getVector3());
            }

            if (sp.getSpawnPositionType() == SpawnPositionType.RED) {
               map.spawnPositonsRed.add(sp.getVector3());
            }

            if (sp.getSpawnPositionType() == SpawnPositionType.BLUE) {
               map.spawnPositonsBlue.add(sp.getVector3());
            }
         }

         if (parsedMap.getBonusesRegion() != null) {
            var5 = parsedMap.getBonusesRegion().iterator();

            while(var5.hasNext()) {
               BonusRegion br = (BonusRegion)var5.next();
               Iterator var7 = br.getType().iterator();

               while(var7.hasNext()) {
                  BonusType type = (BonusType)var7.next();
                  if (type == BonusType.CRYSTALL) {
                     map.crystallsRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.CRYSTALL_100) {
                     map.goldsRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.ARMOR) {
                     map.armorsRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.DAMAGE) {
                     map.damagesRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.HEAL) {
                     map.healthsRegions.add(br.toServerBonusRegion());
                  } else if (type == BonusType.NITRO) {
                     map.nitrosRegions.add(br.toServerBonusRegion());
                  }
               }
            }
         }

         map.flagBluePosition = parsedMap.getPositionBlueFlag() != null ? parsedMap.getPositionBlueFlag().toVector3() : null;
         map.flagRedPosition = parsedMap.getPositionRedFlag() != null ? parsedMap.getPositionRedFlag().toVector3() : null;
         if (map.flagBluePosition != null) {
            map.flagBluePosition.z += 50.0F;
            map.flagRedPosition.z += 50.0F;
         }

         maps.put(map.id, map);
      }
   }

   private static IMapConfigItem getMapItem(String id) {
      Iterator var2 = configItems.iterator();

      while(var2.hasNext()) {
         IMapConfigItem item = (IMapConfigItem)var2.next();
         if (item.id.equals(id)) {
            return item;
         }
      }

      return null;
   }
}
