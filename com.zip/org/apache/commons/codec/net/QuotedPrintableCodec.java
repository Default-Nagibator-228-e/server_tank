package org.apache.commons.codec.net;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.BitSet;
import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.StringDecoder;
import org.apache.commons.codec.StringEncoder;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.codec.net.Utils;

public class QuotedPrintableCodec implements BinaryEncoder, BinaryDecoder, StringEncoder, StringDecoder {
   private final String charset;
   private static final BitSet PRINTABLE_CHARS = new BitSet(256);
   private static final byte ESCAPE_CHAR = 61;
   private static final byte TAB = 9;
   private static final byte SPACE = 32;

   public QuotedPrintableCodec() {
      this("UTF-8");
   }

   public QuotedPrintableCodec(String charset) {
      this.charset = charset;
   }

   private static final void encodeQuotedPrintable(int b, ByteArrayOutputStream buffer) {
      buffer.write(61);
      char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 15, 16));
      char hex2 = Character.toUpperCase(Character.forDigit(b & 15, 16));
      buffer.write(hex1);
      buffer.write(hex2);
   }

   public static final byte[] encodeQuotedPrintable(BitSet printable, byte[] bytes) {
      if(bytes == null) {
         return null;
      } else {
         if(printable == null) {
            printable = PRINTABLE_CHARS;
         }

         ByteArrayOutputStream buffer = new ByteArrayOutputStream();

         for(int i = 0; i < bytes.length; ++i) {
            int b = bytes[i];
            if(b < 0) {
               b += 256;
            }

            if(printable.get(b)) {
               buffer.write(b);
            } else {
               encodeQuotedPrintable(b, buffer);
            }
         }

         return buffer.toByteArray();
      }
   }

   public static final byte[] decodeQuotedPrintable(byte[] bytes) throws DecoderException {
      if(bytes == null) {
         return null;
      } else {
         ByteArrayOutputStream buffer = new ByteArrayOutputStream();

         for(int i = 0; i < bytes.length; ++i) {
            byte b = bytes[i];
            if(b == 61) {
               try {
                  ++i;
                  int e = Utils.digit16(bytes[i]);
                  ++i;
                  int l = Utils.digit16(bytes[i]);
                  buffer.write((char)((e << 4) + l));
               } catch (ArrayIndexOutOfBoundsException var6) {
                  throw new DecoderException("Invalid quoted-printable encoding", var6);
               }
            } else {
               buffer.write(b);
            }
         }

         return buffer.toByteArray();
      }
   }

   public byte[] encode(byte[] bytes) {
      return encodeQuotedPrintable(PRINTABLE_CHARS, bytes);
   }

   public byte[] decode(byte[] bytes) throws DecoderException {
      return decodeQuotedPrintable(bytes);
   }

   public String encode(String pString) throws EncoderException {
      if(pString == null) {
         return null;
      } else {
         try {
            return this.encode(pString, this.getDefaultCharset());
         } catch (UnsupportedEncodingException var3) {
            throw new EncoderException(var3.getMessage(), var3);
         }
      }
   }

   public String decode(String pString, String charset) throws DecoderException, UnsupportedEncodingException {
      return pString == null?null:new String(this.decode(StringUtils.getBytesUsAscii(pString)), charset);
   }

   public String decode(String pString) throws DecoderException {
      if(pString == null) {
         return null;
      } else {
         try {
            return this.decode(pString, this.getDefaultCharset());
         } catch (UnsupportedEncodingException var3) {
            throw new DecoderException(var3.getMessage(), var3);
         }
      }
   }

   public Object encode(Object pObject) throws EncoderException {
      if(pObject == null) {
         return null;
      } else if(pObject instanceof byte[]) {
         return this.encode((byte[])((byte[])pObject));
      } else if(pObject instanceof String) {
         return this.encode((String)pObject);
      } else {
         throw new EncoderException("Objects of type " + pObject.getClass().getName() + " cannot be quoted-printable encoded");
      }
   }

   public Object decode(Object pObject) throws DecoderException {
      if(pObject == null) {
         return null;
      } else if(pObject instanceof byte[]) {
         return this.decode((byte[])((byte[])pObject));
      } else if(pObject instanceof String) {
         return this.decode((String)pObject);
      } else {
         throw new DecoderException("Objects of type " + pObject.getClass().getName() + " cannot be quoted-printable decoded");
      }
   }

   public String getDefaultCharset() {
      return this.charset;
   }

   public String encode(String pString, String charset) throws UnsupportedEncodingException {
      return pString == null?null:StringUtils.newStringUsAscii(this.encode(pString.getBytes(charset)));
   }

   static {
      int i;
      for(i = 33; i <= 60; ++i) {
         PRINTABLE_CHARS.set(i);
      }

      for(i = 62; i <= 126; ++i) {
         PRINTABLE_CHARS.set(i);
      }

      PRINTABLE_CHARS.set(9);
      PRINTABLE_CHARS.set(32);
   }
}
