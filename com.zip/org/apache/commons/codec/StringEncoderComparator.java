package org.apache.commons.codec;

import java.util.Comparator;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.StringEncoder;

public class StringEncoderComparator implements Comparator {
   private final StringEncoder stringEncoder;

   /** @deprecated */
   public StringEncoderComparator() {
      this.stringEncoder = null;
   }

   public StringEncoderComparator(StringEncoder stringEncoder) {
      this.stringEncoder = stringEncoder;
   }

   public int compare(Object o1, Object o2) {
      boolean compareCode = false;

      int compareCode1;
      try {
         Comparable ee = (Comparable)this.stringEncoder.encode(o1);
         Comparable s2 = (Comparable)this.stringEncoder.encode(o2);
         compareCode1 = ee.compareTo(s2);
      } catch (EncoderException var6) {
         compareCode1 = 0;
      }

      return compareCode1;
   }
}
