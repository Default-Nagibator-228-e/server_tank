package org.apache.commons.codec;

import org.apache.commons.codec.DecoderException;

public interface Decoder {
   Object decode(Object var1) throws DecoderException;
}
