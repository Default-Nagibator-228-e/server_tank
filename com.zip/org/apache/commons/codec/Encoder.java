package org.apache.commons.codec;

import org.apache.commons.codec.EncoderException;

public interface Encoder {
   Object encode(Object var1) throws EncoderException;
}
