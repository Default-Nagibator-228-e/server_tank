package org.dom4j;

import org.dom4j.ElementPath;

public interface ElementHandler {
   void onStart(ElementPath var1);

   void onEnd(ElementPath var1);
}
