package org.dom4j;

import org.dom4j.CharacterData;

public interface Comment extends CharacterData {
}
