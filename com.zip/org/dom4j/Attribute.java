package org.dom4j;

import org.dom4j.Namespace;
import org.dom4j.Node;
import org.dom4j.QName;

public interface Attribute extends Node {
   QName getQName();

   Namespace getNamespace();

   void setNamespace(Namespace var1);

   String getNamespacePrefix();

   String getNamespaceURI();

   String getQualifiedName();

   String getValue();

   void setValue(String var1);

   Object getData();

   void setData(Object var1);
}
