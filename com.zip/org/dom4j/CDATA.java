package org.dom4j;

import org.dom4j.CharacterData;

public interface CDATA extends CharacterData {
}
