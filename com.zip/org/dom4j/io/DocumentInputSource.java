package org.dom4j.io;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import org.dom4j.Document;
import org.dom4j.io.XMLWriter;
import org.xml.sax.InputSource;

class DocumentInputSource extends InputSource {
   private Document document;

   public DocumentInputSource() {
   }

   public DocumentInputSource(Document document) {
      this.document = document;
      this.setSystemId(document.getName());
   }

   public Document getDocument() {
      return this.document;
   }

   public void setDocument(Document document) {
      this.document = document;
      this.setSystemId(document.getName());
   }

   public void setCharacterStream(Reader characterStream) throws UnsupportedOperationException {
      throw new UnsupportedOperationException();
   }

   public Reader getCharacterStream() {
      try {
         StringWriter e = new StringWriter();
         XMLWriter writer = new XMLWriter(e);
         writer.write(this.document);
         writer.flush();
         return new StringReader(e.toString());
      } catch (final IOException var3) {
         return new Reader() {
            public int read(char[] ch, int offset, int length) throws IOException {
               throw var3;
            }

            public void close() throws IOException {
            }
         };
      }
   }
}
