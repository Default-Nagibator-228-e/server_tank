package org.dom4j.dom;

import java.util.Map;
import org.dom4j.Attribute;
import org.dom4j.CDATA;
import org.dom4j.Comment;
import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.DocumentType;
import org.dom4j.Element;
import org.dom4j.Entity;
import org.dom4j.Namespace;
import org.dom4j.ProcessingInstruction;
import org.dom4j.QName;
import org.dom4j.Text;
import org.dom4j.dom.DOMAttribute;
import org.dom4j.dom.DOMCDATA;
import org.dom4j.dom.DOMComment;
import org.dom4j.dom.DOMDocument;
import org.dom4j.dom.DOMDocumentType;
import org.dom4j.dom.DOMElement;
import org.dom4j.dom.DOMEntityReference;
import org.dom4j.dom.DOMNamespace;
import org.dom4j.dom.DOMProcessingInstruction;
import org.dom4j.dom.DOMText;
import org.dom4j.util.SingletonStrategy;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;

public class DOMDocumentFactory extends DocumentFactory implements DOMImplementation {
   private static SingletonStrategy singleton = null;
   // $FF: synthetic field
   static Class class$org$dom4j$dom$DOMDocumentFactory;

   public static DocumentFactory getInstance() {
      DOMDocumentFactory fact = (DOMDocumentFactory)singleton.instance();
      return fact;
   }

   public Document createDocument() {
      DOMDocument answer = new DOMDocument();
      answer.setDocumentFactory(this);
      return answer;
   }

   public DocumentType createDocType(String name, String publicId, String systemId) {
      return new DOMDocumentType(name, publicId, systemId);
   }

   public Element createElement(QName qname) {
      return new DOMElement(qname);
   }

   public Element createElement(QName qname, int attributeCount) {
      return new DOMElement(qname, attributeCount);
   }

   public Attribute createAttribute(Element owner, QName qname, String value) {
      return new DOMAttribute(qname, value);
   }

   public CDATA createCDATA(String text) {
      return new DOMCDATA(text);
   }

   public Comment createComment(String text) {
      return new DOMComment(text);
   }

   public Text createText(String text) {
      return new DOMText(text);
   }

   public Entity createEntity(String name) {
      return new DOMEntityReference(name);
   }

   public Entity createEntity(String name, String text) {
      return new DOMEntityReference(name, text);
   }

   public Namespace createNamespace(String prefix, String uri) {
      return new DOMNamespace(prefix, uri);
   }

   public ProcessingInstruction createProcessingInstruction(String target, String data) {
      return new DOMProcessingInstruction(target, data);
   }

   public ProcessingInstruction createProcessingInstruction(String target, Map data) {
      return new DOMProcessingInstruction(target, data);
   }

   public boolean hasFeature(String feat, String version) {
      return !"XML".equalsIgnoreCase(feat) && !"Core".equalsIgnoreCase(feat)?false:version == null || version.length() == 0 || "1.0".equals(version) || "2.0".equals(version);
   }

   public org.w3c.dom.DocumentType createDocumentType(String qualifiedName, String publicId, String systemId) throws DOMException {
      return new DOMDocumentType(qualifiedName, publicId, systemId);
   }

   public org.w3c.dom.Document createDocument(String namespaceURI, String qualifiedName, org.w3c.dom.DocumentType docType) throws DOMException {
      DOMDocument document;
      if(docType != null) {
         DOMDocumentType documentType = this.asDocumentType(docType);
         document = new DOMDocument(documentType);
      } else {
         document = new DOMDocument();
      }

      document.addElement(this.createQName(qualifiedName, namespaceURI));
      return document;
   }

   protected DOMDocumentType asDocumentType(org.w3c.dom.DocumentType docType) {
      return docType instanceof DOMDocumentType?(DOMDocumentType)docType:new DOMDocumentType(docType.getName(), docType.getPublicId(), docType.getSystemId());
   }

   // $FF: synthetic method
   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

   static {
      try {
         String exc3 = "org.dom4j.util.SimpleSingleton";
         Class clazz = null;

         try {
            String exc1 = System.getProperty("org.dom4j.dom.DOMDocumentFactory.singleton.strategy", exc3);
            clazz = Class.forName(exc1);
         } catch (Exception var5) {
            try {
               clazz = Class.forName(exc3);
            } catch (Exception var4) {
               ;
            }
         }

         singleton = (SingletonStrategy)clazz.newInstance();
         singleton.setSingletonClassName((class$org$dom4j$dom$DOMDocumentFactory == null?(class$org$dom4j$dom$DOMDocumentFactory = class$("org.dom4j.dom.DOMDocumentFactory")):class$org$dom4j$dom$DOMDocumentFactory).getName());
      } catch (Exception var6) {
         ;
      }

   }
}
