package org.dom4j;

import org.dom4j.Node;

public interface Entity extends Node {
}
