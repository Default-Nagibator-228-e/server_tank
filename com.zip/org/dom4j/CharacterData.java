package org.dom4j;

import org.dom4j.Node;

public interface CharacterData extends Node {
   void appendText(String var1);
}
