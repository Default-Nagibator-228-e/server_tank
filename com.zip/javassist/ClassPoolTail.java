package javassist;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.Hashtable;
import javassist.CannotCompileException;
import javassist.ClassClassPath;
import javassist.ClassPath;
import javassist.ClassPathList;
import javassist.DirClassPath;
import javassist.JarClassPath;
import javassist.NotFoundException;

final class ClassPoolTail {
   protected ClassPathList pathList = null;
   private Hashtable packages = new Hashtable();

   public String toString() {
      StringBuffer buf = new StringBuffer();
      buf.append("[class path: ");

      for(ClassPathList list = this.pathList; list != null; list = list.next) {
         buf.append(list.path.toString());
         buf.append(File.pathSeparatorChar);
      }

      buf.append(']');
      return buf.toString();
   }

   public synchronized ClassPath insertClassPath(ClassPath cp) {
      this.pathList = new ClassPathList(cp, this.pathList);
      return cp;
   }

   public synchronized ClassPath appendClassPath(ClassPath cp) {
      ClassPathList tail = new ClassPathList(cp, (ClassPathList)null);
      ClassPathList list = this.pathList;
      if(list == null) {
         this.pathList = tail;
      } else {
         while(true) {
            if(list.next == null) {
               list.next = tail;
               break;
            }

            list = list.next;
         }
      }

      return cp;
   }

   public synchronized void removeClassPath(ClassPath cp) {
      ClassPathList list = this.pathList;
      if(list != null) {
         if(list.path == cp) {
            this.pathList = list.next;
         } else {
            while(list.next != null) {
               if(list.next.path == cp) {
                  list.next = list.next.next;
               } else {
                  list = list.next;
               }
            }
         }
      }

      cp.close();
   }

   public ClassPath appendSystemPath() {
      return this.appendClassPath((ClassPath)(new ClassClassPath()));
   }

   public ClassPath insertClassPath(String pathname) throws NotFoundException {
      return this.insertClassPath(makePathObject(pathname));
   }

   public ClassPath appendClassPath(String pathname) throws NotFoundException {
      return this.appendClassPath(makePathObject(pathname));
   }

   private static ClassPath makePathObject(String pathname) throws NotFoundException {
      int i = pathname.lastIndexOf(46);
      if(i >= 0) {
         String ext = pathname.substring(i).toLowerCase();
         if(ext.equals(".jar") || ext.equals(".zip")) {
            return new JarClassPath(pathname);
         }
      }

      return new DirClassPath(pathname);
   }

   public void recordInvalidClassName(String name) {
      this.packages.put(name, name);
   }

   void writeClassfile(String classname, OutputStream out) throws NotFoundException, IOException, CannotCompileException {
      InputStream fin = this.openClassfile(classname);
      if(fin == null) {
         throw new NotFoundException(classname);
      } else {
         try {
            copyStream(fin, out);
         } finally {
            fin.close();
         }

      }
   }

   InputStream openClassfile(String classname) throws NotFoundException {
      if(this.packages.get(classname) != null) {
         return null;
      } else {
         ClassPathList list = this.pathList;
         InputStream ins = null;

         NotFoundException error;
         for(error = null; list != null; list = list.next) {
            try {
               ins = list.path.openClassfile(classname);
            } catch (NotFoundException var6) {
               if(error == null) {
                  error = var6;
               }
            }

            if(ins != null) {
               return ins;
            }
         }

         if(error != null) {
            throw error;
         } else {
            return null;
         }
      }
   }

   public URL find(String classname) {
      if(this.packages.get(classname) != null) {
         return null;
      } else {
         ClassPathList list = this.pathList;

         for(URL url = null; list != null; list = list.next) {
            url = list.path.find(classname);
            if(url != null) {
               return url;
            }
         }

         return null;
      }
   }

   public static byte[] readStream(InputStream fin) throws IOException {
      byte[][] bufs = new byte[8][];
      int bufsize = 4096;

      for(int i = 0; i < 8; ++i) {
         bufs[i] = new byte[bufsize];
         int size = 0;
         boolean len = false;

         do {
            int var9 = fin.read(bufs[i], size, bufsize - size);
            if(var9 < 0) {
               byte[] result = new byte[bufsize - 4096 + size];
               int s = 0;

               for(int j = 0; j < i; ++j) {
                  System.arraycopy(bufs[j], 0, result, s, s + 4096);
                  s = s + s + 4096;
               }

               System.arraycopy(bufs[i], 0, result, s, size);
               return result;
            }

            size += var9;
         } while(size < bufsize);

         bufsize *= 2;
      }

      throw new IOException("too much data");
   }

   public static void copyStream(InputStream fin, OutputStream fout) throws IOException {
      int bufsize = 4096;

      for(int i = 0; i < 8; ++i) {
         byte[] buf = new byte[bufsize];
         int size = 0;
         boolean len = false;

         do {
            int var7 = fin.read(buf, size, bufsize - size);
            if(var7 < 0) {
               fout.write(buf, 0, size);
               return;
            }

            size += var7;
         } while(size < bufsize);

         fout.write(buf);
         bufsize *= 2;
      }

      throw new IOException("too much data");
   }
}
