package javassist.convert;

import javassist.CtClass;
import javassist.CtMethod;
import javassist.Modifier;
import javassist.bytecode.BadBytecode;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.CodeIterator;
import javassist.bytecode.ConstPool;
import javassist.convert.Transformer;

public class TransformCall extends Transformer {
   protected String classname;
   protected String methodname;
   protected String methodDescriptor;
   protected String newClassname;
   protected String newMethodname;
   protected boolean newMethodIsPrivate;
   protected int newIndex;
   protected ConstPool constPool;

   public TransformCall(Transformer next, CtMethod origMethod, CtMethod substMethod) {
      this(next, origMethod.getName(), substMethod);
      this.classname = origMethod.getDeclaringClass().getName();
   }

   public TransformCall(Transformer next, String oldMethodName, CtMethod substMethod) {
      super(next);
      this.methodname = oldMethodName;
      this.methodDescriptor = substMethod.getMethodInfo2().getDescriptor();
      this.classname = this.newClassname = substMethod.getDeclaringClass().getName();
      this.newMethodname = substMethod.getName();
      this.constPool = null;
      this.newMethodIsPrivate = Modifier.isPrivate(substMethod.getModifiers());
   }

   public void initialize(ConstPool cp, CodeAttribute attr) {
      if(this.constPool != cp) {
         this.newIndex = 0;
      }

   }

   public int transform(CtClass clazz, int pos, CodeIterator iterator, ConstPool cp) throws BadBytecode {
      int c = iterator.byteAt(pos);
      if(c == 185 || c == 183 || c == 184 || c == 182) {
         int index = iterator.u16bitAt(pos + 1);
         int typedesc = cp.isMember(this.classname, this.methodname, index);
         if(typedesc != 0 && cp.getUtf8Info(typedesc).equals(this.methodDescriptor)) {
            pos = this.match(c, pos, iterator, typedesc, cp);
         }
      }

      return pos;
   }

   protected int match(int c, int pos, CodeIterator iterator, int typedesc, ConstPool cp) throws BadBytecode {
      if(this.newIndex == 0) {
         int nt = cp.addNameAndTypeInfo(cp.addUtf8Info(this.newMethodname), typedesc);
         int ci = cp.addClassInfo(this.newClassname);
         if(c == 185) {
            this.newIndex = cp.addInterfaceMethodrefInfo(ci, nt);
         } else {
            if(this.newMethodIsPrivate && c == 182) {
               iterator.writeByte(183, pos);
            }

            this.newIndex = cp.addMethodrefInfo(ci, nt);
         }

         this.constPool = cp;
      }

      iterator.write16bit(this.newIndex, pos + 1);
      return pos;
   }
}
