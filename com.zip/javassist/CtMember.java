package javassist;

import javassist.CtClass;
import javassist.Modifier;

public abstract class CtMember {
   protected CtMember next;
   protected CtClass declaringClass;

   protected CtMember(CtClass clazz) {
      this.declaringClass = clazz;
   }

   static CtMember append(CtMember list, CtMember previousTail, CtMember tail) {
      tail.next = null;
      if(list == null) {
         return tail;
      } else {
         previousTail.next = tail;
         return list;
      }
   }

   static CtMember append(CtMember list, CtMember tail) {
      tail.next = null;
      if(list == null) {
         return tail;
      } else {
         CtMember lst;
         for(lst = list; lst.next != null; lst = lst.next) {
            ;
         }

         lst.next = tail;
         return list;
      }
   }

   static int count(CtMember f) {
      int n;
      for(n = 0; f != null; f = f.next) {
         ++n;
      }

      return n;
   }

   static CtMember remove(CtMember list, CtMember m) {
      CtMember top = list;
      if(list == null) {
         return null;
      } else if(list == m) {
         return list.next;
      } else {
         while(list.next != null) {
            if(list.next == m) {
               list.next = list.next.next;
               break;
            }

            list = list.next;
         }

         return top;
      }
   }

   public String toString() {
      StringBuffer buffer = new StringBuffer(this.getClass().getName());
      buffer.append("@");
      buffer.append(Integer.toHexString(this.hashCode()));
      buffer.append("[");
      buffer.append(Modifier.toString(this.getModifiers()));
      this.extendToString(buffer);
      buffer.append("]");
      return buffer.toString();
   }

   protected abstract void extendToString(StringBuffer var1);

   public CtClass getDeclaringClass() {
      return this.declaringClass;
   }

   public boolean visibleFrom(CtClass clazz) {
      int mod = this.getModifiers();
      if(Modifier.isPublic(mod)) {
         return true;
      } else if(Modifier.isPrivate(mod)) {
         return clazz == this.declaringClass;
      } else {
         String declName = this.declaringClass.getPackageName();
         String fromName = clazz.getPackageName();
         boolean visible;
         if(declName == null) {
            visible = fromName == null;
         } else {
            visible = declName.equals(fromName);
         }

         return !visible && Modifier.isProtected(mod)?clazz.subclassOf(this.declaringClass):visible;
      }
   }

   public abstract int getModifiers();

   public abstract void setModifiers(int var1);

   public abstract Object[] getAnnotations() throws ClassNotFoundException;

   public abstract Object[] getAvailableAnnotations() throws ClassNotFoundException;

   public abstract String getName();

   public abstract String getSignature();

   public abstract byte[] getAttribute(String var1);

   public abstract void setAttribute(String var1, byte[] var2);
}
