package javassist.scopedpool;

import javassist.ClassPool;
import javassist.scopedpool.ScopedClassPool;
import javassist.scopedpool.ScopedClassPoolFactory;
import javassist.scopedpool.ScopedClassPoolRepository;

public class ScopedClassPoolFactoryImpl implements ScopedClassPoolFactory {
   public ScopedClassPool create(ClassLoader cl, ClassPool src, ScopedClassPoolRepository repository) {
      return new ScopedClassPool(cl, src, repository);
   }

   public ScopedClassPool create(ClassPool src, ScopedClassPoolRepository repository) {
      return new ScopedClassPool((ClassLoader)null, src, repository);
   }
}
