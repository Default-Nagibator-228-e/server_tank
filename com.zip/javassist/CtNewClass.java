package javassist;

import java.io.DataOutputStream;
import java.io.IOException;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtClassType;
import javassist.CtConstructor;
import javassist.CtNewConstructor;
import javassist.Modifier;
import javassist.NotFoundException;
import javassist.bytecode.ClassFile;

class CtNewClass extends CtClassType {
   protected boolean hasConstructor;

   CtNewClass(String name, ClassPool cp, boolean isInterface, CtClass superclass) {
      super(name, cp);
      this.wasChanged = true;
      this.eraseCache();
      String superName;
      if(superclass == null) {
         superName = null;
      } else {
         superName = superclass.getName();
      }

      this.classfile = new ClassFile(isInterface, name, superName);
      this.setModifiers(Modifier.setPublic(this.getModifiers()));
      this.hasConstructor = isInterface;
   }

   protected void extendToString(StringBuffer buffer) {
      if(this.hasConstructor) {
         buffer.append("hasConstructor ");
      }

      super.extendToString(buffer);
   }

   public void addConstructor(CtConstructor c) throws CannotCompileException {
      this.hasConstructor = true;
      super.addConstructor(c);
   }

   public void toBytecode(DataOutputStream out) throws CannotCompileException, IOException {
      if(!this.hasConstructor) {
         try {
            this.inheritAllConstructors();
            this.hasConstructor = true;
         } catch (NotFoundException var3) {
            throw new CannotCompileException(var3);
         }
      }

      super.toBytecode(out);
   }

   public void inheritAllConstructors() throws CannotCompileException, NotFoundException {
      CtClass superclazz = this.getSuperclass();
      CtConstructor[] cs = superclazz.getDeclaredConstructors();
      int n = 0;

      for(int i = 0; i < cs.length; ++i) {
         CtConstructor c = cs[i];
         if(Modifier.isPublic(c.getModifiers())) {
            CtConstructor cons = CtNewConstructor.make(c.getParameterTypes(), c.getExceptionTypes(), this);
            this.addConstructor(cons);
            ++n;
         }
      }

      if(n < 1) {
         throw new CannotCompileException("no public constructor in " + superclazz.getName());
      }
   }
}
