package javassist;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Comparator;
import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtField;
import javassist.CtMethod;
import javassist.NotFoundException;
import javassist.bytecode.ClassFile;
import javassist.bytecode.Descriptor;

public class SerialVersionUID {
   public static void setSerialVersionUID(CtClass clazz) throws CannotCompileException, NotFoundException {
      try {
         clazz.getDeclaredField("serialVersionUID");
      } catch (NotFoundException var2) {
         if(isSerializable(clazz)) {
            CtField field = new CtField(CtClass.longType, "serialVersionUID", clazz);
            field.setModifiers(26);
            clazz.addField(field, calculateDefault(clazz) + "L");
         }
      }
   }

   private static boolean isSerializable(CtClass clazz) throws NotFoundException {
      ClassPool pool = clazz.getClassPool();
      return clazz.subtypeOf(pool.get("java.io.Serializable"));
   }

   static long calculateDefault(CtClass clazz) throws CannotCompileException {
      try {
         ByteArrayOutputStream e = new ByteArrayOutputStream();
         DataOutputStream out = new DataOutputStream(e);
         ClassFile classFile = clazz.getClassFile();
         String javaName = javaName(clazz);
         out.writeUTF(javaName);
         out.writeInt(clazz.getModifiers() & 1553);
         String[] interfaces = classFile.getInterfaces();

         int fields;
         for(fields = 0; fields < interfaces.length; ++fields) {
            interfaces[fields] = javaName(interfaces[fields]);
         }

         Arrays.sort(interfaces);

         for(fields = 0; fields < interfaces.length; ++fields) {
            out.writeUTF(interfaces[fields]);
         }

         CtField[] var16 = clazz.getDeclaredFields();
         Arrays.sort(var16, new Comparator() {
            public int compare(Object o1, Object o2) {
               CtField field1 = (CtField)o1;
               CtField field2 = (CtField)o2;
               return field1.getName().compareTo(field2.getName());
            }
         });

         int digest;
         for(int constructors = 0; constructors < var16.length; ++constructors) {
            CtField methods = var16[constructors];
            digest = methods.getModifiers();
            if((digest & 2) == 0 || (digest & 136) == 0) {
               out.writeUTF(methods.getName());
               out.writeInt(digest);
               out.writeUTF(methods.getFieldInfo2().getDescriptor());
            }
         }

         if(classFile.getStaticInitializer() != null) {
            out.writeUTF("<clinit>");
            out.writeInt(8);
            out.writeUTF("()V");
         }

         CtConstructor[] var17 = clazz.getDeclaredConstructors();
         Arrays.sort(var17, new Comparator() {
            public int compare(Object o1, Object o2) {
               CtConstructor c1 = (CtConstructor)o1;
               CtConstructor c2 = (CtConstructor)o2;
               return c1.getMethodInfo2().getDescriptor().compareTo(c2.getMethodInfo2().getDescriptor());
            }
         });

         for(int var18 = 0; var18 < var17.length; ++var18) {
            CtConstructor var20 = var17[var18];
            int digested = var20.getModifiers();
            if((digested & 2) == 0) {
               out.writeUTF("<init>");
               out.writeInt(digested);
               out.writeUTF(var20.getMethodInfo2().getDescriptor().replace('/', '.'));
            }
         }

         CtMethod[] var19 = clazz.getDeclaredMethods();
         Arrays.sort(var19, new Comparator() {
            public int compare(Object o1, Object o2) {
               CtMethod m1 = (CtMethod)o1;
               CtMethod m2 = (CtMethod)o2;
               int value = m1.getName().compareTo(m2.getName());
               if(value == 0) {
                  value = m1.getMethodInfo2().getDescriptor().compareTo(m2.getMethodInfo2().getDescriptor());
               }

               return value;
            }
         });

         for(digest = 0; digest < var19.length; ++digest) {
            CtMethod var22 = var19[digest];
            int hash = var22.getModifiers();
            if((hash & 2) == 0) {
               out.writeUTF(var22.getName());
               out.writeInt(hash);
               out.writeUTF(var22.getMethodInfo2().getDescriptor().replace('/', '.'));
            }
         }

         out.flush();
         MessageDigest var21 = MessageDigest.getInstance("SHA");
         byte[] var23 = var21.digest(e.toByteArray());
         long var24 = 0L;

         for(int i = Math.min(var23.length, 8) - 1; i >= 0; --i) {
            var24 = var24 << 8 | (long)(var23[i] & 255);
         }

         return var24;
      } catch (IOException var14) {
         throw new CannotCompileException(var14);
      } catch (NoSuchAlgorithmException var15) {
         throw new CannotCompileException(var15);
      }
   }

   private static String javaName(CtClass clazz) {
      return Descriptor.toJavaName(Descriptor.toJvmName(clazz));
   }

   private static String javaName(String name) {
      return Descriptor.toJavaName(Descriptor.toJvmName(name));
   }
}
