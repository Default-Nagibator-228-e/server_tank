package javassist.tools.reflect;

import javassist.tools.reflect.ClassMetaobject;
import javassist.tools.reflect.Metaobject;

public interface Metalevel {
   ClassMetaobject _getClass();

   Metaobject _getMetaobject();

   void _setMetaobject(Metaobject var1);
}
