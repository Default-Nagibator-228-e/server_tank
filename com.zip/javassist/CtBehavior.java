package javassist;

import javassist.CannotCompileException;
import javassist.ClassMap;
import javassist.ClassPool;
import javassist.CodeConverter;
import javassist.CtClass;
import javassist.CtClassType;
import javassist.CtField;
import javassist.CtMember;
import javassist.CtPrimitiveType;
import javassist.Modifier;
import javassist.NotFoundException;
import javassist.bytecode.AccessFlag;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.BadBytecode;
import javassist.bytecode.Bytecode;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.CodeIterator;
import javassist.bytecode.ConstPool;
import javassist.bytecode.Descriptor;
import javassist.bytecode.ExceptionsAttribute;
import javassist.bytecode.LineNumberAttribute;
import javassist.bytecode.LocalVariableAttribute;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.ParameterAnnotationsAttribute;
import javassist.compiler.CompileError;
import javassist.compiler.Javac;
import javassist.expr.ExprEditor;

public abstract class CtBehavior extends CtMember {
   protected MethodInfo methodInfo;

   protected CtBehavior(CtClass clazz, MethodInfo minfo) {
      super(clazz);
      this.methodInfo = minfo;
   }

   void copy(CtBehavior src, boolean isCons, ClassMap map) throws CannotCompileException {
      CtClass declaring = this.declaringClass;
      MethodInfo srcInfo = src.methodInfo;
      CtClass srcClass = src.getDeclaringClass();
      ConstPool cp = declaring.getClassFile2().getConstPool();
      map = new ClassMap(map);
      map.put(srcClass.getName(), declaring.getName());

      try {
         boolean e = false;
         CtClass srcSuper = srcClass.getSuperclass();
         CtClass destSuper = declaring.getSuperclass();
         String destSuperName = null;
         if(srcSuper != null && destSuper != null) {
            String srcSuperName = srcSuper.getName();
            destSuperName = destSuper.getName();
            if(!srcSuperName.equals(destSuperName)) {
               if(srcSuperName.equals("java.lang.Object")) {
                  e = true;
               } else {
                  map.put(srcSuperName, destSuperName);
               }
            }
         }

         this.methodInfo = new MethodInfo(cp, srcInfo.getName(), srcInfo, map);
         if(isCons && e) {
            this.methodInfo.setSuperclass(destSuperName);
         }

      } catch (NotFoundException var13) {
         throw new CannotCompileException(var13);
      } catch (BadBytecode var14) {
         throw new CannotCompileException(var14);
      }
   }

   protected void extendToString(StringBuffer buffer) {
      buffer.append(' ');
      buffer.append(this.getName());
      buffer.append(' ');
      buffer.append(this.methodInfo.getDescriptor());
   }

   public MethodInfo getMethodInfo() {
      this.declaringClass.checkModify();
      return this.methodInfo;
   }

   public MethodInfo getMethodInfo2() {
      return this.methodInfo;
   }

   public int getModifiers() {
      return AccessFlag.toModifier(this.methodInfo.getAccessFlags());
   }

   public void setModifiers(int mod) {
      this.declaringClass.checkModify();
      this.methodInfo.setAccessFlags(AccessFlag.of(mod));
   }

   public Object[] getAnnotations() throws ClassNotFoundException {
      return this.getAnnotations(false);
   }

   public Object[] getAvailableAnnotations() {
      try {
         return this.getAnnotations(true);
      } catch (ClassNotFoundException var2) {
         throw new RuntimeException("Unexpected exception", var2);
      }
   }

   private Object[] getAnnotations(boolean ignoreNotFound) throws ClassNotFoundException {
      MethodInfo mi = this.getMethodInfo2();
      AnnotationsAttribute ainfo = (AnnotationsAttribute)mi.getAttribute("RuntimeInvisibleAnnotations");
      AnnotationsAttribute ainfo2 = (AnnotationsAttribute)mi.getAttribute("RuntimeVisibleAnnotations");
      return CtClassType.toAnnotationType(ignoreNotFound, this.getDeclaringClass().getClassPool(), ainfo, ainfo2);
   }

   public Object[][] getParameterAnnotations() throws ClassNotFoundException {
      return this.getParameterAnnotations(false);
   }

   public Object[][] getAvailableParameterAnnotations() {
      try {
         return this.getParameterAnnotations(true);
      } catch (ClassNotFoundException var2) {
         throw new RuntimeException("Unexpected exception", var2);
      }
   }

   Object[][] getParameterAnnotations(boolean ignoreNotFound) throws ClassNotFoundException {
      MethodInfo mi = this.getMethodInfo2();
      ParameterAnnotationsAttribute ainfo = (ParameterAnnotationsAttribute)mi.getAttribute("RuntimeInvisibleParameterAnnotations");
      ParameterAnnotationsAttribute ainfo2 = (ParameterAnnotationsAttribute)mi.getAttribute("RuntimeVisibleParameterAnnotations");
      return CtClassType.toAnnotationType(ignoreNotFound, this.getDeclaringClass().getClassPool(), ainfo, ainfo2, mi);
   }

   public CtClass[] getParameterTypes() throws NotFoundException {
      return Descriptor.getParameterTypes(this.methodInfo.getDescriptor(), this.declaringClass.getClassPool());
   }

   CtClass getReturnType0() throws NotFoundException {
      return Descriptor.getReturnType(this.methodInfo.getDescriptor(), this.declaringClass.getClassPool());
   }

   public String getSignature() {
      return this.methodInfo.getDescriptor();
   }

   public CtClass[] getExceptionTypes() throws NotFoundException {
      ExceptionsAttribute ea = this.methodInfo.getExceptionsAttribute();
      String[] exceptions;
      if(ea == null) {
         exceptions = null;
      } else {
         exceptions = ea.getExceptions();
      }

      return this.declaringClass.getClassPool().get(exceptions);
   }

   public void setExceptionTypes(CtClass[] types) throws NotFoundException {
      this.declaringClass.checkModify();
      if(types != null && types.length != 0) {
         String[] names = new String[types.length];

         for(int ea = 0; ea < types.length; ++ea) {
            names[ea] = types[ea].getName();
         }

         ExceptionsAttribute var4 = this.methodInfo.getExceptionsAttribute();
         if(var4 == null) {
            var4 = new ExceptionsAttribute(this.methodInfo.getConstPool());
            this.methodInfo.setExceptionsAttribute(var4);
         }

         var4.setExceptions(names);
      } else {
         this.methodInfo.removeExceptionsAttribute();
      }
   }

   public abstract boolean isEmpty();

   public void setBody(String src) throws CannotCompileException {
      this.setBody(src, (String)null, (String)null);
   }

   public void setBody(String src, String delegateObj, String delegateMethod) throws CannotCompileException {
      this.declaringClass.checkModify();

      try {
         Javac e = new Javac(this.declaringClass);
         if(delegateMethod != null) {
            e.recordProceed(delegateObj, delegateMethod);
         }

         Bytecode b = e.compileBody(this, src);
         this.methodInfo.setCodeAttribute(b.toCodeAttribute());
         this.methodInfo.setAccessFlags(this.methodInfo.getAccessFlags() & -1025);
      } catch (CompileError var6) {
         throw new CannotCompileException(var6);
      }
   }

   static void setBody0(CtClass srcClass, MethodInfo srcInfo, CtClass destClass, MethodInfo destInfo, ClassMap map) throws CannotCompileException {
      destClass.checkModify();
      map = new ClassMap(map);
      map.put(srcClass.getName(), destClass.getName());

      try {
         CodeAttribute e = srcInfo.getCodeAttribute();
         if(e != null) {
            ConstPool cp = destInfo.getConstPool();
            CodeAttribute ca = (CodeAttribute)e.copy(cp, map);
            destInfo.setCodeAttribute(ca);
         }
      } catch (CodeAttribute.RuntimeCopyException var8) {
         throw new CannotCompileException(var8);
      }

      destInfo.setAccessFlags(destInfo.getAccessFlags() & -1025);
   }

   public byte[] getAttribute(String name) {
      AttributeInfo ai = this.methodInfo.getAttribute(name);
      return ai == null?null:ai.get();
   }

   public void setAttribute(String name, byte[] data) {
      this.declaringClass.checkModify();
      this.methodInfo.addAttribute(new AttributeInfo(this.methodInfo.getConstPool(), name, data));
   }

   public void useCflow(String name) throws CannotCompileException {
      CtClass cc = this.declaringClass;
      cc.checkModify();
      ClassPool pool = cc.getClassPool();
      int i = 0;

      while(true) {
         String fname = "_cflow$" + i++;

         try {
            cc.getDeclaredField(fname);
         } catch (NotFoundException var10) {
            pool.recordCflow(name, this.declaringClass.getName(), fname);

            try {
               CtClass e = pool.get("javassist.runtime.Cflow");
               CtField field = new CtField(e, fname, cc);
               field.setModifiers(9);
               cc.addField(field, CtField.Initializer.byNew(e));
               this.insertBefore(fname + ".enter();");
               String src = fname + ".exit();";
               this.insertAfter(src, true);
               return;
            } catch (NotFoundException var9) {
               throw new CannotCompileException(var9);
            }
         }
      }
   }

   public void addLocalVariable(String name, CtClass type) throws CannotCompileException {
      this.declaringClass.checkModify();
      ConstPool cp = this.methodInfo.getConstPool();
      CodeAttribute ca = this.methodInfo.getCodeAttribute();
      if(ca == null) {
         throw new CannotCompileException("no method body");
      } else {
         LocalVariableAttribute va = (LocalVariableAttribute)ca.getAttribute("LocalVariableTable");
         if(va == null) {
            va = new LocalVariableAttribute(cp);
            ca.getAttributes().add(va);
         }

         int maxLocals = ca.getMaxLocals();
         String desc = Descriptor.of(type);
         va.addEntry(0, ca.getCodeLength(), cp.addUtf8Info(name), cp.addUtf8Info(desc), maxLocals);
         ca.setMaxLocals(maxLocals + Descriptor.dataSize(desc));
      }
   }

   public void instrument(CodeConverter converter) throws CannotCompileException {
      this.declaringClass.checkModify();
      ConstPool cp = this.methodInfo.getConstPool();
      converter.doit(this.getDeclaringClass(), this.methodInfo, cp);
   }

   public void instrument(ExprEditor editor) throws CannotCompileException {
      if(this.declaringClass.isFrozen()) {
         this.declaringClass.checkModify();
      }

      if(editor.doit(this.declaringClass, this.methodInfo)) {
         this.declaringClass.checkModify();
      }

   }

   public void insertBefore(String src) throws CannotCompileException {
      this.declaringClass.checkModify();
      CodeAttribute ca = this.methodInfo.getCodeAttribute();
      if(ca == null) {
         throw new CannotCompileException("no method body");
      } else {
         CodeIterator iterator = ca.iterator();
         Javac jv = new Javac(this.declaringClass);

         try {
            int e = jv.recordParams(this.getParameterTypes(), Modifier.isStatic(this.getModifiers()));
            jv.recordParamNames(ca, e);
            jv.recordLocalVariables(ca, 0);
            jv.compileStmnt(src);
            Bytecode b = jv.getBytecode();
            int stack = b.getMaxStack();
            int locals = b.getMaxLocals();
            if(stack > ca.getMaxStack()) {
               ca.setMaxStack(stack);
            }

            if(locals > ca.getMaxLocals()) {
               ca.setMaxLocals(locals);
            }

            int pos = iterator.insertEx(b.get());
            iterator.insert(b.getExceptionTable(), pos);
         } catch (NotFoundException var10) {
            throw new CannotCompileException(var10);
         } catch (CompileError var11) {
            throw new CannotCompileException(var11);
         } catch (BadBytecode var12) {
            throw new CannotCompileException(var12);
         }
      }
   }

   public void insertAfter(String src) throws CannotCompileException {
      this.insertAfter(src, false);
   }

   public void insertAfter(String src, boolean asFinally) throws CannotCompileException {
      this.declaringClass.checkModify();
      ConstPool pool = this.methodInfo.getConstPool();
      CodeAttribute ca = this.methodInfo.getCodeAttribute();
      if(ca == null) {
         throw new CannotCompileException("no method body");
      } else {
         CodeIterator iterator = ca.iterator();
         int retAddr = ca.getMaxLocals();
         Bytecode b = new Bytecode(pool, 0, retAddr + 1);
         b.setStackDepth(ca.getMaxStack() + 1);
         Javac jv = new Javac(b, this.declaringClass);

         try {
            int e = jv.recordParams(this.getParameterTypes(), Modifier.isStatic(this.getModifiers()));
            jv.recordParamNames(ca, e);
            CtClass rtype = this.getReturnType0();
            int varNo = jv.recordReturnType(rtype, true);
            jv.recordLocalVariables(ca, 0);
            int handlerLen = this.insertAfterHandler(asFinally, b, rtype, varNo);
            byte[] save = this.makeSaveCode(pool, rtype, varNo);
            byte[] restore = this.makeRestoreCode(b, pool, rtype, varNo);
            b.addAstore(retAddr);
            jv.compileStmnt(src);
            b.addRet(retAddr);
            ca.setMaxStack(b.getMaxStack());
            ca.setMaxLocals(b.getMaxLocals());
            int gapPos = iterator.append(b.get());
            iterator.append(b.getExceptionTable(), gapPos);
            if(asFinally) {
               ca.getExceptionTable().add(0, gapPos, gapPos, 0);
            }

            int gapLen = iterator.getCodeLength() - gapPos - handlerLen;
            int subr = iterator.getCodeLength() - gapLen;

            while(iterator.hasNext()) {
               int pos = iterator.next();
               if(pos >= subr) {
                  break;
               }

               int c = iterator.byteAt(pos);
               if(c == 176 || c == 172 || c == 174 || c == 173 || c == 175 || c == 177) {
                  this.insertJSR(iterator, subr, pos, save, restore);
                  subr = iterator.getCodeLength() - gapLen;
               }
            }

         } catch (NotFoundException var20) {
            throw new CannotCompileException(var20);
         } catch (CompileError var21) {
            throw new CannotCompileException(var21);
         } catch (BadBytecode var22) {
            throw new CannotCompileException(var22);
         }
      }
   }

   private byte[] makeSaveCode(ConstPool cp, CtClass rtype, int varNo) {
      Bytecode b = new Bytecode(cp, 0, 0);
      if(rtype == CtClass.voidType) {
         b.addOpcode(1);
         b.addAstore(varNo);
         return b.get();
      } else {
         b.addStore(varNo, rtype);
         return b.get();
      }
   }

   private byte[] makeRestoreCode(Bytecode code, ConstPool cp, CtClass rtype, int varNo) {
      if(rtype == CtClass.voidType) {
         if(code.getMaxLocals() < 1) {
            code.setMaxLocals(1);
         }

         return new byte[0];
      } else {
         Bytecode b = new Bytecode(cp, 0, 0);
         b.addLoad(varNo, rtype);
         return b.get();
      }
   }

   private void insertJSR(CodeIterator iterator, int subr, int pos, byte[] save, byte[] restore) throws BadBytecode {
      int gapSize = 5 + save.length + restore.length;
      boolean wide = subr - pos > 32767 - gapSize - 4;
      gapSize = iterator.insertGap(pos, wide?gapSize:gapSize - 2);
      iterator.write(save, pos);
      pos += save.length;
      if(wide) {
         iterator.writeByte(201, pos);
         iterator.write32bit(subr - pos + gapSize, pos + 1);
         pos += 5;
      } else {
         iterator.writeByte(168, pos);
         iterator.write16bit(subr - pos + gapSize, pos + 1);
         pos += 3;
      }

      iterator.write(restore, pos);
   }

   private int insertAfterHandler(boolean asFinally, Bytecode b, CtClass rtype, int returnVarNo) {
      if(!asFinally) {
         return 0;
      } else {
         int var = b.getMaxLocals();
         b.incMaxLocals(1);
         int pc = b.currentPc();
         b.addAstore(var);
         if(rtype.isPrimitive()) {
            char pc2 = ((CtPrimitiveType)rtype).getDescriptor();
            if(pc2 == 68) {
               b.addDconst(0.0D);
               b.addDstore(returnVarNo);
            } else if(pc2 == 70) {
               b.addFconst(0.0F);
               b.addFstore(returnVarNo);
            } else if(pc2 == 74) {
               b.addLconst(0L);
               b.addLstore(returnVarNo);
            } else if(pc2 != 86) {
               b.addIconst(0);
               b.addIstore(returnVarNo);
            }
         } else {
            b.addOpcode(1);
            b.addAstore(returnVarNo);
         }

         b.addOpcode(168);
         int pc21 = b.currentPc();
         b.addIndex(0);
         b.addAload(var);
         b.addOpcode(191);
         int pc3 = b.currentPc();
         b.write16bit(pc21, pc3 - pc21 + 1);
         return pc3 - pc;
      }
   }

   public void addCatch(String src, CtClass exceptionType) throws CannotCompileException {
      this.addCatch(src, exceptionType, "$e");
   }

   public void addCatch(String src, CtClass exceptionType, String exceptionName) throws CannotCompileException {
      this.declaringClass.checkModify();
      ConstPool cp = this.methodInfo.getConstPool();
      CodeAttribute ca = this.methodInfo.getCodeAttribute();
      CodeIterator iterator = ca.iterator();
      Bytecode b = new Bytecode(cp, ca.getMaxStack(), ca.getMaxLocals());
      b.setStackDepth(1);
      Javac jv = new Javac(b, this.declaringClass);

      try {
         jv.recordParams(this.getParameterTypes(), Modifier.isStatic(this.getModifiers()));
         int e = jv.recordVariable(exceptionType, exceptionName);
         b.addAstore(e);
         jv.compileStmnt(src);
         int stack = b.getMaxStack();
         int locals = b.getMaxLocals();
         if(stack > ca.getMaxStack()) {
            ca.setMaxStack(stack);
         }

         if(locals > ca.getMaxLocals()) {
            ca.setMaxLocals(locals);
         }

         int len = iterator.getCodeLength();
         int pos = iterator.append(b.get());
         ca.getExceptionTable().add(this.getStartPosOfBody(ca), len, len, cp.addClassInfo(exceptionType));
         iterator.append(b.getExceptionTable(), pos);
      } catch (NotFoundException var14) {
         throw new CannotCompileException(var14);
      } catch (CompileError var15) {
         throw new CannotCompileException(var15);
      }
   }

   int getStartPosOfBody(CodeAttribute ca) throws CannotCompileException {
      return 0;
   }

   public int insertAt(int lineNum, String src) throws CannotCompileException {
      return this.insertAt(lineNum, true, src);
   }

   public int insertAt(int lineNum, boolean modify, String src) throws CannotCompileException {
      CodeAttribute ca = this.methodInfo.getCodeAttribute();
      if(ca == null) {
         throw new CannotCompileException("no method body");
      } else {
         LineNumberAttribute ainfo = (LineNumberAttribute)ca.getAttribute("LineNumberTable");
         if(ainfo == null) {
            throw new CannotCompileException("no line number info");
         } else {
            LineNumberAttribute.Pc pc = ainfo.toNearPc(lineNum);
            lineNum = pc.line;
            int index = pc.index;
            if(!modify) {
               return lineNum;
            } else {
               this.declaringClass.checkModify();
               CodeIterator iterator = ca.iterator();
               Javac jv = new Javac(this.declaringClass);

               try {
                  jv.recordLocalVariables(ca, index);
                  jv.recordParams(this.getParameterTypes(), Modifier.isStatic(this.getModifiers()));
                  jv.setMaxLocals(ca.getMaxLocals());
                  jv.compileStmnt(src);
                  Bytecode e = jv.getBytecode();
                  int locals = e.getMaxLocals();
                  int stack = e.getMaxStack();
                  ca.setMaxLocals(locals);
                  if(stack > ca.getMaxStack()) {
                     ca.setMaxStack(stack);
                  }

                  iterator.insert(index, e.get());
                  iterator.insert(e.getExceptionTable(), index);
                  return lineNum;
               } catch (NotFoundException var13) {
                  throw new CannotCompileException(var13);
               } catch (CompileError var14) {
                  throw new CannotCompileException(var14);
               } catch (BadBytecode var15) {
                  throw new CannotCompileException(var15);
               }
            }
         }
      }
   }
}
