package javassist;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javassist.CannotCompileException;
import javassist.ClassMap;
import javassist.ClassPool;
import javassist.CodeConverter;
import javassist.CtBehavior;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtField;
import javassist.CtMember;
import javassist.CtMethod;
import javassist.FieldInitLink;
import javassist.Modifier;
import javassist.NotFoundException;
import javassist.bytecode.AccessFlag;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.BadBytecode;
import javassist.bytecode.Bytecode;
import javassist.bytecode.ClassFile;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.CodeIterator;
import javassist.bytecode.ConstPool;
import javassist.bytecode.ConstantAttribute;
import javassist.bytecode.Descriptor;
import javassist.bytecode.EnclosingMethodAttribute;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.InnerClassesAttribute;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.ParameterAnnotationsAttribute;
import javassist.bytecode.annotation.Annotation;
import javassist.compiler.AccessorMaker;
import javassist.compiler.CompileError;
import javassist.compiler.Javac;
import javassist.expr.ExprEditor;

class CtClassType extends CtClass {
   ClassPool classPool;
   boolean wasChanged;
   private boolean wasFrozen;
   boolean wasPruned;
   boolean memberRemoved;
   ClassFile classfile;
   private CtMember fieldsCache;
   private CtMember methodsCache;
   private CtMember constructorsCache;
   private CtConstructor classInitializerCache;
   private AccessorMaker accessors;
   private FieldInitLink fieldInitializers;
   private Hashtable hiddenMethods;
   private int uniqueNumberSeed;
   private boolean doPruning;
   int getCounter;
   private static int readCounter = 0;
   private static final int READ_THRESHOLD = 100;

   CtClassType(String name, ClassPool cp) {
      super(name);
      this.doPruning = ClassPool.doPruning;
      this.classPool = cp;
      this.wasChanged = this.wasFrozen = this.wasPruned = this.memberRemoved = false;
      this.classfile = null;
      this.accessors = null;
      this.fieldInitializers = null;
      this.hiddenMethods = null;
      this.uniqueNumberSeed = 0;
      this.eraseCache();
      this.getCounter = 0;
   }

   CtClassType(InputStream ins, ClassPool cp) throws IOException {
      this((String)null, cp);
      this.classfile = new ClassFile(new DataInputStream(ins));
      this.qualifiedName = this.classfile.getName();
   }

   protected void extendToString(StringBuffer buffer) {
      if(this.wasChanged) {
         buffer.append("changed ");
      }

      if(this.wasFrozen) {
         buffer.append("frozen ");
      }

      if(this.wasPruned) {
         buffer.append("pruned ");
      }

      buffer.append(Modifier.toString(this.getModifiers()));
      buffer.append(" class ");
      buffer.append(this.getName());

      try {
         CtClass field = this.getSuperclass();
         if(field != null) {
            String c = field.getName();
            if(!c.equals("java.lang.Object")) {
               buffer.append(" extends " + field.getName());
            }
         }
      } catch (NotFoundException var5) {
         buffer.append(" extends ??");
      }

      try {
         CtClass[] var7 = this.getInterfaces();
         if(var7.length > 0) {
            buffer.append(" implements ");
         }

         for(int var9 = 0; var9 < var7.length; ++var9) {
            buffer.append(var7[var9].getName());
            buffer.append(", ");
         }
      } catch (NotFoundException var6) {
         buffer.append(" extends ??");
      }

      CtMember var8 = this.getFieldsCache();
      buffer.append(" fields=");

      while(var8 != null) {
         buffer.append(var8);
         buffer.append(", ");
         var8 = var8.next;
      }

      CtMember var10 = this.getConstructorsCache();
      buffer.append(" constructors=");

      while(var10 != null) {
         buffer.append(var10);
         buffer.append(", ");
         var10 = var10.next;
      }

      CtMember m = this.getMethodsCache();
      buffer.append(" methods=");

      while(m != null) {
         buffer.append(m);
         buffer.append(", ");
         m = m.next;
      }

   }

   protected void eraseCache() {
      this.fieldsCache = null;
      this.constructorsCache = null;
      this.classInitializerCache = null;
      this.methodsCache = null;
   }

   public AccessorMaker getAccessorMaker() {
      if(this.accessors == null) {
         this.accessors = new AccessorMaker(this);
      }

      return this.accessors;
   }

   public ClassFile getClassFile2() {
      if(this.classfile != null) {
         return this.classfile;
      } else {
         if(readCounter++ > 100 && ClassPool.releaseUnmodifiedClassFile) {
            this.releaseClassFiles();
            readCounter = 0;
         }

         Object fin = null;

         ClassFile e;
         try {
            fin = this.classPool.openClassfile(this.getName());
            if(fin == null) {
               throw new NotFoundException(this.getName());
            }

            fin = new BufferedInputStream((InputStream)fin);
            this.classfile = new ClassFile(new DataInputStream((InputStream)fin));
            if(!this.classfile.getName().equals(this.qualifiedName)) {
               throw new RuntimeException("cannot find " + this.qualifiedName + ": " + this.classfile.getName() + " found in " + this.qualifiedName.replace('.', '/') + ".class");
            }

            e = this.classfile;
         } catch (NotFoundException var12) {
            throw new RuntimeException(var12.toString());
         } catch (IOException var13) {
            throw new RuntimeException(var13.toString());
         } finally {
            if(fin != null) {
               try {
                  ((InputStream)fin).close();
               } catch (IOException var11) {
                  ;
               }
            }

         }

         return e;
      }
   }

   void incGetCounter() {
      ++this.getCounter;
   }

   private void releaseClassFiles() {
      Enumeration e = this.classPool.classes.elements();

      while(e.hasMoreElements()) {
         Object obj = e.nextElement();
         if(obj instanceof CtClassType) {
            CtClassType cct = (CtClassType)obj;
            if(cct.getCounter < 2 && !cct.isModified()) {
               cct.eraseCache();
               cct.classfile = null;
            }

            cct.getCounter = 0;
         }
      }

   }

   public ClassPool getClassPool() {
      return this.classPool;
   }

   void setClassPool(ClassPool cp) {
      this.classPool = cp;
   }

   public URL getURL() throws NotFoundException {
      URL url = this.classPool.find(this.getName());
      if(url == null) {
         throw new NotFoundException(this.getName());
      } else {
         return url;
      }
   }

   public boolean isModified() {
      return this.wasChanged;
   }

   public boolean isFrozen() {
      return this.wasFrozen;
   }

   void freeze() {
      this.wasFrozen = true;
   }

   void checkModify() throws RuntimeException {
      if(this.isFrozen()) {
         String msg = this.getName() + " class is frozen";
         if(this.wasPruned) {
            msg = msg + " and pruned";
         }

         throw new RuntimeException(msg);
      } else {
         this.wasChanged = true;
      }
   }

   public void defrost() {
      this.checkPruned("defrost");
      this.wasFrozen = false;
   }

   public boolean subtypeOf(CtClass clazz) throws NotFoundException {
      String cname = clazz.getName();
      if(this != clazz && !this.getName().equals(cname)) {
         ClassFile file = this.getClassFile2();
         String supername = file.getSuperclass();
         if(supername != null && supername.equals(cname)) {
            return true;
         } else {
            String[] ifs = file.getInterfaces();
            int num = ifs.length;

            int i;
            for(i = 0; i < num; ++i) {
               if(ifs[i].equals(cname)) {
                  return true;
               }
            }

            if(supername != null && this.classPool.get(supername).subtypeOf(clazz)) {
               return true;
            } else {
               for(i = 0; i < num; ++i) {
                  if(this.classPool.get(ifs[i]).subtypeOf(clazz)) {
                     return true;
                  }
               }

               return false;
            }
         }
      } else {
         return true;
      }
   }

   public void setName(String name) throws RuntimeException {
      String oldname = this.getName();
      if(!name.equals(oldname)) {
         this.classPool.checkNotFrozen(name);
         ClassFile cf = this.getClassFile2();
         super.setName(name);
         cf.setName(name);
         this.eraseCache();
         this.classPool.classNameChanged(oldname, this);
      }
   }

   public void replaceClassName(ClassMap classnames) throws RuntimeException {
      String oldClassName = this.getName();
      String newClassName = (String)classnames.get(Descriptor.toJvmName(oldClassName));
      if(newClassName != null) {
         newClassName = Descriptor.toJavaName(newClassName);
         this.classPool.checkNotFrozen(newClassName);
      }

      super.replaceClassName(classnames);
      ClassFile cf = this.getClassFile2();
      cf.renameClass(classnames);
      this.eraseCache();
      if(newClassName != null) {
         super.setName(newClassName);
         this.classPool.classNameChanged(oldClassName, this);
      }

   }

   public void replaceClassName(String oldname, String newname) throws RuntimeException {
      String thisname = this.getName();
      if(thisname.equals(oldname)) {
         this.setName(newname);
      } else {
         super.replaceClassName(oldname, newname);
         this.getClassFile2().renameClass(oldname, newname);
         this.eraseCache();
      }

   }

   public boolean isInterface() {
      return Modifier.isInterface(this.getModifiers());
   }

   public boolean isAnnotation() {
      return Modifier.isAnnotation(this.getModifiers());
   }

   public boolean isEnum() {
      return Modifier.isEnum(this.getModifiers());
   }

   public int getModifiers() {
      ClassFile cf = this.getClassFile2();
      int acc = cf.getAccessFlags();
      acc = AccessFlag.clear(acc, 32);
      int inner = cf.getInnerAccessFlags();
      if(inner != -1 && (inner & 8) != 0) {
         acc |= 8;
      }

      return AccessFlag.toModifier(acc);
   }

   public CtClass[] getNestedClasses() throws NotFoundException {
      ClassFile cf = this.getClassFile2();
      InnerClassesAttribute ica = (InnerClassesAttribute)cf.getAttribute("InnerClasses");
      if(ica == null) {
         return new CtClass[0];
      } else {
         String thisName = cf.getName();
         int n = ica.tableLength();
         ArrayList list = new ArrayList(n);

         for(int i = 0; i < n; ++i) {
            String outer = ica.outerClass(i);
            if(outer == null || outer.equals(thisName)) {
               String inner = ica.innerClass(i);
               if(inner != null) {
                  list.add(this.classPool.get(inner));
               }
            }
         }

         return (CtClass[])list.toArray(new CtClass[list.size()]);
      }
   }

   public void setModifiers(int mod) {
      ClassFile cf = this.getClassFile2();
      int acc;
      if(Modifier.isStatic(mod)) {
         acc = cf.getInnerAccessFlags();
         if(acc == -1 || (acc & 8) == 0) {
            throw new RuntimeException("cannot change " + this.getName() + " into a static class");
         }

         mod &= -9;
      }

      this.checkModify();
      acc = AccessFlag.of(mod) | 32;
      cf.setAccessFlags(acc);
   }

   public Object[] getAnnotations() throws ClassNotFoundException {
      return this.getAnnotations(false);
   }

   public Object[] getAvailableAnnotations() {
      try {
         return this.getAnnotations(true);
      } catch (ClassNotFoundException var2) {
         throw new RuntimeException("Unexpected exception ", var2);
      }
   }

   private Object[] getAnnotations(boolean ignoreNotFound) throws ClassNotFoundException {
      ClassFile cf = this.getClassFile2();
      AnnotationsAttribute ainfo = (AnnotationsAttribute)cf.getAttribute("RuntimeInvisibleAnnotations");
      AnnotationsAttribute ainfo2 = (AnnotationsAttribute)cf.getAttribute("RuntimeVisibleAnnotations");
      return toAnnotationType(ignoreNotFound, this.getClassPool(), ainfo, ainfo2);
   }

   static Object[] toAnnotationType(boolean ignoreNotFound, ClassPool cp, AnnotationsAttribute a1, AnnotationsAttribute a2) throws ClassNotFoundException {
      Annotation[] anno1;
      int size1;
      if(a1 == null) {
         anno1 = null;
         size1 = 0;
      } else {
         anno1 = a1.getAnnotations();
         size1 = anno1.length;
      }

      Annotation[] anno2;
      int size2;
      if(a2 == null) {
         anno2 = null;
         size2 = 0;
      } else {
         anno2 = a2.getAnnotations();
         size2 = anno2.length;
      }

      int j;
      if(!ignoreNotFound) {
         Object[] var13 = new Object[size1 + size2];

         for(j = 0; j < size1; ++j) {
            var13[j] = toAnnoType(anno1[j], cp);
         }

         for(j = 0; j < size2; ++j) {
            var13[j + size1] = toAnnoType(anno2[j], cp);
         }

         return var13;
      } else {
         ArrayList annotations = new ArrayList();

         for(j = 0; j < size1; ++j) {
            try {
               annotations.add(toAnnoType(anno1[j], cp));
            } catch (ClassNotFoundException var12) {
               ;
            }
         }

         for(j = 0; j < size2; ++j) {
            try {
               annotations.add(toAnnoType(anno2[j], cp));
            } catch (ClassNotFoundException var11) {
               ;
            }
         }

         return annotations.toArray();
      }
   }

   static Object[][] toAnnotationType(boolean ignoreNotFound, ClassPool cp, ParameterAnnotationsAttribute a1, ParameterAnnotationsAttribute a2, MethodInfo minfo) throws ClassNotFoundException {
      boolean numParameters = false;
      int var17;
      if(a1 != null) {
         var17 = a1.numParameters();
      } else if(a2 != null) {
         var17 = a2.numParameters();
      } else {
         var17 = Descriptor.numOfParameters(minfo.getDescriptor());
      }

      Object[][] result = new Object[var17][];

      for(int i = 0; i < var17; ++i) {
         Annotation[] anno1;
         int size1;
         if(a1 == null) {
            anno1 = null;
            size1 = 0;
         } else {
            anno1 = a1.getAnnotations()[i];
            size1 = anno1.length;
         }

         Annotation[] anno2;
         int size2;
         if(a2 == null) {
            anno2 = null;
            size2 = 0;
         } else {
            anno2 = a2.getAnnotations()[i];
            size2 = anno2.length;
         }

         if(!ignoreNotFound) {
            result[i] = new Object[size1 + size2];

            int var18;
            for(var18 = 0; var18 < size1; ++var18) {
               result[i][var18] = toAnnoType(anno1[var18], cp);
            }

            for(var18 = 0; var18 < size2; ++var18) {
               result[i][var18 + size1] = toAnnoType(anno2[var18], cp);
            }
         } else {
            ArrayList annotations = new ArrayList();

            int j;
            for(j = 0; j < size1; ++j) {
               try {
                  annotations.add(toAnnoType(anno1[j], cp));
               } catch (ClassNotFoundException var16) {
                  ;
               }
            }

            for(j = 0; j < size2; ++j) {
               try {
                  annotations.add(toAnnoType(anno2[j], cp));
               } catch (ClassNotFoundException var15) {
                  ;
               }
            }

            result[i] = annotations.toArray();
         }
      }

      return result;
   }

   private static Object toAnnoType(Annotation anno, ClassPool cp) throws ClassNotFoundException {
      try {
         ClassLoader e = cp.getClassLoader();
         return anno.toAnnotationType(e, cp);
      } catch (ClassNotFoundException var4) {
         ClassLoader cl2 = cp.getClass().getClassLoader();
         return anno.toAnnotationType(cl2, cp);
      }
   }

   public boolean subclassOf(CtClass superclass) {
      if(superclass == null) {
         return false;
      } else {
         String superName = superclass.getName();
         Object curr = this;

         try {
            while(curr != null) {
               if(((CtClass)curr).getName().equals(superName)) {
                  return true;
               }

               curr = ((CtClass)curr).getSuperclass();
            }
         } catch (Exception var5) {
            ;
         }

         return false;
      }
   }

   public CtClass getSuperclass() throws NotFoundException {
      String supername = this.getClassFile2().getSuperclass();
      return supername == null?null:this.classPool.get(supername);
   }

   public void setSuperclass(CtClass clazz) throws CannotCompileException {
      this.checkModify();
      if(this.isInterface()) {
         this.addInterface(clazz);
      } else {
         this.getClassFile2().setSuperclass(clazz.getName());
      }

   }

   public CtClass[] getInterfaces() throws NotFoundException {
      String[] ifs = this.getClassFile2().getInterfaces();
      int num = ifs.length;
      CtClass[] ifc = new CtClass[num];

      for(int i = 0; i < num; ++i) {
         ifc[i] = this.classPool.get(ifs[i]);
      }

      return ifc;
   }

   public void setInterfaces(CtClass[] list) {
      this.checkModify();
      String[] ifs;
      if(list == null) {
         ifs = new String[0];
      } else {
         int num = list.length;
         ifs = new String[num];

         for(int i = 0; i < num; ++i) {
            ifs[i] = list[i].getName();
         }
      }

      this.getClassFile2().setInterfaces(ifs);
   }

   public void addInterface(CtClass anInterface) {
      this.checkModify();
      if(anInterface != null) {
         this.getClassFile2().addInterface(anInterface.getName());
      }

   }

   public CtClass getDeclaringClass() throws NotFoundException {
      ClassFile cf = this.getClassFile2();
      InnerClassesAttribute ica = (InnerClassesAttribute)cf.getAttribute("InnerClasses");
      if(ica == null) {
         return null;
      } else {
         String name = this.getName();
         int n = ica.tableLength();

         for(int i = 0; i < n; ++i) {
            if(name.equals(ica.innerClass(i))) {
               String outName = ica.outerClass(i);
               if(outName != null) {
                  return this.classPool.get(outName);
               }

               EnclosingMethodAttribute ema = (EnclosingMethodAttribute)cf.getAttribute("EnclosingMethod");
               if(ema != null) {
                  return this.classPool.get(ema.className());
               }
            }
         }

         return null;
      }
   }

   public CtMethod getEnclosingMethod() throws NotFoundException {
      ClassFile cf = this.getClassFile2();
      EnclosingMethodAttribute ema = (EnclosingMethodAttribute)cf.getAttribute("EnclosingMethod");
      if(ema != null) {
         CtClass enc = this.classPool.get(ema.className());
         return enc.getMethod(ema.methodName(), ema.methodDescriptor());
      } else {
         return null;
      }
   }

   public CtClass makeNestedClass(String name, boolean isStatic) {
      if(!isStatic) {
         throw new RuntimeException("sorry, only nested static class is supported");
      } else {
         this.checkModify();
         CtClass c = this.classPool.makeNestedClass(this.getName() + "$" + name);
         ClassFile cf = this.getClassFile2();
         ClassFile cf2 = c.getClassFile2();
         InnerClassesAttribute ica = (InnerClassesAttribute)cf.getAttribute("InnerClasses");
         if(ica == null) {
            ica = new InnerClassesAttribute(cf.getConstPool());
            cf.addAttribute(ica);
         }

         ica.append(c.getName(), this.getName(), name, cf2.getAccessFlags() & -33 | 8);
         cf2.addAttribute(ica.copy(cf2.getConstPool(), (Map)null));
         return c;
      }
   }

   public CtField[] getFields() {
      ArrayList alist = new ArrayList();
      getFields(alist, this);
      return (CtField[])alist.toArray(new CtField[alist.size()]);
   }

   private static void getFields(ArrayList alist, CtClass cc) {
      if(cc != null) {
         try {
            getFields(alist, cc.getSuperclass());
         } catch (NotFoundException var5) {
            ;
         }

         try {
            CtClass[] cf = cc.getInterfaces();
            int num = cf.length;

            for(int i = 0; i < num; ++i) {
               getFields(alist, cf[i]);
            }
         } catch (NotFoundException var6) {
            ;
         }

         for(CtMember var7 = ((CtClassType)cc).getFieldsCache(); var7 != null; var7 = var7.next) {
            if(!Modifier.isPrivate(var7.getModifiers())) {
               alist.add(var7);
            }
         }

      }
   }

   public CtField getField(String name) throws NotFoundException {
      CtField f = this.getField2(name);
      if(f == null) {
         throw new NotFoundException("field: " + name + " in " + this.getName());
      } else {
         return f;
      }
   }

   CtField getField2(String name) {
      CtField df = this.getDeclaredField2(name);
      if(df != null) {
         return df;
      } else {
         try {
            CtClass[] e = this.getInterfaces();
            int num = e.length;

            for(int s = 0; s < num; ++s) {
               CtField f = e[s].getField2(name);
               if(f != null) {
                  return f;
               }
            }

            CtClass var8 = this.getSuperclass();
            if(var8 != null) {
               return var8.getField2(name);
            }
         } catch (NotFoundException var7) {
            ;
         }

         return null;
      }
   }

   public CtField[] getDeclaredFields() {
      CtMember cf = this.getFieldsCache();
      int num = CtField.count(cf);
      CtField[] cfs = new CtField[num];

      for(int i = 0; cf != null; cf = cf.next) {
         cfs[i++] = (CtField)cf;
      }

      return cfs;
   }

   protected CtMember getFieldsCache() {
      if(this.fieldsCache == null) {
         List list = this.getClassFile2().getFields();
         int n = list.size();
         CtMember allFields = null;
         CtField tail = null;

         for(int i = 0; i < n; ++i) {
            FieldInfo finfo = (FieldInfo)list.get(i);
            CtField newTail = new CtField(finfo, this);
            allFields = CtMember.append(allFields, tail, newTail);
            tail = newTail;
         }

         this.fieldsCache = allFields;
      }

      return this.fieldsCache;
   }

   public CtField getDeclaredField(String name) throws NotFoundException {
      CtField f = this.getDeclaredField2(name);
      if(f == null) {
         throw new NotFoundException("field: " + name + " in " + this.getName());
      } else {
         return f;
      }
   }

   private CtField getDeclaredField2(String name) {
      for(CtMember cf = this.getFieldsCache(); cf != null; cf = cf.next) {
         if(cf.getName().equals(name)) {
            return (CtField)cf;
         }
      }

      return null;
   }

   public CtBehavior[] getDeclaredBehaviors() {
      CtMember cc = this.getConstructorsCache();
      CtMember cm = this.getMethodsCache();
      int num = CtMember.count(cm) + CtMember.count(cc);
      CtBehavior[] cb = new CtBehavior[num];

      int i;
      for(i = 0; cc != null; cc = cc.next) {
         cb[i++] = (CtBehavior)cc;
      }

      while(cm != null) {
         cb[i++] = (CtBehavior)cm;
         cm = cm.next;
      }

      return cb;
   }

   public CtConstructor[] getConstructors() {
      CtConstructor[] cons = this.getDeclaredConstructors();
      if(cons.length == 0) {
         return cons;
      } else {
         int n = 0;
         int i = cons.length;

         while(true) {
            --i;
            if(i < 0) {
               CtConstructor[] result = new CtConstructor[n];
               n = 0;
               i = cons.length;

               while(true) {
                  --i;
                  if(i < 0) {
                     return result;
                  }

                  CtConstructor c = cons[i];
                  if(!Modifier.isPrivate(c.getModifiers())) {
                     result[n++] = c;
                  }
               }
            }

            if(!Modifier.isPrivate(cons[i].getModifiers())) {
               ++n;
            }
         }
      }
   }

   public CtConstructor getConstructor(String desc) throws NotFoundException {
      for(CtConstructor cc = (CtConstructor)this.getConstructorsCache(); cc != null; cc = (CtConstructor)cc.next) {
         if(cc.getMethodInfo2().getDescriptor().equals(desc)) {
            return cc;
         }
      }

      return super.getConstructor(desc);
   }

   public CtConstructor[] getDeclaredConstructors() {
      CtMember cc = this.getConstructorsCache();
      int num = CtMember.count(cc);
      CtConstructor[] ccs = new CtConstructor[num];

      for(int i = 0; cc != null; cc = cc.next) {
         ccs[i++] = (CtConstructor)cc;
      }

      return ccs;
   }

   protected CtMember getConstructorsCache() {
      if(this.constructorsCache == null) {
         List list = this.getClassFile2().getMethods();
         int n = list.size();
         CtMember allConstructors = null;
         CtConstructor tail = null;

         for(int i = 0; i < n; ++i) {
            MethodInfo minfo = (MethodInfo)list.get(i);
            if(minfo.isConstructor()) {
               CtConstructor newTail = new CtConstructor(minfo, this);
               allConstructors = CtMember.append(allConstructors, tail, newTail);
               tail = newTail;
            }
         }

         this.constructorsCache = allConstructors;
      }

      return this.constructorsCache;
   }

   public CtConstructor getClassInitializer() {
      if(this.classInitializerCache == null) {
         MethodInfo minfo = this.getClassFile2().getStaticInitializer();
         if(minfo != null) {
            this.classInitializerCache = new CtConstructor(minfo, this);
         }
      }

      return this.classInitializerCache;
   }

   public CtMethod[] getMethods() {
      HashMap h = new HashMap();
      getMethods0(h, this);
      return (CtMethod[])h.values().toArray(new CtMethod[h.size()]);
   }

   private static void getMethods0(HashMap h, CtClass cc) {
      try {
         CtClass[] cm = cc.getInterfaces();
         int size = cm.length;

         for(int i = 0; i < size; ++i) {
            getMethods0(h, cm[i]);
         }
      } catch (NotFoundException var6) {
         ;
      }

      try {
         CtClass var7 = cc.getSuperclass();
         if(var7 != null) {
            getMethods0(h, var7);
         }
      } catch (NotFoundException var5) {
         ;
      }

      if(cc instanceof CtClassType) {
         for(CtMember var8 = ((CtClassType)cc).getMethodsCache(); var8 != null; var8 = var8.next) {
            if(!Modifier.isPrivate(var8.getModifiers())) {
               h.put(((CtMethod)var8).getStringRep(), var8);
            }
         }
      }

   }

   public CtMethod getMethod(String name, String desc) throws NotFoundException {
      CtMethod m = getMethod0(this, name, desc);
      if(m != null) {
         return m;
      } else {
         throw new NotFoundException(name + "(..) is not found in " + this.getName());
      }
   }

   private static CtMethod getMethod0(CtClass cc, String name, String desc) {
      if(cc instanceof CtClassType) {
         for(CtMethod e = (CtMethod)((CtClassType)cc).getMethodsCache(); e != null; e = (CtMethod)e.next) {
            if(e.getName().equals(name) && e.getMethodInfo2().getDescriptor().equals(desc)) {
               return e;
            }
         }
      }

      try {
         CtClass var9 = cc.getSuperclass();
         if(var9 != null) {
            CtMethod size = getMethod0(var9, name, desc);
            if(size != null) {
               return size;
            }
         }
      } catch (NotFoundException var7) {
         ;
      }

      try {
         CtClass[] var10 = cc.getInterfaces();
         int var11 = var10.length;

         for(int i = 0; i < var11; ++i) {
            CtMethod m = getMethod0(var10[i], name, desc);
            if(m != null) {
               return m;
            }
         }
      } catch (NotFoundException var8) {
         ;
      }

      return null;
   }

   public CtMethod[] getDeclaredMethods() {
      CtMember cm = this.getMethodsCache();
      int num = CtMember.count(cm);
      CtMethod[] cms = new CtMethod[num];

      for(int i = 0; cm != null; cm = cm.next) {
         cms[i++] = (CtMethod)cm;
      }

      return cms;
   }

   public CtMethod getDeclaredMethod(String name) throws NotFoundException {
      for(CtMember m = this.getMethodsCache(); m != null; m = m.next) {
         if(m.getName().equals(name)) {
            return (CtMethod)m;
         }
      }

      throw new NotFoundException(name + "(..) is not found in " + this.getName());
   }

   public CtMethod getDeclaredMethod(String name, CtClass[] params) throws NotFoundException {
      String desc = Descriptor.ofParameters(params);

      for(CtMethod m = (CtMethod)this.getMethodsCache(); m != null; m = (CtMethod)m.next) {
         if(m.getName().equals(name) && m.getMethodInfo2().getDescriptor().startsWith(desc)) {
            return m;
         }
      }

      throw new NotFoundException(name + "(..) is not found in " + this.getName());
   }

   protected CtMember getMethodsCache() {
      if(this.methodsCache == null) {
         List list = this.getClassFile2().getMethods();
         int n = list.size();
         CtMember allMethods = null;
         CtMethod tail = null;

         for(int i = 0; i < n; ++i) {
            MethodInfo minfo = (MethodInfo)list.get(i);
            if(minfo.isMethod()) {
               CtMethod newTail = new CtMethod(minfo, this);
               allMethods = CtMember.append(allMethods, tail, newTail);
               tail = newTail;
            }
         }

         this.methodsCache = allMethods;
      }

      return this.methodsCache;
   }

   public void addField(CtField f, String init) throws CannotCompileException {
      this.addField(f, CtField.Initializer.byExpr(init));
   }

   public void addField(CtField f, CtField.Initializer init) throws CannotCompileException {
      this.checkModify();
      if(f.getDeclaringClass() != this) {
         throw new CannotCompileException("cannot add");
      } else {
         if(init == null) {
            init = f.getInit();
         }

         if(init != null) {
            int fil = f.getModifiers();
            if(Modifier.isStatic(fil) && Modifier.isFinal(fil)) {
               try {
                  ConstPool link = this.getClassFile2().getConstPool();
                  int index = init.getConstantValue(link, f.getType());
                  if(index != 0) {
                     f.getFieldInfo2().addAttribute(new ConstantAttribute(link, index));
                     init = null;
                  }
               } catch (NotFoundException var6) {
                  ;
               }
            }
         }

         this.getFieldsCache();
         this.fieldsCache = CtField.append(this.fieldsCache, f);
         this.getClassFile2().addField(f.getFieldInfo2());
         if(init != null) {
            FieldInitLink fil1 = new FieldInitLink(f, init);
            FieldInitLink link1 = this.fieldInitializers;
            if(link1 == null) {
               this.fieldInitializers = fil1;
            } else {
               while(link1.next != null) {
                  link1 = link1.next;
               }

               link1.next = fil1;
            }
         }

      }
   }

   public void removeField(CtField f) throws NotFoundException {
      this.checkModify();
      FieldInfo fi = f.getFieldInfo2();
      ClassFile cf = this.getClassFile2();
      if(cf.getFields().remove(fi)) {
         this.fieldsCache = CtMember.remove(this.fieldsCache, f);
         this.memberRemoved = true;
      } else {
         throw new NotFoundException(f.toString());
      }
   }

   public CtConstructor makeClassInitializer() throws CannotCompileException {
      CtConstructor clinit = this.getClassInitializer();
      if(clinit != null) {
         return clinit;
      } else {
         this.checkModify();
         ClassFile cf = this.getClassFile2();
         Bytecode code = new Bytecode(cf.getConstPool(), 0, 0);
         this.modifyClassConstructor(cf, code, 0, 0);
         return this.getClassInitializer();
      }
   }

   public void addConstructor(CtConstructor c) throws CannotCompileException {
      this.checkModify();
      if(c.getDeclaringClass() != this) {
         throw new CannotCompileException("cannot add");
      } else {
         this.getConstructorsCache();
         this.constructorsCache = (CtConstructor)CtMember.append(this.constructorsCache, c);
         this.getClassFile2().addMethod(c.getMethodInfo2());
      }
   }

   public void removeConstructor(CtConstructor m) throws NotFoundException {
      this.checkModify();
      MethodInfo mi = m.getMethodInfo2();
      ClassFile cf = this.getClassFile2();
      if(cf.getMethods().remove(mi)) {
         this.constructorsCache = CtMember.remove(this.constructorsCache, m);
         this.memberRemoved = true;
      } else {
         throw new NotFoundException(m.toString());
      }
   }

   public void addMethod(CtMethod m) throws CannotCompileException {
      this.checkModify();
      if(m.getDeclaringClass() != this) {
         throw new CannotCompileException("cannot add");
      } else {
         this.getMethodsCache();
         this.methodsCache = CtMember.append(this.methodsCache, m);
         this.getClassFile2().addMethod(m.getMethodInfo2());
         if((m.getModifiers() & 1024) != 0) {
            this.setModifiers(this.getModifiers() | 1024);
         }

      }
   }

   public void removeMethod(CtMethod m) throws NotFoundException {
      this.checkModify();
      MethodInfo mi = m.getMethodInfo2();
      ClassFile cf = this.getClassFile2();
      if(cf.getMethods().remove(mi)) {
         this.methodsCache = CtMember.remove(this.methodsCache, m);
         this.memberRemoved = true;
      } else {
         throw new NotFoundException(m.toString());
      }
   }

   public byte[] getAttribute(String name) {
      AttributeInfo ai = this.getClassFile2().getAttribute(name);
      return ai == null?null:ai.get();
   }

   public void setAttribute(String name, byte[] data) {
      this.checkModify();
      ClassFile cf = this.getClassFile2();
      cf.addAttribute(new AttributeInfo(cf.getConstPool(), name, data));
   }

   public void instrument(CodeConverter converter) throws CannotCompileException {
      this.checkModify();
      ClassFile cf = this.getClassFile2();
      ConstPool cp = cf.getConstPool();
      List list = cf.getMethods();
      int n = list.size();

      for(int i = 0; i < n; ++i) {
         MethodInfo minfo = (MethodInfo)list.get(i);
         converter.doit(this, minfo, cp);
      }

   }

   public void instrument(ExprEditor editor) throws CannotCompileException {
      this.checkModify();
      ClassFile cf = this.getClassFile2();
      List list = cf.getMethods();
      int n = list.size();

      for(int i = 0; i < n; ++i) {
         MethodInfo minfo = (MethodInfo)list.get(i);
         editor.doit(this, minfo);
      }

   }

   public void prune() {
      if(!this.wasPruned) {
         this.wasPruned = this.wasFrozen = true;
         this.getClassFile2().prune();
      }
   }

   public void toBytecode(DataOutputStream out) throws CannotCompileException, IOException {
      try {
         if(this.isModified()) {
            this.checkPruned("toBytecode");
            ClassFile e = this.getClassFile2();
            if(this.memberRemoved) {
               e.compact();
               this.memberRemoved = false;
            }

            this.modifyClassConstructor(e);
            this.modifyConstructors(e);
            e.write(out);
            out.flush();
            this.fieldInitializers = null;
            if(this.doPruning) {
               e.prune();
               this.wasPruned = true;
            }
         } else {
            this.classPool.writeClassfile(this.getName(), out);
            this.eraseCache();
            this.classfile = null;
         }

         this.wasFrozen = true;
      } catch (NotFoundException var3) {
         throw new CannotCompileException(var3);
      } catch (IOException var4) {
         throw new CannotCompileException(var4);
      }
   }

   private void checkPruned(String method) {
      if(this.wasPruned) {
         throw new RuntimeException(method + "(): " + this.getName() + " was pruned.");
      }
   }

   public boolean stopPruning(boolean stop) {
      boolean prev = !this.doPruning;
      this.doPruning = !stop;
      return prev;
   }

   private void modifyClassConstructor(ClassFile cf) throws CannotCompileException, NotFoundException {
      if(this.fieldInitializers != null) {
         Bytecode code = new Bytecode(cf.getConstPool(), 0, 0);
         Javac jv = new Javac(code, this);
         int stacksize = 0;
         boolean doInit = false;

         for(FieldInitLink fi = this.fieldInitializers; fi != null; fi = fi.next) {
            CtField f = fi.field;
            if(Modifier.isStatic(f.getModifiers())) {
               doInit = true;
               int s = fi.init.compileIfStatic(f.getType(), f.getName(), code, jv);
               if(stacksize < s) {
                  stacksize = s;
               }
            }
         }

         if(doInit) {
            this.modifyClassConstructor(cf, code, stacksize, 0);
         }

      }
   }

   private void modifyClassConstructor(ClassFile cf, Bytecode code, int stacksize, int localsize) throws CannotCompileException {
      MethodInfo m = cf.getStaticInitializer();
      if(m == null) {
         code.add(177);
         code.setMaxStack(stacksize);
         code.setMaxLocals(localsize);
         m = new MethodInfo(cf.getConstPool(), "<clinit>", "()V");
         m.setAccessFlags(8);
         m.setCodeAttribute(code.toCodeAttribute());
         cf.addMethod(m);
      } else {
         CodeAttribute codeAttr = m.getCodeAttribute();
         if(codeAttr == null) {
            throw new CannotCompileException("empty <clinit>");
         }

         try {
            CodeIterator e = codeAttr.iterator();
            int pos = e.insertEx(code.get());
            e.insert(code.getExceptionTable(), pos);
            int maxstack = codeAttr.getMaxStack();
            if(maxstack < stacksize) {
               codeAttr.setMaxStack(stacksize);
            }

            int maxlocals = codeAttr.getMaxLocals();
            if(maxlocals < localsize) {
               codeAttr.setMaxLocals(localsize);
            }
         } catch (BadBytecode var11) {
            throw new CannotCompileException(var11);
         }
      }

   }

   private void modifyConstructors(ClassFile cf) throws CannotCompileException, NotFoundException {
      if(this.fieldInitializers != null) {
         ConstPool cp = cf.getConstPool();
         List list = cf.getMethods();
         int n = list.size();

         for(int i = 0; i < n; ++i) {
            MethodInfo minfo = (MethodInfo)list.get(i);
            if(minfo.isConstructor()) {
               CodeAttribute codeAttr = minfo.getCodeAttribute();
               if(codeAttr != null) {
                  try {
                     Bytecode e = new Bytecode(cp, 0, codeAttr.getMaxLocals());
                     CtClass[] params = Descriptor.getParameterTypes(minfo.getDescriptor(), this.classPool);
                     int stacksize = this.makeFieldInitializer(e, params);
                     insertAuxInitializer(codeAttr, e, stacksize);
                  } catch (BadBytecode var11) {
                     throw new CannotCompileException(var11);
                  }
               }
            }
         }

      }
   }

   private static void insertAuxInitializer(CodeAttribute codeAttr, Bytecode initializer, int stacksize) throws BadBytecode {
      CodeIterator it = codeAttr.iterator();
      int index = it.skipSuperConstructor();
      if(index < 0) {
         index = it.skipThisConstructor();
         if(index >= 0) {
            return;
         }
      }

      int pos = it.insertEx(initializer.get());
      it.insert(initializer.getExceptionTable(), pos);
      int maxstack = codeAttr.getMaxStack();
      if(maxstack < stacksize) {
         codeAttr.setMaxStack(stacksize);
      }

   }

   private int makeFieldInitializer(Bytecode code, CtClass[] parameters) throws CannotCompileException, NotFoundException {
      int stacksize = 0;
      Javac jv = new Javac(code, this);

      try {
         jv.recordParams(parameters, false);
      } catch (CompileError var8) {
         throw new CannotCompileException(var8);
      }

      for(FieldInitLink fi = this.fieldInitializers; fi != null; fi = fi.next) {
         CtField f = fi.field;
         if(!Modifier.isStatic(f.getModifiers())) {
            int s = fi.init.compile(f.getType(), f.getName(), code, parameters, jv);
            if(stacksize < s) {
               stacksize = s;
            }
         }
      }

      return stacksize;
   }

   Hashtable getHiddenMethods() {
      if(this.hiddenMethods == null) {
         this.hiddenMethods = new Hashtable();
      }

      return this.hiddenMethods;
   }

   int getUniqueNumber() {
      return this.uniqueNumberSeed++;
   }

   public String makeUniqueName(String prefix) {
      HashMap table = new HashMap();
      this.makeMemberList(table);
      Set keys = table.keySet();
      String[] methods = new String[keys.size()];
      keys.toArray(methods);
      if(notFindInArray(prefix, methods)) {
         return prefix;
      } else {
         int i = 100;

         while(i <= 999) {
            String name = prefix + i++;
            if(notFindInArray(name, methods)) {
               return name;
            }
         }

         throw new RuntimeException("too many unique name");
      }
   }

   private static boolean notFindInArray(String prefix, String[] values) {
      int len = values.length;

      for(int i = 0; i < len; ++i) {
         if(values[i].startsWith(prefix)) {
            return false;
         }
      }

      return true;
   }

   private void makeMemberList(HashMap table) {
      int mod = this.getModifiers();
      int n;
      int i;
      if(Modifier.isAbstract(mod) || Modifier.isInterface(mod)) {
         try {
            CtClass[] list = this.getInterfaces();
            n = list.length;

            for(i = 0; i < n; ++i) {
               CtClass finfo = list[i];
               if(finfo != null && finfo instanceof CtClassType) {
                  ((CtClassType)finfo).makeMemberList(table);
               }
            }
         } catch (NotFoundException var8) {
            ;
         }
      }

      try {
         CtClass var9 = this.getSuperclass();
         if(var9 != null && var9 instanceof CtClassType) {
            ((CtClassType)var9).makeMemberList(table);
         }
      } catch (NotFoundException var7) {
         ;
      }

      List var10 = this.getClassFile2().getMethods();
      n = var10.size();

      for(i = 0; i < n; ++i) {
         MethodInfo var11 = (MethodInfo)var10.get(i);
         table.put(var11.getName(), this);
      }

      var10 = this.getClassFile2().getFields();
      n = var10.size();

      for(i = 0; i < n; ++i) {
         FieldInfo var12 = (FieldInfo)var10.get(i);
         table.put(var12.getName(), this);
      }

   }
}
