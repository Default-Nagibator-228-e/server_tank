package javassist;

import java.io.InputStream;
import java.net.URL;
import javassist.ClassPath;

public class ClassClassPath implements ClassPath {
   private Class thisClass;
   // $FF: synthetic field
   static Class class$java$lang$Object;

   public ClassClassPath(Class c) {
      this.thisClass = c;
   }

   ClassClassPath() {
      this(class$java$lang$Object == null?(class$java$lang$Object = class$("java.lang.Object")):class$java$lang$Object);
   }

   public InputStream openClassfile(String classname) {
      String jarname = "/" + classname.replace('.', '/') + ".class";
      return this.thisClass.getResourceAsStream(jarname);
   }

   public URL find(String classname) {
      String jarname = "/" + classname.replace('.', '/') + ".class";
      return this.thisClass.getResource(jarname);
   }

   public void close() {
   }

   public String toString() {
      return this.thisClass.getName() + ".class";
   }

   // $FF: synthetic method
   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }
}
