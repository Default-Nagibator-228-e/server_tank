package javassist;

import javassist.CannotCompileException;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.Modifier;
import javassist.NotFoundException;
import javassist.bytecode.BadBytecode;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.CodeIterator;
import javassist.bytecode.ConstPool;
import javassist.bytecode.MethodInfo;
import javassist.convert.TransformAfter;
import javassist.convert.TransformBefore;
import javassist.convert.TransformCall;
import javassist.convert.TransformFieldAccess;
import javassist.convert.TransformNew;
import javassist.convert.TransformReadField;
import javassist.convert.TransformWriteField;
import javassist.convert.Transformer;

public class CodeConverter {
   Transformer transformers = null;

   public void replaceNew(CtClass newClass, CtClass calledClass, String calledMethod) {
      this.transformers = new TransformNew(this.transformers, newClass.getName(), calledClass.getName(), calledMethod);
   }

   public void redirectFieldAccess(CtField field, CtClass newClass, String newFieldname) {
      this.transformers = new TransformFieldAccess(this.transformers, field, newClass.getName(), newFieldname);
   }

   public void replaceFieldRead(CtField field, CtClass calledClass, String calledMethod) {
      this.transformers = new TransformReadField(this.transformers, field, calledClass.getName(), calledMethod);
   }

   public void replaceFieldWrite(CtField field, CtClass calledClass, String calledMethod) {
      this.transformers = new TransformWriteField(this.transformers, field, calledClass.getName(), calledMethod);
   }

   public void redirectMethodCall(CtMethod origMethod, CtMethod substMethod) throws CannotCompileException {
      String d1 = origMethod.getMethodInfo2().getDescriptor();
      String d2 = substMethod.getMethodInfo2().getDescriptor();
      if(!d1.equals(d2)) {
         throw new CannotCompileException("signature mismatch");
      } else {
         int mod1 = origMethod.getModifiers();
         int mod2 = substMethod.getModifiers();
         if(Modifier.isStatic(mod1) == Modifier.isStatic(mod2) && (!Modifier.isPrivate(mod1) || Modifier.isPrivate(mod2)) && origMethod.getDeclaringClass().isInterface() == substMethod.getDeclaringClass().isInterface()) {
            this.transformers = new TransformCall(this.transformers, origMethod, substMethod);
         } else {
            throw new CannotCompileException("invoke-type mismatch");
         }
      }
   }

   public void redirectMethodCall(String oldMethodName, CtMethod newMethod) throws CannotCompileException {
      this.transformers = new TransformCall(this.transformers, oldMethodName, newMethod);
   }

   public void insertBeforeMethod(CtMethod origMethod, CtMethod beforeMethod) throws CannotCompileException {
      try {
         this.transformers = new TransformBefore(this.transformers, origMethod, beforeMethod);
      } catch (NotFoundException var4) {
         throw new CannotCompileException(var4);
      }
   }

   public void insertAfterMethod(CtMethod origMethod, CtMethod afterMethod) throws CannotCompileException {
      try {
         this.transformers = new TransformAfter(this.transformers, origMethod, afterMethod);
      } catch (NotFoundException var4) {
         throw new CannotCompileException(var4);
      }
   }

   void doit(CtClass clazz, MethodInfo minfo, ConstPool cp) throws CannotCompileException {
      CodeAttribute codeAttr = minfo.getCodeAttribute();
      if(codeAttr != null && this.transformers != null) {
         Transformer t;
         for(t = this.transformers; t != null; t = t.getNext()) {
            t.initialize(cp, codeAttr);
         }

         CodeIterator iterator = codeAttr.iterator();

         int locals;
         while(iterator.hasNext()) {
            try {
               locals = iterator.next();

               for(t = this.transformers; t != null; t = t.getNext()) {
                  locals = t.transform(clazz, locals, iterator, cp);
               }
            } catch (BadBytecode var9) {
               throw new CannotCompileException(var9);
            }
         }

         locals = 0;

         for(t = this.transformers; t != null; t = t.getNext()) {
            int s = t.extraLocals();
            if(s > locals) {
               locals = s;
            }
         }

         for(t = this.transformers; t != null; t = t.getNext()) {
            t.clean();
         }

         codeAttr.setMaxLocals(codeAttr.getMaxLocals() + locals);
      }
   }
}
