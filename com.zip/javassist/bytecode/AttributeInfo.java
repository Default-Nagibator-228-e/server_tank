package javassist.bytecode;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Map;
import javassist.bytecode.AnnotationDefaultAttribute;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.ConstPool;
import javassist.bytecode.ConstantAttribute;
import javassist.bytecode.DeprecatedAttribute;
import javassist.bytecode.EnclosingMethodAttribute;
import javassist.bytecode.ExceptionsAttribute;
import javassist.bytecode.InnerClassesAttribute;
import javassist.bytecode.LineNumberAttribute;
import javassist.bytecode.LocalVariableAttribute;
import javassist.bytecode.ParameterAnnotationsAttribute;
import javassist.bytecode.SignatureAttribute;
import javassist.bytecode.SourceFileAttribute;
import javassist.bytecode.StackMapTable;
import javassist.bytecode.SyntheticAttribute;

public class AttributeInfo {
   protected ConstPool constPool;
   int name;
   byte[] info;

   protected AttributeInfo(ConstPool cp, int attrname, byte[] attrinfo) {
      this.constPool = cp;
      this.name = attrname;
      this.info = attrinfo;
   }

   protected AttributeInfo(ConstPool cp, String attrname) {
      this(cp, attrname, (byte[])null);
   }

   public AttributeInfo(ConstPool cp, String attrname, byte[] attrinfo) {
      this(cp, cp.addUtf8Info(attrname), attrinfo);
   }

   protected AttributeInfo(ConstPool cp, int n, DataInputStream in) throws IOException {
      this.constPool = cp;
      this.name = n;
      int len = in.readInt();
      this.info = new byte[len];
      if(len > 0) {
         in.readFully(this.info);
      }

   }

   static AttributeInfo read(ConstPool cp, DataInputStream in) throws IOException {
      int name = in.readUnsignedShort();
      String nameStr = cp.getUtf8Info(name);
      if(nameStr.charAt(0) < 76) {
         if(nameStr.equals("AnnotationDefault")) {
            return new AnnotationDefaultAttribute(cp, name, in);
         } else if(nameStr.equals("Code")) {
            return new CodeAttribute(cp, name, in);
         } else if(nameStr.equals("ConstantValue")) {
            return new ConstantAttribute(cp, name, in);
         } else if(nameStr.equals("Deprecated")) {
            return new DeprecatedAttribute(cp, name, in);
         } else if(nameStr.equals("EnclosingMethod")) {
            return new EnclosingMethodAttribute(cp, name, in);
         } else if(nameStr.equals("Exceptions")) {
            return new ExceptionsAttribute(cp, name, in);
         } else if(nameStr.equals("InnerClasses")) {
            return new InnerClassesAttribute(cp, name, in);
         } else {
            return new AttributeInfo(cp, name, in);
         }
      } else if(nameStr.equals("LineNumberTable")) {
         return new LineNumberAttribute(cp, name, in);
      } else if(!nameStr.equals("LocalVariableTable") && !nameStr.equals("LocalVariableTypeTable")) {
         if(!nameStr.equals("RuntimeVisibleAnnotations") && !nameStr.equals("RuntimeInvisibleAnnotations")) {
            if(!nameStr.equals("RuntimeVisibleParameterAnnotations") && !nameStr.equals("RuntimeInvisibleParameterAnnotations")) {
               if(nameStr.equals("Signature")) {
                  return new SignatureAttribute(cp, name, in);
               } else if(nameStr.equals("SourceFile")) {
                  return new SourceFileAttribute(cp, name, in);
               } else if(nameStr.equals("Synthetic")) {
                  return new SyntheticAttribute(cp, name, in);
               } else if(nameStr.equals("StackMapTable")) {
                  return new StackMapTable(cp, name, in);
               } else {
                  return new AttributeInfo(cp, name, in);
               }
            } else {
               return new ParameterAnnotationsAttribute(cp, name, in);
            }
         } else {
            return new AnnotationsAttribute(cp, name, in);
         }
      } else {
         return new LocalVariableAttribute(cp, name, in);
      }
   }

   public String getName() {
      return this.constPool.getUtf8Info(this.name);
   }

   public ConstPool getConstPool() {
      return this.constPool;
   }

   public int length() {
      return this.info.length + 6;
   }

   public byte[] get() {
      return this.info;
   }

   public void set(byte[] newinfo) {
      this.info = newinfo;
   }

   public AttributeInfo copy(ConstPool newCp, Map classnames) {
      int s = this.info.length;
      byte[] srcInfo = this.info;
      byte[] newInfo = new byte[s];

      for(int i = 0; i < s; ++i) {
         newInfo[i] = srcInfo[i];
      }

      return new AttributeInfo(newCp, this.getName(), newInfo);
   }

   void write(DataOutputStream out) throws IOException {
      out.writeShort(this.name);
      out.writeInt(this.info.length);
      if(this.info.length > 0) {
         out.write(this.info);
      }

   }

   static int getLength(LinkedList list) {
      int size = 0;
      int n = list.size();

      for(int i = 0; i < n; ++i) {
         AttributeInfo attr = (AttributeInfo)list.get(i);
         size += attr.length();
      }

      return size;
   }

   static AttributeInfo lookup(LinkedList list, String name) {
      if(list == null) {
         return null;
      } else {
         ListIterator iterator = list.listIterator();

         AttributeInfo ai;
         do {
            if(!iterator.hasNext()) {
               return null;
            }

            ai = (AttributeInfo)iterator.next();
         } while(!ai.getName().equals(name));

         return ai;
      }
   }

   static synchronized void remove(LinkedList list, String name) {
      if(list != null) {
         ListIterator iterator = list.listIterator();

         while(iterator.hasNext()) {
            AttributeInfo ai = (AttributeInfo)iterator.next();
            if(ai.getName().equals(name)) {
               iterator.remove();
            }
         }

      }
   }

   static void writeAll(LinkedList list, DataOutputStream out) throws IOException {
      if(list != null) {
         int n = list.size();

         for(int i = 0; i < n; ++i) {
            AttributeInfo attr = (AttributeInfo)list.get(i);
            attr.write(out);
         }

      }
   }

   static LinkedList copyAll(LinkedList list, ConstPool cp) {
      if(list == null) {
         return null;
      } else {
         LinkedList newList = new LinkedList();
         int n = list.size();

         for(int i = 0; i < n; ++i) {
            AttributeInfo attr = (AttributeInfo)list.get(i);
            newList.add(attr.copy(cp, (Map)null));
         }

         return newList;
      }
   }
}
