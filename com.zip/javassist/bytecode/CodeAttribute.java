package javassist.bytecode;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.BadBytecode;
import javassist.bytecode.CodeAnalyzer;
import javassist.bytecode.CodeIterator;
import javassist.bytecode.ConstPool;
import javassist.bytecode.ExceptionTable;
import javassist.bytecode.LdcEntry;
import javassist.bytecode.Opcode;

public class CodeAttribute extends AttributeInfo implements Opcode {
   public static final String tag = "Code";
   private int maxStack;
   private int maxLocals;
   private ExceptionTable exceptions;
   private LinkedList attributes;

   public CodeAttribute(ConstPool cp, int stack, int locals, byte[] code, ExceptionTable etable) {
      super(cp, "Code");
      this.maxStack = stack;
      this.maxLocals = locals;
      this.info = code;
      this.exceptions = etable;
      this.attributes = new LinkedList();
   }

   private CodeAttribute(ConstPool cp, CodeAttribute src, Map classnames) throws BadBytecode {
      super(cp, "Code");
      this.maxStack = src.getMaxStack();
      this.maxLocals = src.getMaxLocals();
      this.exceptions = src.getExceptionTable().copy(cp, classnames);
      this.info = src.copyCode(cp, classnames, this.exceptions, this);
      this.attributes = new LinkedList();
      List src_attr = src.getAttributes();
      int num = src_attr.size();

      for(int i = 0; i < num; ++i) {
         AttributeInfo ai = (AttributeInfo)src_attr.get(i);
         this.attributes.add(ai.copy(cp, classnames));
      }

   }

   CodeAttribute(ConstPool cp, int name_id, DataInputStream in) throws IOException {
      super(cp, name_id, (byte[])null);
      int attr_len = in.readInt();
      this.maxStack = in.readUnsignedShort();
      this.maxLocals = in.readUnsignedShort();
      int code_len = in.readInt();
      this.info = new byte[code_len];
      in.readFully(this.info);
      this.exceptions = new ExceptionTable(cp, in);
      this.attributes = new LinkedList();
      int num = in.readUnsignedShort();

      for(int i = 0; i < num; ++i) {
         this.attributes.add(AttributeInfo.read(cp, in));
      }

   }

   public AttributeInfo copy(ConstPool newCp, Map classnames) throws CodeAttribute.RuntimeCopyException {
      try {
         return new CodeAttribute(newCp, this, classnames);
      } catch (BadBytecode var4) {
         throw new CodeAttribute.RuntimeCopyException("bad bytecode. fatal?");
      }
   }

   public int length() {
      return 18 + this.info.length + this.exceptions.size() * 8 + AttributeInfo.getLength(this.attributes);
   }

   void write(DataOutputStream out) throws IOException {
      out.writeShort(this.name);
      out.writeInt(this.length() - 6);
      out.writeShort(this.maxStack);
      out.writeShort(this.maxLocals);
      out.writeInt(this.info.length);
      out.write(this.info);
      this.exceptions.write(out);
      out.writeShort(this.attributes.size());
      AttributeInfo.writeAll(this.attributes, out);
   }

   public byte[] get() {
      throw new UnsupportedOperationException("CodeAttribute.get()");
   }

   public void set(byte[] newinfo) {
      throw new UnsupportedOperationException("CodeAttribute.set()");
   }

   public String getDeclaringClass() {
      ConstPool cp = this.getConstPool();
      return cp.getClassName();
   }

   public int getMaxStack() {
      return this.maxStack;
   }

   public void setMaxStack(int value) {
      this.maxStack = value;
   }

   public int computeMaxStack() throws BadBytecode {
      this.maxStack = (new CodeAnalyzer(this)).computeMaxStack();
      return this.maxStack;
   }

   public int getMaxLocals() {
      return this.maxLocals;
   }

   public void setMaxLocals(int value) {
      this.maxLocals = value;
   }

   public int getCodeLength() {
      return this.info.length;
   }

   public byte[] getCode() {
      return this.info;
   }

   void setCode(byte[] newinfo) {
      super.set(newinfo);
   }

   public CodeIterator iterator() {
      return new CodeIterator(this);
   }

   public ExceptionTable getExceptionTable() {
      return this.exceptions;
   }

   public List getAttributes() {
      return this.attributes;
   }

   public AttributeInfo getAttribute(String name) {
      return AttributeInfo.lookup(this.attributes, name);
   }

   private byte[] copyCode(ConstPool destCp, Map classnames, ExceptionTable etable, CodeAttribute destCa) throws BadBytecode {
      int len = this.getCodeLength();
      byte[] newCode = new byte[len];
      LdcEntry ldc = copyCode(this.info, 0, len, this.getConstPool(), newCode, destCp, classnames);
      return LdcEntry.doit(newCode, ldc, etable, destCa);
   }

   private static LdcEntry copyCode(byte[] code, int beginPos, int endPos, ConstPool srcCp, byte[] newcode, ConstPool destCp, Map classnameMap) throws BadBytecode {
      LdcEntry ldcEntry = null;

      int i2;
      for(int i = beginPos; i < endPos; i = i2) {
         i2 = CodeIterator.nextOpcode(code, i);
         int c = code[i];
         newcode[i] = (byte)c;
         switch(c & 255) {
         case 18:
            int index = code[i + 1] & 255;
            index = srcCp.copy(index, destCp, classnameMap);
            if(index < 256) {
               newcode[i + 1] = (byte)index;
            } else {
               LdcEntry ldc = new LdcEntry();
               ldc.where = i;
               ldc.index = index;
               ldc.next = ldcEntry;
               ldcEntry = ldc;
            }
            break;
         case 19:
         case 20:
         case 178:
         case 179:
         case 180:
         case 181:
         case 182:
         case 183:
         case 184:
         case 187:
         case 189:
         case 192:
         case 193:
            copyConstPoolInfo(i + 1, code, srcCp, newcode, destCp, classnameMap);
            break;
         case 185:
            copyConstPoolInfo(i + 1, code, srcCp, newcode, destCp, classnameMap);
            newcode[i + 3] = code[i + 3];
            newcode[i + 4] = code[i + 4];
            break;
         case 197:
            copyConstPoolInfo(i + 1, code, srcCp, newcode, destCp, classnameMap);
            newcode[i + 3] = code[i + 3];
            break;
         default:
            while(true) {
               ++i;
               if(i >= i2) {
                  break;
               }

               newcode[i] = code[i];
            }
         }
      }

      return ldcEntry;
   }

   private static void copyConstPoolInfo(int i, byte[] code, ConstPool srcCp, byte[] newcode, ConstPool destCp, Map classnameMap) {
      int index = (code[i] & 255) << 8 | code[i + 1] & 255;
      index = srcCp.copy(index, destCp, classnameMap);
      newcode[i] = (byte)(index >> 8);
      newcode[i + 1] = (byte)index;
   }

   public static class RuntimeCopyException extends RuntimeException {
      public RuntimeCopyException(String s) {
         super(s);
      }
   }
}
