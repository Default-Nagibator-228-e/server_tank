package javassist.bytecode;

class AlignmentException extends Exception {
}
