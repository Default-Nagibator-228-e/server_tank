package javassist.bytecode.annotation;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.bytecode.AnnotationDefaultAttribute;
import javassist.bytecode.ClassFile;
import javassist.bytecode.MethodInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.MemberValue;

public class AnnotationImpl implements InvocationHandler {
   private Annotation annotation;
   private ClassPool pool;
   private ClassLoader classLoader;
   // $FF: synthetic field
   static Class class$java$lang$Object;

   public static Object make(ClassLoader cl, Class clazz, ClassPool cp, Annotation anon) {
      AnnotationImpl handler = new AnnotationImpl(anon, cp, cl);
      return Proxy.newProxyInstance(cl, new Class[]{clazz}, handler);
   }

   private AnnotationImpl(Annotation a, ClassPool cp, ClassLoader loader) {
      this.annotation = a;
      this.pool = cp;
      this.classLoader = loader;
   }

   public String getTypeName() {
      return this.annotation.getTypeName();
   }

   public Annotation getAnnotation() {
      return this.annotation;
   }

   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
      String name = method.getName();
      if((class$java$lang$Object == null?(class$java$lang$Object = class$("java.lang.Object")):class$java$lang$Object) == method.getDeclaringClass()) {
         if("equals".equals(name)) {
            Object mv = args[0];
            if(mv != null && mv instanceof Proxy) {
               InvocationHandler other = Proxy.getInvocationHandler(mv);
               if(this.equals(other)) {
                  return Boolean.TRUE;
               }

               return Boolean.FALSE;
            }

            return Boolean.FALSE;
         }

         if("toString".equals(name)) {
            return this.annotation.getTypeName() + '@' + this.hashCode();
         }

         if("hashCode".equals(name)) {
            return new Integer(this.hashCode());
         }
      } else if("annotationType".equals(name) && method.getParameterTypes().length == 0) {
         return this.classLoader.loadClass(this.getTypeName());
      }

      MemberValue mv1 = this.annotation.getMemberValue(name);
      return mv1 == null?this.getDefault(name, method):mv1.getValue(this.classLoader, this.pool, method);
   }

   private Object getDefault(String name, Method method) throws ClassNotFoundException, RuntimeException {
      String classname = this.annotation.getTypeName();
      if(this.pool != null) {
         try {
            CtClass e = this.pool.get(classname);
            ClassFile cf = e.getClassFile2();
            MethodInfo minfo = cf.getMethod(name);
            if(minfo != null) {
               AnnotationDefaultAttribute ainfo = (AnnotationDefaultAttribute)minfo.getAttribute("AnnotationDefault");
               if(ainfo != null) {
                  MemberValue mv = ainfo.getDefaultValue();
                  return mv.getValue(this.classLoader, this.pool, method);
               }
            }
         } catch (NotFoundException var9) {
            throw new RuntimeException("cannot find a class file: " + classname);
         }
      }

      throw new RuntimeException("no default value: " + classname + "." + name + "()");
   }

   // $FF: synthetic method
   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }
}
