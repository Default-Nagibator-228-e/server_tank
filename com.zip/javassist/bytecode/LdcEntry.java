package javassist.bytecode;

import javassist.bytecode.BadBytecode;
import javassist.bytecode.ByteArray;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.CodeIterator;
import javassist.bytecode.ExceptionTable;

final class LdcEntry {
   LdcEntry next;
   int where;
   int index;

   static byte[] doit(byte[] code, LdcEntry ldc, ExceptionTable etable, CodeAttribute ca) throws BadBytecode {
      while(ldc != null) {
         int where = ldc.where;
         code = CodeIterator.insertGap(code, where, 1, false, etable, ca);
         code[where] = 19;
         ByteArray.write16bit(ldc.index, code, where + 1);
         ldc = ldc.next;
      }

      return code;
   }
}
