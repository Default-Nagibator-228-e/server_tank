package javassist.bytecode;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.Map;
import javassist.bytecode.AttributeInfo;
import javassist.bytecode.ByteArray;
import javassist.bytecode.ConstPool;

public class SignatureAttribute extends AttributeInfo {
   public static final String tag = "Signature";

   SignatureAttribute(ConstPool cp, int n, DataInputStream in) throws IOException {
      super(cp, n, in);
   }

   public SignatureAttribute(ConstPool cp, String signature) {
      super(cp, "Signature");
      int index = cp.addUtf8Info(signature);
      byte[] bvalue = new byte[]{(byte)(index >>> 8), (byte)index};
      this.set(bvalue);
   }

   public String getSignature() {
      return this.getConstPool().getUtf8Info(ByteArray.readU16bit(this.get(), 0));
   }

   public AttributeInfo copy(ConstPool newCp, Map classnames) {
      return new SignatureAttribute(newCp, this.getSignature());
   }
}
