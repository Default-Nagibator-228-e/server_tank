package javassist.util.proxy;

import javassist.util.proxy.MethodHandler;

public interface ProxyObject {
   void setHandler(MethodHandler var1);
}
