package javassist.util.proxy;

import java.io.InvalidClassException;
import java.io.InvalidObjectException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import javassist.util.proxy.MethodFilter;
import javassist.util.proxy.MethodHandler;
import javassist.util.proxy.ProxyFactory;

class SerializedProxy implements Serializable {
   private String superClass;
   private String[] interfaces;
   private MethodFilter filter;
   private MethodHandler handler;
   // $FF: synthetic field
   static Class class$javassist$util$proxy$ProxyObject;

   SerializedProxy(Class proxy, MethodFilter f, MethodHandler h) {
      this.filter = f;
      this.handler = h;
      this.superClass = proxy.getSuperclass().getName();
      Class[] infs = proxy.getInterfaces();
      int n = infs.length;
      this.interfaces = new String[n - 1];
      String setterInf = (class$javassist$util$proxy$ProxyObject == null?(class$javassist$util$proxy$ProxyObject = class$("javassist.util.proxy.ProxyObject")):class$javassist$util$proxy$ProxyObject).getName();

      for(int i = 0; i < n; ++i) {
         String name = infs[i].getName();
         if(!name.equals(setterInf)) {
            this.interfaces[i] = name;
         }
      }

   }

   Object readResolve() throws ObjectStreamException {
      try {
         int e3 = this.interfaces.length;
         Class[] infs = new Class[e3];

         for(int f = 0; f < e3; ++f) {
            infs[f] = Class.forName(this.interfaces[f]);
         }

         ProxyFactory var7 = new ProxyFactory();
         var7.setSuperclass(Class.forName(this.superClass));
         var7.setInterfaces(infs);
         var7.setFilter(this.filter);
         var7.setHandler(this.handler);
         return var7.createClass().newInstance();
      } catch (ClassNotFoundException var4) {
         throw new InvalidClassException(var4.getMessage());
      } catch (InstantiationException var5) {
         throw new InvalidObjectException(var5.getMessage());
      } catch (IllegalAccessException var6) {
         throw new InvalidClassException(var6.getMessage());
      }
   }

   // $FF: synthetic method
   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }
}
