package javassist.util.proxy;

import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.Map.Entry;
import javassist.CannotCompileException;
import javassist.bytecode.Bytecode;
import javassist.bytecode.ClassFile;
import javassist.bytecode.ConstPool;
import javassist.bytecode.Descriptor;
import javassist.bytecode.DuplicateMemberException;
import javassist.bytecode.ExceptionsAttribute;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.MethodInfo;
import javassist.util.proxy.FactoryHelper;
import javassist.util.proxy.MethodFilter;
import javassist.util.proxy.MethodHandler;
import javassist.util.proxy.ProxyObject;
import javassist.util.proxy.RuntimeSupport;

public class ProxyFactory {
   private Class superClass = null;
   private Class[] interfaces = null;
   private MethodFilter methodFilter = null;
   private MethodHandler handler = null;
   private Class thisClass = null;
   public String writeDirectory = null;
   private static final Class OBJECT_TYPE;
   private static final String HOLDER = "_methods_";
   private static final String HOLDER_TYPE = "[Ljava/lang/reflect/Method;";
   private static final String METHOD_FILTER_FIELD = "_method_filter";
   private static final String HANDLER = "handler";
   private static final String NULL_INTERCEPTOR_HOLDER = "javassist.util.proxy.RuntimeSupport";
   private static final String DEFAULT_INTERCEPTOR = "default_interceptor";
   private static final String HANDLER_TYPE;
   private static final String HANDLER_SETTER = "setHandler";
   private static final String HANDLER_SETTER_TYPE;
   public static boolean useCache;
   private static WeakHashMap proxyCache;
   public static ProxyFactory.ClassLoaderProvider classLoaderProvider;
   private static int counter;
   // $FF: synthetic field
   static Class class$java$lang$Object;
   // $FF: synthetic field
   static Class class$javassist$util$proxy$MethodHandler;
   // $FF: synthetic field
   static Class class$javassist$util$proxy$ProxyObject;
   // $FF: synthetic field
   static Class class$javassist$util$proxy$RuntimeSupport;

   public void setSuperclass(Class clazz) {
      this.superClass = clazz;
   }

   public Class getSuperclass() {
      return this.superClass;
   }

   public void setInterfaces(Class[] ifs) {
      this.interfaces = ifs;
   }

   public Class[] getInterfaces() {
      return this.interfaces;
   }

   public void setFilter(MethodFilter mf) {
      this.methodFilter = mf;
   }

   public Class createClass() {
      if(this.thisClass == null) {
         ClassLoader cl = this.getClassLoader();
         WeakHashMap var2 = proxyCache;
         synchronized(proxyCache) {
            if(useCache) {
               this.createClass2(cl);
            } else {
               this.createClass3(cl);
            }
         }
      }

      return this.thisClass;
   }

   private void createClass2(ClassLoader cl) {
      ProxyFactory.CacheKey key = new ProxyFactory.CacheKey(this.superClass, this.interfaces, this.methodFilter, this.handler);
      HashMap cacheForTheLoader = (HashMap)proxyCache.get(cl);
      if(cacheForTheLoader == null) {
         cacheForTheLoader = new HashMap();
         proxyCache.put(cl, cacheForTheLoader);
         cacheForTheLoader.put(key, key);
      } else {
         ProxyFactory.CacheKey c = (ProxyFactory.CacheKey)cacheForTheLoader.get(key);
         if(c == null) {
            cacheForTheLoader.put(key, key);
         } else {
            key = c;
            Class c1 = this.isValidEntry(c);
            if(c1 != null) {
               this.thisClass = c1;
               return;
            }
         }
      }

      Class c2 = this.isValidEntry(key);
      if(c2 == null) {
         this.createClass3(cl);
         key.proxyClass = new WeakReference(this.thisClass);
      } else {
         this.thisClass = c2;
      }

   }

   private Class isValidEntry(ProxyFactory.CacheKey key) {
      WeakReference ref = key.proxyClass;
      if(ref != null) {
         Class c = (Class)ref.get();
         if(c != null) {
            return c;
         }
      }

      return null;
   }

   private void createClass3(ClassLoader cl) {
      try {
         ClassFile e = this.make();
         if(this.writeDirectory != null) {
            FactoryHelper.writeFile(e, this.writeDirectory);
         }

         this.thisClass = FactoryHelper.toClass(e, cl, this.getDomain());
         this.setField("default_interceptor", this.handler);
         this.setField("_method_filter", this.methodFilter);
      } catch (CannotCompileException var3) {
         throw new RuntimeException(var3.getMessage(), var3);
      }
   }

   private void setField(String fieldName, Object value) {
      if(this.thisClass != null && value != null) {
         try {
            Field e = this.thisClass.getField(fieldName);
            e.setAccessible(true);
            e.set((Object)null, value);
            e.setAccessible(false);
         } catch (Exception var4) {
            throw new RuntimeException(var4);
         }
      }

   }

   static MethodFilter getFilter(Class clazz) {
      return (MethodFilter)getField(clazz, "_method_filter");
   }

   static MethodHandler getHandler(Class clazz) {
      return (MethodHandler)getField(clazz, "default_interceptor");
   }

   private static Object getField(Class clazz, String fieldName) {
      try {
         Field e = clazz.getField(fieldName);
         e.setAccessible(true);
         Object value = e.get((Object)null);
         e.setAccessible(false);
         return value;
      } catch (Exception var4) {
         throw new RuntimeException(var4);
      }
   }

   protected ClassLoader getClassLoader() {
      return classLoaderProvider.get(this);
   }

   protected ClassLoader getClassLoader0() {
      ClassLoader loader = null;
      if(this.superClass != null && !this.superClass.getName().equals("java.lang.Object")) {
         loader = this.superClass.getClassLoader();
      } else if(this.interfaces != null && this.interfaces.length > 0) {
         loader = this.interfaces[0].getClassLoader();
      }

      if(loader == null) {
         loader = this.getClass().getClassLoader();
         if(loader == null) {
            loader = Thread.currentThread().getContextClassLoader();
            if(loader == null) {
               loader = ClassLoader.getSystemClassLoader();
            }
         }
      }

      return loader;
   }

   protected ProtectionDomain getDomain() {
      Class clazz;
      if(this.superClass != null && !this.superClass.getName().equals("java.lang.Object")) {
         clazz = this.superClass;
      } else if(this.interfaces != null && this.interfaces.length > 0) {
         clazz = this.interfaces[0];
      } else {
         clazz = this.getClass();
      }

      return clazz.getProtectionDomain();
   }

   public Object create(Class[] paramTypes, Object[] args, MethodHandler mh) throws NoSuchMethodException, IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
      Object obj = this.create(paramTypes, args);
      ((ProxyObject)obj).setHandler(mh);
      return obj;
   }

   public Object create(Class[] paramTypes, Object[] args) throws NoSuchMethodException, IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
      Class c = this.createClass();
      Constructor cons = c.getConstructor(paramTypes);
      return cons.newInstance(args);
   }

   public void setHandler(MethodHandler mi) {
      this.handler = mi;
      this.setField("default_interceptor", this.handler);
   }

   private static synchronized String makeProxyName(String classname) {
      return classname + "_$$_javassist_" + counter++;
   }

   private ClassFile make() throws CannotCompileException {
      if(this.interfaces == null) {
         this.interfaces = new Class[0];
      }

      String superName;
      String classname;
      if(this.superClass == null) {
         this.superClass = OBJECT_TYPE;
         superName = this.superClass.getName();
         classname = this.interfaces.length == 0?superName:this.interfaces[0].getName();
      } else {
         superName = this.superClass.getName();
         classname = superName;
      }

      if(Modifier.isFinal(this.superClass.getModifiers())) {
         throw new CannotCompileException(superName + " is final");
      } else {
         classname = makeProxyName(classname);
         if(classname.startsWith("java.")) {
            classname = "org.javassist.tmp." + classname;
         }

         ClassFile cf = new ClassFile(false, classname, superName);
         cf.setAccessFlags(1);
         setInterfaces(cf, this.interfaces);
         ConstPool pool = cf.getConstPool();
         FieldInfo finfo = new FieldInfo(pool, "default_interceptor", HANDLER_TYPE);
         finfo.setAccessFlags(9);
         cf.addField(finfo);
         FieldInfo finfo2 = new FieldInfo(pool, "handler", HANDLER_TYPE);
         finfo2.setAccessFlags(2);
         cf.addField(finfo2);
         FieldInfo finfo3 = new FieldInfo(pool, "_method_filter", "Ljavassist/util/proxy/MethodFilter;");
         finfo3.setAccessFlags(9);
         cf.addField(finfo3);
         HashMap allMethods = getMethods(this.superClass, this.interfaces);
         int size = allMethods.size();
         this.makeConstructors(classname, cf, pool, classname);
         int s = this.overrideMethods(cf, pool, classname, allMethods);
         addMethodsHolder(cf, pool, classname, s);
         addSetter(classname, cf, pool);

         try {
            cf.addMethod(makeWriteReplace(pool));
         } catch (DuplicateMemberException var12) {
            ;
         }

         this.thisClass = null;
         return cf;
      }
   }

   private static void setInterfaces(ClassFile cf, Class[] interfaces) {
      String setterIntf = (class$javassist$util$proxy$ProxyObject == null?(class$javassist$util$proxy$ProxyObject = class$("javassist.util.proxy.ProxyObject")):class$javassist$util$proxy$ProxyObject).getName();
      String[] list;
      if(interfaces != null && interfaces.length != 0) {
         list = new String[interfaces.length + 1];

         for(int i = 0; i < interfaces.length; ++i) {
            list[i] = interfaces[i].getName();
         }

         list[interfaces.length] = setterIntf;
      } else {
         list = new String[]{setterIntf};
      }

      cf.setInterfaces(list);
   }

   private static void addMethodsHolder(ClassFile cf, ConstPool cp, String classname, int size) throws CannotCompileException {
      FieldInfo finfo = new FieldInfo(cp, "_methods_", "[Ljava/lang/reflect/Method;");
      finfo.setAccessFlags(10);
      cf.addField(finfo);
      MethodInfo minfo = new MethodInfo(cp, "<clinit>", "()V");
      Bytecode code = new Bytecode(cp, 0, 0);
      code.addIconst(size * 2);
      code.addAnewarray("java.lang.reflect.Method");
      code.addPutstatic(classname, "_methods_", "[Ljava/lang/reflect/Method;");
      code.addOpcode(177);
      minfo.setCodeAttribute(code.toCodeAttribute());
      cf.addMethod(minfo);
   }

   private static void addSetter(String classname, ClassFile cf, ConstPool cp) throws CannotCompileException {
      MethodInfo minfo = new MethodInfo(cp, "setHandler", HANDLER_SETTER_TYPE);
      minfo.setAccessFlags(1);
      Bytecode code = new Bytecode(cp, 2, 2);
      code.addAload(0);
      code.addAload(1);
      code.addPutfield(classname, "handler", HANDLER_TYPE);
      code.addOpcode(177);
      minfo.setCodeAttribute(code.toCodeAttribute());
      cf.addMethod(minfo);
   }

   private int overrideMethods(ClassFile cf, ConstPool cp, String className, HashMap allMethods) throws CannotCompileException {
      String prefix = makeUniqueName("_d", allMethods);
      Set entries = allMethods.entrySet();
      Iterator it = entries.iterator();
      int index = 0;

      while(true) {
         String key;
         Method meth;
         int mod;
         do {
            do {
               do {
                  do {
                     if(!it.hasNext()) {
                        return index;
                     }

                     Entry e = (Entry)it.next();
                     key = (String)e.getKey();
                     meth = (Method)e.getValue();
                     mod = meth.getModifiers();
                  } while(Modifier.isFinal(mod));
               } while(Modifier.isStatic(mod));
            } while(!isVisible(mod, className, meth));
         } while(this.methodFilter != null && !this.methodFilter.isHandled(meth));

         this.override(className, meth, prefix, index++, keyToDesc(key), cf, cp);
      }
   }

   private void override(String thisClassname, Method meth, String prefix, int index, String desc, ClassFile cf, ConstPool cp) throws CannotCompileException {
      Class declClass = meth.getDeclaringClass();
      String delegatorName = prefix + index + meth.getName();
      MethodInfo forwarder;
      if(Modifier.isAbstract(meth.getModifiers())) {
         delegatorName = null;
      } else {
         forwarder = makeDelegator(meth, desc, cp, declClass, delegatorName);
         forwarder.setAccessFlags(forwarder.getAccessFlags() & -65);
         cf.addMethod(forwarder);
      }

      forwarder = makeForwarder(thisClassname, meth, desc, cp, declClass, delegatorName, index);
      cf.addMethod(forwarder);
   }

   private void makeConstructors(String thisClassName, ClassFile cf, ConstPool cp, String classname) throws CannotCompileException {
      Constructor[] cons = this.superClass.getDeclaredConstructors();

      for(int i = 0; i < cons.length; ++i) {
         Constructor c = cons[i];
         int mod = c.getModifiers();
         if(!Modifier.isFinal(mod) && !Modifier.isPrivate(mod) && isVisible(mod, classname, c)) {
            MethodInfo m = makeConstructor(thisClassName, c, cp, this.superClass);
            cf.addMethod(m);
         }
      }

   }

   private static String makeUniqueName(String name, HashMap hash) {
      Set keys = hash.keySet();
      if(makeUniqueName0(name, keys.iterator())) {
         return name;
      } else {
         for(int i = 100; i < 999; ++i) {
            String s = name + i;
            if(makeUniqueName0(s, keys.iterator())) {
               return s;
            }
         }

         throw new RuntimeException("cannot make a unique method name");
      }
   }

   private static boolean makeUniqueName0(String name, Iterator it) {
      while(true) {
         if(it.hasNext()) {
            String key = (String)it.next();
            if(!key.startsWith(name)) {
               continue;
            }

            return false;
         }

         return true;
      }
   }

   private static boolean isVisible(int mod, String from, Member meth) {
      if((mod & 2) != 0) {
         return false;
      } else if((mod & 5) != 0) {
         return true;
      } else {
         String p = getPackageName(from);
         String q = getPackageName(meth.getDeclaringClass().getName());
         return p == null?q == null:p.equals(q);
      }
   }

   private static String getPackageName(String name) {
      int i = name.lastIndexOf(46);
      return i < 0?null:name.substring(0, i);
   }

   private static HashMap getMethods(Class superClass, Class[] interfaceTypes) {
      HashMap hash = new HashMap();

      for(int i = 0; i < interfaceTypes.length; ++i) {
         getMethods(hash, interfaceTypes[i]);
      }

      getMethods(hash, superClass);
      return hash;
   }

   private static void getMethods(HashMap hash, Class clazz) {
      Class[] ifs = clazz.getInterfaces();

      for(int parent = 0; parent < ifs.length; ++parent) {
         getMethods(hash, ifs[parent]);
      }

      Class var8 = clazz.getSuperclass();
      if(var8 != null) {
         getMethods(hash, var8);
      }

      Method[] methods = clazz.getDeclaredMethods();

      for(int i = 0; i < methods.length; ++i) {
         if(!Modifier.isPrivate(methods[i].getModifiers())) {
            Method m = methods[i];
            String key = m.getName() + ':' + RuntimeSupport.makeDescriptor(m);
            hash.put(key, methods[i]);
         }
      }

   }

   private static String keyToDesc(String key) {
      return key.substring(key.indexOf(58) + 1);
   }

   private static MethodInfo makeConstructor(String thisClassName, Constructor cons, ConstPool cp, Class superClass) {
      String desc = RuntimeSupport.makeDescriptor(cons.getParameterTypes(), Void.TYPE);
      MethodInfo minfo = new MethodInfo(cp, "<init>", desc);
      minfo.setAccessFlags(1);
      setThrows(minfo, cp, cons.getExceptionTypes());
      Bytecode code = new Bytecode(cp, 0, 0);
      code.addAload(0);
      code.addGetstatic(thisClassName, "default_interceptor", HANDLER_TYPE);
      code.addOpcode(89);
      code.addOpcode(199);
      code.addIndex(7);
      code.addOpcode(87);
      code.addGetstatic("javassist.util.proxy.RuntimeSupport", "default_interceptor", HANDLER_TYPE);
      code.addPutfield(thisClassName, "handler", HANDLER_TYPE);
      code.addAload(0);
      int s = addLoadParameters(code, cons.getParameterTypes(), 1);
      code.addInvokespecial(superClass.getName(), "<init>", desc);
      code.addOpcode(177);
      code.setMaxLocals(s + 1);
      minfo.setCodeAttribute(code.toCodeAttribute());
      return minfo;
   }

   private static MethodInfo makeDelegator(Method meth, String desc, ConstPool cp, Class declClass, String delegatorName) {
      MethodInfo delegator = new MethodInfo(cp, delegatorName, desc);
      delegator.setAccessFlags(17 | meth.getModifiers() & -1319);
      setThrows(delegator, cp, meth);
      Bytecode code = new Bytecode(cp, 0, 0);
      code.addAload(0);
      int s = addLoadParameters(code, meth.getParameterTypes(), 1);
      code.addInvokespecial(declClass.getName(), meth.getName(), desc);
      addReturn(code, meth.getReturnType());
      ++s;
      code.setMaxLocals(s);
      delegator.setCodeAttribute(code.toCodeAttribute());
      return delegator;
   }

   private static MethodInfo makeForwarder(String thisClassName, Method meth, String desc, ConstPool cp, Class declClass, String delegatorName, int index) {
      MethodInfo forwarder = new MethodInfo(cp, meth.getName(), desc);
      forwarder.setAccessFlags(16 | meth.getModifiers() & -1313);
      setThrows(forwarder, cp, meth);
      int args = Descriptor.paramSize(desc);
      Bytecode code = new Bytecode(cp, 0, args + 2);
      int origIndex = index * 2;
      int delIndex = index * 2 + 1;
      int arrayVar = args + 1;
      code.addGetstatic(thisClassName, "_methods_", "[Ljava/lang/reflect/Method;");
      code.addAstore(arrayVar);
      code.addAload(arrayVar);
      code.addIconst(origIndex);
      code.addOpcode(50);
      code.addOpcode(199);
      int pc = code.currentPc();
      code.addIndex(0);
      callFindMethod(code, "findSuperMethod", arrayVar, origIndex, meth.getName(), desc);
      callFindMethod(code, "findMethod", arrayVar, delIndex, delegatorName, desc);
      code.write16bit(pc, code.currentPc() - pc + 1);
      code.addAload(0);
      code.addGetfield(thisClassName, "handler", HANDLER_TYPE);
      code.addAload(0);
      code.addAload(arrayVar);
      code.addIconst(origIndex);
      code.addOpcode(50);
      code.addAload(arrayVar);
      code.addIconst(delIndex);
      code.addOpcode(50);
      makeParameterList(code, meth.getParameterTypes());
      code.addInvokeinterface((String)(class$javassist$util$proxy$MethodHandler == null?(class$javassist$util$proxy$MethodHandler = class$("javassist.util.proxy.MethodHandler")):class$javassist$util$proxy$MethodHandler).getName(), "invoke", "(Ljava/lang/Object;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;", 5);
      Class retType = meth.getReturnType();
      addUnwrapper(code, retType);
      addReturn(code, retType);
      forwarder.setCodeAttribute(code.toCodeAttribute());
      return forwarder;
   }

   private static void setThrows(MethodInfo minfo, ConstPool cp, Method orig) {
      Class[] exceptions = orig.getExceptionTypes();
      setThrows(minfo, cp, exceptions);
   }

   private static void setThrows(MethodInfo minfo, ConstPool cp, Class[] exceptions) {
      if(exceptions.length != 0) {
         String[] list = new String[exceptions.length];

         for(int ea = 0; ea < exceptions.length; ++ea) {
            list[ea] = exceptions[ea].getName();
         }

         ExceptionsAttribute var5 = new ExceptionsAttribute(cp);
         var5.setExceptions(list);
         minfo.setExceptionsAttribute(var5);
      }
   }

   private static int addLoadParameters(Bytecode code, Class[] params, int offset) {
      int stacksize = 0;
      int n = params.length;

      for(int i = 0; i < n; ++i) {
         stacksize += addLoad(code, stacksize + offset, params[i]);
      }

      return stacksize;
   }

   private static int addLoad(Bytecode code, int n, Class type) {
      if(type.isPrimitive()) {
         if(type == Long.TYPE) {
            code.addLload(n);
            return 2;
         }

         if(type == Float.TYPE) {
            code.addFload(n);
         } else {
            if(type == Double.TYPE) {
               code.addDload(n);
               return 2;
            }

            code.addIload(n);
         }
      } else {
         code.addAload(n);
      }

      return 1;
   }

   private static int addReturn(Bytecode code, Class type) {
      if(type.isPrimitive()) {
         if(type == Long.TYPE) {
            code.addOpcode(173);
            return 2;
         }

         if(type == Float.TYPE) {
            code.addOpcode(174);
         } else {
            if(type == Double.TYPE) {
               code.addOpcode(175);
               return 2;
            }

            if(type == Void.TYPE) {
               code.addOpcode(177);
               return 0;
            }

            code.addOpcode(172);
         }
      } else {
         code.addOpcode(176);
      }

      return 1;
   }

   private static void makeParameterList(Bytecode code, Class[] params) {
      int regno = 1;
      int n = params.length;
      code.addIconst(n);
      code.addAnewarray("java/lang/Object");

      for(int i = 0; i < n; ++i) {
         code.addOpcode(89);
         code.addIconst(i);
         Class type = params[i];
         if(type.isPrimitive()) {
            regno = makeWrapper(code, type, regno);
         } else {
            code.addAload(regno);
            ++regno;
         }

         code.addOpcode(83);
      }

   }

   private static int makeWrapper(Bytecode code, Class type, int regno) {
      int index = FactoryHelper.typeIndex(type);
      String wrapper = FactoryHelper.wrapperTypes[index];
      code.addNew(wrapper);
      code.addOpcode(89);
      addLoad(code, regno, type);
      code.addInvokespecial(wrapper, "<init>", FactoryHelper.wrapperDesc[index]);
      return regno + FactoryHelper.dataSize[index];
   }

   private static void callFindMethod(Bytecode code, String findMethod, int arrayVar, int index, String methodName, String desc) {
      String findClass = (class$javassist$util$proxy$RuntimeSupport == null?(class$javassist$util$proxy$RuntimeSupport = class$("javassist.util.proxy.RuntimeSupport")):class$javassist$util$proxy$RuntimeSupport).getName();
      String findDesc = "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/reflect/Method;";
      code.addAload(arrayVar);
      code.addIconst(index);
      if(methodName == null) {
         code.addOpcode(1);
      } else {
         code.addAload(0);
         code.addLdc(methodName);
         code.addLdc(desc);
         code.addInvokestatic(findClass, findMethod, findDesc);
      }

      code.addOpcode(83);
   }

   private static void addUnwrapper(Bytecode code, Class type) {
      if(type.isPrimitive()) {
         if(type == Void.TYPE) {
            code.addOpcode(87);
         } else {
            int index = FactoryHelper.typeIndex(type);
            String wrapper = FactoryHelper.wrapperTypes[index];
            code.addCheckcast(wrapper);
            code.addInvokevirtual(wrapper, FactoryHelper.unwarpMethods[index], FactoryHelper.unwrapDesc[index]);
         }
      } else {
         code.addCheckcast(type.getName());
      }

   }

   private static MethodInfo makeWriteReplace(ConstPool cp) {
      MethodInfo minfo = new MethodInfo(cp, "writeReplace", "()Ljava/lang/Object;");
      String[] list = new String[]{"java.io.ObjectStreamException"};
      ExceptionsAttribute ea = new ExceptionsAttribute(cp);
      ea.setExceptions(list);
      minfo.setExceptionsAttribute(ea);
      Bytecode code = new Bytecode(cp, 0, 1);
      code.addAload(0);
      code.addInvokestatic("javassist.util.proxy.RuntimeSupport", "makeSerializedProxy", "(Ljava/lang/Object;)Ljavassist/util/proxy/SerializedProxy;");
      code.addOpcode(176);
      minfo.setCodeAttribute(code.toCodeAttribute());
      return minfo;
   }

   // $FF: synthetic method
   static Class class$(String x0) {
      try {
         return Class.forName(x0);
      } catch (ClassNotFoundException var2) {
         throw new NoClassDefFoundError(var2.getMessage());
      }
   }

   static {
      OBJECT_TYPE = class$java$lang$Object == null?(class$java$lang$Object = class$("java.lang.Object")):class$java$lang$Object;
      HANDLER_TYPE = 'L' + (class$javassist$util$proxy$MethodHandler == null?(class$javassist$util$proxy$MethodHandler = class$("javassist.util.proxy.MethodHandler")):class$javassist$util$proxy$MethodHandler).getName().replace('.', '/') + ';';
      HANDLER_SETTER_TYPE = "(" + HANDLER_TYPE + ")V";
      useCache = true;
      proxyCache = new WeakHashMap();
      classLoaderProvider = new ProxyFactory.ClassLoaderProvider() {
         public ClassLoader get(ProxyFactory pf) {
            return pf.getClassLoader0();
         }
      };
      counter = 0;
   }

   public interface ClassLoaderProvider {
      ClassLoader get(ProxyFactory var1);
   }

   static class CacheKey {
      String classes;
      MethodFilter filter;
      private int hash;
      WeakReference proxyClass;
      MethodHandler handler;

      public CacheKey(Class superClass, Class[] interfaces, MethodFilter f, MethodHandler h) {
         this.classes = getKey(superClass, interfaces);
         this.hash = this.classes.hashCode();
         this.filter = f;
         this.handler = h;
         this.proxyClass = null;
      }

      public int hashCode() {
         return this.hash;
      }

      public boolean equals(Object obj) {
         if(!(obj instanceof ProxyFactory.CacheKey)) {
            return false;
         } else {
            ProxyFactory.CacheKey target = (ProxyFactory.CacheKey)obj;
            return target.filter == this.filter && target.handler == this.handler && target.classes.equals(this.classes);
         }
      }

      static String getKey(Class superClass, Class[] interfaces) {
         StringBuffer sbuf = new StringBuffer();
         if(superClass != null) {
            sbuf.append(superClass.getName());
         }

         sbuf.append(':');
         if(interfaces != null) {
            int len = interfaces.length;

            for(int i = 0; i < len; ++i) {
               sbuf.append(interfaces[i].getName()).append(',');
            }
         }

         return sbuf.toString();
      }
   }
}
