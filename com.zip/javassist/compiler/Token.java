package javassist.compiler;

class Token {
   public Token next = null;
   public int tokenId;
   public long longValue;
   public double doubleValue;
   public String textValue;
}
