package javassist.compiler;

import javassist.bytecode.Bytecode;
import javassist.compiler.CompileError;
import javassist.compiler.JvstCodeGen;
import javassist.compiler.JvstTypeChecker;
import javassist.compiler.ast.ASTList;

public interface ProceedHandler {
   void doit(JvstCodeGen var1, Bytecode var2, ASTList var3) throws CompileError;

   void setReturnType(JvstTypeChecker var1, ASTList var2) throws CompileError;
}
