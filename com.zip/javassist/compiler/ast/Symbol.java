package javassist.compiler.ast;

import javassist.compiler.CompileError;
import javassist.compiler.ast.ASTree;
import javassist.compiler.ast.Visitor;

public class Symbol extends ASTree {
   protected String identifier;

   public Symbol(String sym) {
      this.identifier = sym;
   }

   public String get() {
      return this.identifier;
   }

   public String toString() {
      return this.identifier;
   }

   public void accept(Visitor v) throws CompileError {
      v.atSymbol(this);
   }
}
