package com.mchange.lang;

import com.mchange.lang.PotentiallySecondary;
import java.io.PrintStream;
import java.io.PrintWriter;

public class PotentiallySecondaryRuntimeException extends RuntimeException implements PotentiallySecondary {
   static final String NESTED_MSG = ">>>>>>>>>> NESTED EXCEPTION >>>>>>>>";
   Throwable nested;

   public PotentiallySecondaryRuntimeException(String msg, Throwable t) {
      super(msg);
      this.nested = t;
   }

   public PotentiallySecondaryRuntimeException(Throwable t) {
      this("", t);
   }

   public PotentiallySecondaryRuntimeException(String msg) {
      this(msg, (Throwable)null);
   }

   public PotentiallySecondaryRuntimeException() {
      this("", (Throwable)null);
   }

   public Throwable getNestedThrowable() {
      return this.nested;
   }

   public void printStackTrace(PrintWriter pw) {
      super.printStackTrace(pw);
      if(this.nested != null) {
         pw.println(">>>>>>>>>> NESTED EXCEPTION >>>>>>>>");
         this.nested.printStackTrace(pw);
      }

   }

   public void printStackTrace(PrintStream ps) {
      super.printStackTrace(ps);
      if(this.nested != null) {
         ps.println("NESTED_MSG");
         this.nested.printStackTrace(ps);
      }

   }

   public void printStackTrace() {
      this.printStackTrace(System.err);
   }
}
