package com.mchange.v1.xml;

import com.mchange.v1.util.DebugUtils;
import java.util.ArrayList;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public final class DomParseUtils {
   static final boolean DEBUG = true;

   public static String allTextFromUniqueChild(Element elem, String childTagName) throws DOMException {
      return allTextFromUniqueChild(elem, childTagName, false);
   }

   public static String allTextFromUniqueChild(Element elem, String childTagName, boolean trim) throws DOMException {
      Element uniqueChild = uniqueChildByTagName(elem, childTagName);
      return uniqueChild == null?null:allTextFromElement(uniqueChild, trim);
   }

   public static Element uniqueChild(Element elem, String childTagName) throws DOMException {
      return uniqueChildByTagName(elem, childTagName);
   }

   /** @deprecated */
   public static Element uniqueChildByTagName(Element elem, String childTagName) throws DOMException {
      NodeList nl = elem.getElementsByTagName(childTagName);
      int len = nl.getLength();
      DebugUtils.myAssert(len <= 1, "There is more than one (" + len + ") child with tag name: " + childTagName + "!!!");
      return len == 1?(Element)nl.item(0):null;
   }

   public static String allText(Element elem) throws DOMException {
      return allTextFromElement(elem);
   }

   public static String allText(Element elem, boolean trim) throws DOMException {
      return allTextFromElement(elem, trim);
   }

   /** @deprecated */
   public static String allTextFromElement(Element elem) throws DOMException {
      return allTextFromElement(elem, false);
   }

   /** @deprecated */
   public static String allTextFromElement(Element elem, boolean trim) throws DOMException {
      StringBuffer textBuf = new StringBuffer();
      NodeList nl = elem.getChildNodes();
      int out = 0;

      for(int len = nl.getLength(); out < len; ++out) {
         Node node = nl.item(out);
         if(node instanceof Text) {
            textBuf.append(node.getNodeValue());
         }
      }

      String var7 = textBuf.toString();
      return trim?var7.trim():var7;
   }

   public static String[] allTextFromImmediateChildElements(Element parent, String tagName) throws DOMException {
      return allTextFromImmediateChildElements(parent, tagName, false);
   }

   public static String[] allTextFromImmediateChildElements(Element parent, String tagName, boolean trim) throws DOMException {
      NodeList nl = immediateChildElementsByTagName(parent, tagName);
      int len = nl.getLength();
      String[] out = new String[len];

      for(int i = 0; i < len; ++i) {
         out[i] = allText((Element)nl.item(i), trim);
      }

      return out;
   }

   public static NodeList immediateChildElementsByTagName(Element parent, String tagName) throws DOMException {
      return getImmediateChildElementsByTagName(parent, tagName);
   }

   /** @deprecated */
   public static NodeList getImmediateChildElementsByTagName(Element parent, String tagName) throws DOMException {
      final ArrayList nodes = new ArrayList();

      for(Node child = parent.getFirstChild(); child != null; child = child.getNextSibling()) {
         if(child instanceof Element && ((Element)child).getTagName().equals(tagName)) {
            nodes.add(child);
         }
      }

      return new NodeList() {
         public int getLength() {
            return nodes.size();
         }

         public Node item(int i) {
            return (Node)nodes.get(i);
         }
      };
   }

   public static String allTextFromUniqueImmediateChild(Element elem, String childTagName) throws DOMException {
      Element uniqueChild = uniqueImmediateChildByTagName(elem, childTagName);
      return uniqueChild == null?null:allTextFromElement(uniqueChild);
   }

   public static Element uniqueImmediateChild(Element elem, String childTagName) throws DOMException {
      return uniqueImmediateChildByTagName(elem, childTagName);
   }

   /** @deprecated */
   public static Element uniqueImmediateChildByTagName(Element elem, String childTagName) throws DOMException {
      NodeList nl = getImmediateChildElementsByTagName(elem, childTagName);
      int len = nl.getLength();
      DebugUtils.myAssert(len <= 1, "There is more than one (" + len + ") child with tag name: " + childTagName + "!!!");
      return len == 1?(Element)nl.item(0):null;
   }

   /** @deprecated */
   public static String attrValFromElement(Element element, String attrName) throws DOMException {
      Attr attr = element.getAttributeNode(attrName);
      return attr == null?null:attr.getValue();
   }
}
