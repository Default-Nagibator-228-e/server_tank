package com.mchange.v1.identicator;

import com.mchange.v1.identicator.Identicator;

abstract class IdHashKey {
   Identicator id;

   public IdHashKey(Identicator id) {
      this.id = id;
   }

   public abstract Object getKeyObj();

   public Identicator getIdenticator() {
      return this.id;
   }

   public abstract boolean equals(Object var1);

   public abstract int hashCode();
}
