package com.mchange.v1.identicator;

import com.mchange.v1.identicator.IdHashKey;
import com.mchange.v1.identicator.Identicator;
import com.mchange.v1.util.AbstractMapEntry;
import com.mchange.v1.util.SimpleMapEntry;
import com.mchange.v1.util.WrapperIterator;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

abstract class IdMap extends AbstractMap implements Map {
   Map inner;
   Identicator id;

   protected IdMap(Map inner, Identicator id) {
      this.inner = inner;
      this.id = id;
   }

   public Object put(Object key, Object value) {
      return this.inner.put(this.createIdKey(key), value);
   }

   public boolean containsKey(Object key) {
      return this.inner.containsKey(this.createIdKey(key));
   }

   public Object get(Object key) {
      return this.inner.get(this.createIdKey(key));
   }

   public Object remove(Object key) {
      return this.inner.remove(this.createIdKey(key));
   }

   protected Object removeIdHashKey(IdHashKey idhk) {
      return this.inner.remove(idhk);
   }

   public Set entrySet() {
      return new IdMap.UserEntrySet();
   }

   protected final Set internalEntrySet() {
      return this.inner.entrySet();
   }

   protected abstract IdHashKey createIdKey(Object var1);

   protected final Entry createIdEntry(Object key, Object val) {
      return new SimpleMapEntry(this.createIdKey(key), val);
   }

   protected final Entry createIdEntry(Entry entry) {
      return this.createIdEntry(entry.getKey(), entry.getValue());
   }

   // $FF: synthetic class
   static class SyntheticClass_1 {
   }

   protected static class UserEntry extends AbstractMapEntry {
      private Entry innerEntry;

      UserEntry(Entry innerEntry) {
         this.innerEntry = innerEntry;
      }

      public final Object getKey() {
         return ((IdHashKey)this.innerEntry.getKey()).getKeyObj();
      }

      public final Object getValue() {
         return this.innerEntry.getValue();
      }

      public final Object setValue(Object value) {
         return this.innerEntry.setValue(value);
      }
   }

   private final class UserEntrySet extends AbstractSet {
      Set innerEntries;

      private UserEntrySet() {
         this.innerEntries = IdMap.this.inner.entrySet();
      }

      public Iterator iterator() {
         return new WrapperIterator(this.innerEntries.iterator(), true) {
            protected Object transformObject(Object o) {
               return new IdMap.UserEntry((Entry)o);
            }
         };
      }

      public int size() {
         return this.innerEntries.size();
      }

      public boolean contains(Object o) {
         if(o instanceof Entry) {
            Entry entry = (Entry)o;
            return this.innerEntries.contains(IdMap.this.createIdEntry(entry));
         } else {
            return false;
         }
      }

      public boolean remove(Object o) {
         if(o instanceof Entry) {
            Entry entry = (Entry)o;
            return this.innerEntries.remove(IdMap.this.createIdEntry(entry));
         } else {
            return false;
         }
      }

      public void clear() {
         IdMap.this.inner.clear();
      }

      // $FF: synthetic method
      UserEntrySet(IdMap.SyntheticClass_1 x1) {
         this();
      }
   }
}
