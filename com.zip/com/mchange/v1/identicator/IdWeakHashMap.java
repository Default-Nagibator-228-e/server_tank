package com.mchange.v1.identicator;

import com.mchange.v1.identicator.IdHashKey;
import com.mchange.v1.identicator.IdMap;
import com.mchange.v1.identicator.Identicator;
import com.mchange.v1.identicator.WeakIdHashKey;
import com.mchange.v1.util.WrapperIterator;
import java.lang.ref.ReferenceQueue;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public final class IdWeakHashMap extends IdMap implements Map {
   ReferenceQueue rq = new ReferenceQueue();

   public IdWeakHashMap(Identicator id) {
      super(new HashMap(), id);
   }

   public int size() {
      this.cleanCleared();
      return super.size();
   }

   public boolean isEmpty() {
      boolean var1;
      try {
         var1 = super.isEmpty();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   public boolean containsKey(Object o) {
      boolean var2;
      try {
         var2 = super.containsKey(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public boolean containsValue(Object o) {
      boolean var2;
      try {
         var2 = super.containsValue(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public Object get(Object o) {
      Object var2;
      try {
         var2 = super.get(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public Object put(Object k, Object v) {
      Object var3;
      try {
         var3 = super.put(k, v);
      } finally {
         this.cleanCleared();
      }

      return var3;
   }

   public Object remove(Object o) {
      Object var2;
      try {
         var2 = super.remove(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public void putAll(Map m) {
      try {
         super.putAll(m);
      } finally {
         this.cleanCleared();
      }

   }

   public void clear() {
      try {
         super.clear();
      } finally {
         this.cleanCleared();
      }

   }

   public Set keySet() {
      Set var1;
      try {
         var1 = super.keySet();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   public Collection values() {
      Collection var1;
      try {
         var1 = super.values();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   public Set entrySet() {
      IdWeakHashMap.WeakUserEntrySet var1;
      try {
         var1 = new IdWeakHashMap.WeakUserEntrySet();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   public boolean equals(Object o) {
      boolean var2;
      try {
         var2 = super.equals(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public int hashCode() {
      int var1;
      try {
         var1 = super.hashCode();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   protected IdHashKey createIdKey(Object o) {
      return new WeakIdHashKey(o, this.id, this.rq);
   }

   private void cleanCleared() {
      WeakIdHashKey.Ref ref;
      while((ref = (WeakIdHashKey.Ref)this.rq.poll()) != null) {
         this.removeIdHashKey(ref.getKey());
      }

   }

   // $FF: synthetic class
   static class SyntheticClass_1 {
   }

   private final class WeakUserEntrySet extends AbstractSet {
      Set innerEntries;

      private WeakUserEntrySet() {
         this.innerEntries = IdWeakHashMap.this.internalEntrySet();
      }

      public Iterator iterator() {
         WrapperIterator var1;
         try {
            var1 = new WrapperIterator(this.innerEntries.iterator(), true) {
               protected Object transformObject(Object o) {
                  final Entry innerEntry = (Entry)o;
                  final Object userKey = ((IdHashKey)innerEntry.getKey()).getKeyObj();
                  return userKey == null?WrapperIterator.SKIP_TOKEN:new IdMap.UserEntry(innerEntry) {
                     Object preventRefClear = userKey;
                  };
               }
            };
         } finally {
            IdWeakHashMap.this.cleanCleared();
         }

         return var1;
      }

      public int size() {
         IdWeakHashMap.this.cleanCleared();
         return this.innerEntries.size();
      }

      public boolean contains(Object o) {
         boolean entry;
         try {
            if(o instanceof Entry) {
               Entry entry1 = (Entry)o;
               boolean var3 = this.innerEntries.contains(IdWeakHashMap.this.createIdEntry(entry1));
               return var3;
            }

            entry = false;
         } finally {
            IdWeakHashMap.this.cleanCleared();
         }

         return entry;
      }

      public boolean remove(Object o) {
         boolean var3;
         try {
            if(!(o instanceof Entry)) {
               boolean entry1 = false;
               return entry1;
            }

            Entry entry = (Entry)o;
            var3 = this.innerEntries.remove(IdWeakHashMap.this.createIdEntry(entry));
         } finally {
            IdWeakHashMap.this.cleanCleared();
         }

         return var3;
      }

      public void clear() {
         try {
            IdWeakHashMap.this.inner.clear();
         } finally {
            IdWeakHashMap.this.cleanCleared();
         }

      }

      // $FF: synthetic method
      WeakUserEntrySet(IdWeakHashMap.SyntheticClass_1 x1) {
         this();
      }
   }
}
