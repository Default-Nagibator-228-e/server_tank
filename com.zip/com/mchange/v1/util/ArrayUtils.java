package com.mchange.v1.util;

import com.mchange.v2.lang.ObjectUtils;

public final class ArrayUtils {
   public static int indexOf(Object[] array, Object o) {
      int i = 0;

      for(int len = array.length; i < len; ++i) {
         if(o.equals(array[i])) {
            return i;
         }
      }

      return -1;
   }

   public static int identityIndexOf(Object[] array, Object o) {
      int i = 0;

      for(int len = array.length; i < len; ++i) {
         if(o == array[i]) {
            return i;
         }
      }

      return -1;
   }

   public static boolean startsWith(byte[] checkMe, byte[] maybePrefix) {
      int cm_len = checkMe.length;
      int mp_len = maybePrefix.length;
      if(cm_len < mp_len) {
         return false;
      } else {
         for(int i = 0; i < mp_len; ++i) {
            if(checkMe[i] != maybePrefix[i]) {
               return false;
            }
         }

         return true;
      }
   }

   public static int hashArray(Object[] oo) {
      int len = oo.length;
      int out = len;

      for(int i = 0; i < len; ++i) {
         int elem_hash = ObjectUtils.hashOrZero(oo[i]);
         int rot = i % 32;
         int rot_hash = elem_hash >>> rot;
         rot_hash |= elem_hash << 32 - rot;
         out ^= rot_hash;
      }

      return out;
   }

   public static int hashArray(int[] ii) {
      int len = ii.length;
      int out = len;

      for(int i = 0; i < len; ++i) {
         int elem_hash = ii[i];
         int rot = i % 32;
         int rot_hash = elem_hash >>> rot;
         rot_hash |= elem_hash << 32 - rot;
         out ^= rot_hash;
      }

      return out;
   }

   public static int hashOrZeroArray(Object[] oo) {
      return oo == null?0:hashArray(oo);
   }

   public static int hashOrZeroArray(int[] ii) {
      return ii == null?0:hashArray(ii);
   }

   /** @deprecated */
   public static String stringifyContents(Object[] array) {
      StringBuffer sb = new StringBuffer();
      sb.append("[ ");
      int i = 0;

      for(int len = array.length; i < len; ++i) {
         if(i != 0) {
            sb.append(", ");
         }

         sb.append(array[i].toString());
      }

      sb.append(" ]");
      return sb.toString();
   }

   private static String toString(String[] strings, int guessed_len) {
      StringBuffer sb = new StringBuffer(guessed_len);
      boolean first = true;
      sb.append('[');
      int i = 0;

      for(int len = strings.length; i < len; ++i) {
         if(first) {
            first = false;
         } else {
            sb.append(',');
         }

         sb.append(strings[i]);
      }

      sb.append(']');
      return sb.toString();
   }

   public static String toString(boolean[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         String str = String.valueOf(arr[i]);
         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }

   public static String toString(byte[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         String str = String.valueOf(arr[i]);
         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }

   public static String toString(char[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         String str = String.valueOf(arr[i]);
         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }

   public static String toString(short[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         String str = String.valueOf(arr[i]);
         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }

   public static String toString(int[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         String str = String.valueOf(arr[i]);
         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }

   public static String toString(long[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         String str = String.valueOf(arr[i]);
         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }

   public static String toString(float[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         String str = String.valueOf(arr[i]);
         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }

   public static String toString(double[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         String str = String.valueOf(arr[i]);
         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }

   public static String toString(Object[] arr) {
      String[] strings = new String[arr.length];
      int chars = 0;
      int i = 0;

      for(int len = arr.length; i < len; ++i) {
         Object o = arr[i];
         String str;
         if(o instanceof Object[]) {
            str = toString((Object[])((Object[])o));
         } else if(o instanceof double[]) {
            str = toString((double[])((double[])o));
         } else if(o instanceof float[]) {
            str = toString((float[])((float[])o));
         } else if(o instanceof long[]) {
            str = toString((long[])((long[])o));
         } else if(o instanceof int[]) {
            str = toString((int[])((int[])o));
         } else if(o instanceof short[]) {
            str = toString((short[])((short[])o));
         } else if(o instanceof char[]) {
            str = toString((char[])((char[])o));
         } else if(o instanceof byte[]) {
            str = toString((byte[])((byte[])o));
         } else if(o instanceof boolean[]) {
            str = toString((boolean[])((boolean[])o));
         } else {
            str = String.valueOf(arr[i]);
         }

         chars += str.length();
         strings[i] = str;
      }

      return toString(strings, chars + arr.length + 1);
   }
}
