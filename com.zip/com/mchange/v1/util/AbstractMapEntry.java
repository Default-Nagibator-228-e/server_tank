package com.mchange.v1.util;

import com.mchange.v2.lang.ObjectUtils;
import java.util.Map.Entry;

public abstract class AbstractMapEntry implements Entry {
   public abstract Object getKey();

   public abstract Object getValue();

   public abstract Object setValue(Object var1);

   public boolean equals(Object o) {
      if(!(o instanceof Entry)) {
         return false;
      } else {
         Entry other = (Entry)o;
         return ObjectUtils.eqOrBothNull(this.getKey(), other.getKey()) && ObjectUtils.eqOrBothNull(this.getValue(), other.getValue());
      }
   }

   public int hashCode() {
      return (this.getKey() == null?0:this.getKey().hashCode()) ^ (this.getValue() == null?0:this.getValue().hashCode());
   }
}
