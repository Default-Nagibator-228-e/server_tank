package com.mchange.v1.lang;

/** @deprecated */
public final class NullUtils {
   public static boolean equalsOrBothNull(Object a, Object b) {
      return a == b?true:(a == null?false:a.equals(b));
   }
}
