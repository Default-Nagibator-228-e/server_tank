package javax.transaction;

public class HeuristicMixedException extends Exception {
   public HeuristicMixedException() {
   }

   public HeuristicMixedException(String msg) {
      super(msg);
   }
}
