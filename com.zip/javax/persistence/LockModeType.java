package javax.persistence;

public enum LockModeType {
   READ,
   WRITE;
}
