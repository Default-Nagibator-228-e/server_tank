package javax.persistence;

import java.util.Map;
import javax.persistence.EntityManager;

public interface EntityManagerFactory {
   EntityManager createEntityManager();

   EntityManager createEntityManager(Map var1);

   void close();

   boolean isOpen();
}
