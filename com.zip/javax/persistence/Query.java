package javax.persistence;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.FlushModeType;
import javax.persistence.TemporalType;

public interface Query {
   List getResultList();

   Object getSingleResult();

   int executeUpdate();

   Query setMaxResults(int var1);

   Query setFirstResult(int var1);

   Query setHint(String var1, Object var2);

   Query setParameter(String var1, Object var2);

   Query setParameter(String var1, Date var2, TemporalType var3);

   Query setParameter(String var1, Calendar var2, TemporalType var3);

   Query setParameter(int var1, Object var2);

   Query setParameter(int var1, Date var2, TemporalType var3);

   Query setParameter(int var1, Calendar var2, TemporalType var3);

   Query setFlushMode(FlushModeType var1);
}
