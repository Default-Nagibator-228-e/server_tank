package javax.persistence;

public enum DiscriminatorType {
   STRING,
   CHAR,
   INTEGER;
}
