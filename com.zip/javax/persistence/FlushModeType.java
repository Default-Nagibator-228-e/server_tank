package javax.persistence;

public enum FlushModeType {
   COMMIT,
   AUTO;
}
