package javax.persistence;

import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.LockModeType;
import javax.persistence.Query;

public interface EntityManager {
   void persist(Object var1);

   Object merge(Object var1);

   void remove(Object var1);

   Object find(Class var1, Object var2);

   Object getReference(Class var1, Object var2);

   void flush();

   void setFlushMode(FlushModeType var1);

   FlushModeType getFlushMode();

   void lock(Object var1, LockModeType var2);

   void refresh(Object var1);

   void clear();

   boolean contains(Object var1);

   Query createQuery(String var1);

   Query createNamedQuery(String var1);

   Query createNativeQuery(String var1);

   Query createNativeQuery(String var1, Class var2);

   Query createNativeQuery(String var1, String var2);

   void joinTransaction();

   Object getDelegate();

   void close();

   boolean isOpen();

   EntityTransaction getTransaction();
}
