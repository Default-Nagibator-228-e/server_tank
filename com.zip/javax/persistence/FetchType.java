package javax.persistence;

public enum FetchType {
   LAZY,
   EAGER;
}
