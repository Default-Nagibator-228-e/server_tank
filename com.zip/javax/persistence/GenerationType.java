package javax.persistence;

public enum GenerationType {
   TABLE,
   SEQUENCE,
   IDENTITY,
   AUTO;
}
