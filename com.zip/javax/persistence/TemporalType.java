package javax.persistence;

public enum TemporalType {
   DATE,
   TIME,
   TIMESTAMP;
}
