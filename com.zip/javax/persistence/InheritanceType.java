package javax.persistence;

public enum InheritanceType {
   SINGLE_TABLE,
   TABLE_PER_CLASS,
   JOINED;
}
