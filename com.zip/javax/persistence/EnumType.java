package javax.persistence;

public enum EnumType {
   ORDINAL,
   STRING;
}
