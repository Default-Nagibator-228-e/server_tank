package javax.persistence;

public enum CascadeType {
   ALL,
   PERSIST,
   MERGE,
   REMOVE,
   REFRESH;
}
