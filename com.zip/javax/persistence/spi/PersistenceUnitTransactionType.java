package javax.persistence.spi;

public enum PersistenceUnitTransactionType {
   JTA,
   RESOURCE_LOCAL;
}
