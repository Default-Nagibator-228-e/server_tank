package javax.xml.parsers;

public class ParserConfigurationException extends Exception {
   public ParserConfigurationException() {
   }

   public ParserConfigurationException(String var1) {
      super(var1);
   }
}
