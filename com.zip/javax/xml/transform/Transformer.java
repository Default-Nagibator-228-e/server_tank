package javax.xml.transform;

import java.util.Properties;
import javax.xml.transform.ErrorListener;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;

public abstract class Transformer {
   public abstract void transform(Source var1, Result var2) throws TransformerException;

   public abstract void setParameter(String var1, Object var2);

   public abstract Object getParameter(String var1);

   public abstract void clearParameters();

   public abstract void setURIResolver(URIResolver var1);

   public abstract URIResolver getURIResolver();

   public abstract void setOutputProperties(Properties var1) throws IllegalArgumentException;

   public abstract Properties getOutputProperties();

   public abstract void setOutputProperty(String var1, String var2) throws IllegalArgumentException;

   public abstract String getOutputProperty(String var1) throws IllegalArgumentException;

   public abstract void setErrorListener(ErrorListener var1) throws IllegalArgumentException;

   public abstract ErrorListener getErrorListener();
}
