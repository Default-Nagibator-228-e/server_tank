package javax.xml.transform;

import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;

public interface URIResolver {
   Source resolve(String var1, String var2) throws TransformerException;
}
