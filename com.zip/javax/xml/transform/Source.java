package javax.xml.transform;

public interface Source {
   void setSystemId(String var1);

   String getSystemId();
}
