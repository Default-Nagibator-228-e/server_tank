package javax.xml.transform;

import java.util.Properties;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;

public interface Templates {
   Transformer newTransformer() throws TransformerConfigurationException;

   Properties getOutputProperties();
}
